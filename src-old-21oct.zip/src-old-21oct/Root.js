import { BrowserRouter, BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Login from "./Login/Login";
import FirstComponent from "./Admin/FirstComponent.js"
import SecondComponent from "./Admin/SecondComponent";
import CreateAccount from "./Onboarding_ExternalUser/CreateAccount.js"
import Idletimer from "react-idle-timer"
import { useRef } from "react"
import { useNavigate } from 'react-router'
import App from "./App.js"
import ForgotPassword from "./Login/ForgotPassword.js";
import ResetPassword from "./Component/ResetPassword";
import Dashboard from "./Admin/Dashboard"
import InternalSiteManager from "./Admin/InternalSiteManager"
import Password90 from "./Component/Password90";
import PrivateRoutes from "./Component/PrivateRoute";
import Success from "./Component/Success";
import SideBar from "./AdminDashboard/Sidebar";
import WithSide from "./AdminDashboard/WithSide";
import Home from "./AdminDashboard/Pages/Home";
import InternalUsers from "./AdminDashboard/Pages/InternalUsers";
import CreateUsers from "./AdminDashboard/Pages/CreateUsers";

function Root() {
    const idleTimeRef = useRef(null)
    const navigate = useNavigate()
    // const handleOnIdle=()=>{
    //     console.log(" on handle idle called")
    //     alert(" You have been inactive for 15 min, Please login again")
    //     navigate("/login")
    //     window.location.reload()
    //     sessionStorage.clear()
    // }
    return (
        <div>
            {/* <Idletimer ref={idleTimeRef} timeout={5*1000} onIdle={handleOnIdle} /> */}

            <Routes>

                <Route element={<PrivateRoutes />}>
                    {/* <Route path='/admindashboard'  exact element={<Dashboard/>} /> */}
                    <Route path='/internalsitemanagerdashboard' exact element={<InternalSiteManager />} />
                    <Route path='/admindashboard' exact element={<SideBar />} />





                </Route>
                <Route element={<PrivateRoutes />}>
                    <Route element={<WithSide />}>
                        <Route path='/home' exact element={<Home />} />
                         <Route path='/internalusers' exact element={<InternalUsers />} /> 
                         <Route path='/createuser' exact element={<CreateUsers />} /> 

                    </Route>

                </Route>




                <Route path='/' exact element={<CreateAccount />} />
                <Route path='/login' exact element={<Login />} />
                <Route path='/reset' exact element={<ResetPassword />} />

                <Route path='/forgotpassword' exact element={<ForgotPassword />} />
                {/* <Route path='/home'  exact element={<Home/>} /> */}

                {/* <Route path='/reset'  exact element={<ResetPassword/>} /> */}

                <Route path='/90days' exact element={<Password90 />} />
                {/* <Route path='/admindashboard'  exact element={<SideBar/>} /> */}

                <Route path='/internalusers' exact element={<InternalUsers />} />






                {/* <Route path='/otppage'  exact element={<OTPPage/>} />  */}
                {/* <Route path='/admin'  exact element={<FirstComponent/>} />  */}
                <Route path='/adminExternal' exact element={<SecondComponent />} />
                <Route path='/success' exact element={<Success />} />

















                {/* <Route path='/forgotpassword'  exact element={<ForgotPassword/>} />  */}

            </Routes>
        </div>
    )

}

export default Root

