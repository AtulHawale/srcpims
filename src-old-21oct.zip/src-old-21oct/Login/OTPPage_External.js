import React, { useState } from 'react'
import { ErrorMessage, Field, Form, Formik } from 'formik';
import { useNavigate,useHistory,useLocation} from 'react-router'
import * as yup from 'yup';
import './OTPPage_External.css'
import Footer from '../Footer/Footer.js';
import Logo from "../Logo/TF_Logo.PNG"
import * as HiIcons from 'react-icons/hi';
import 'bootstrap/dist/css/bootstrap.min.css';
import SecondComponent from '../Admin/SecondComponent';
import axios from "axios";





function OTPPage_External(props){
    console.log(" in otp page ")
   
    const navigate = useNavigate();
    const [otpConfimed,setOtpConfirmed]= useState(false)
 
    const formInitialSchema = {

        otp: '',

    }
    const formValidationSchema = yup.object().shape({

        otp: yup.string().required('OTP is required')
    })
    const handleFormSubmit = (values) => {

        console.log(" submitted otp", values)
        axios({
            method: "post",
            withCredentials:true,
            url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/login",
            data: { "email": props.email, "password": props.password, "location":{"verificationToken":values.otp,"locationName":"","singleUse":false}
             },
            headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
        })
            .then((response) => {
                if (response.status === 200) {
                    if (response.data) {
                        setOtpConfirmed(true)
                    }
                   
                }
                console.log("otp login response", response);
                //setData(res.data);

            })
            .catch((err) => {
                
                alert(err.response.data.message)
                console.log("ERRROR", err.response.data.message)
            });
        
    }
    const handleBackButton=()=>{
        console.log("on click called", props)
        props.setLoginClickedExternal(false)
        // navigate(-1)
    }
    return (
        <>
        {otpConfimed?<SecondComponent/>:
         <div >
         <div className='imageStyle'>
                    <img  src={Logo} width="364px" height="144px"></img>
                    </div>
                    <p className="Header">Login to your Account</p>
                    <div style={{textAlign:"center",fontSize:"25px",color:"blue",right:"183px",position:"relative", cursor:"pointer"}}>
                        <HiIcons.HiArrowSmLeft onClick={handleBackButton}/></div>
                   
    
                    <div className="form">
    
                        <Formik initialValues={formInitialSchema}
                            validationSchema={formValidationSchema}
                            onSubmit={(values => handleFormSubmit(values))}>
                            {({ values }) =>
                                <Form>
                                   
                                    <div >
                                    <label htmlFor="otp" className='lab'>Verification Token:</label>
                                        <Field type="text"
                                        
                                            name="otp"
                                            placeholder="Enter verification token"
                                            className="form-control" />
                                        <p className="text-danger">
                                            <ErrorMessage name="otp" />
                                        </p>
                                    </div>
                                   
                                        
    
    
    
                                   
    
                                    <div>
                                        <button className="button"
                                            type="submit"
                                        >Confirm
                                        </button>
                                    </div>
    
    
                                </Form>
                            }
    
                        </Formik> <br></br> <br></br>
                        {/* <div>
                            <label style={{fontSize:"12px"}}>Didn't receive OTP?</label>
                            <label> <a style={{color:"#1E8AE7",fontSize:"12px", paddingLeft:"2px"}}>Resend</a></label>
                        </div> */}
                   {/* <Footer></Footer> */}
    
                      
                    </div>
                    
    
    
                </div>
    
                                    
        
                         } 
        </>
      )
}


export default OTPPage_External