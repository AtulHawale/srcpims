import React, { useEffect, useState } from 'react'
import { ErrorMessage, FastField, Field, Form, Formik, useFormik } from 'formik';
import { useNavigate } from 'react-router'
import * as yup from 'yup';
import Footer from '../Footer/Footer.js';
import { Link } from 'react-router-dom'
import "./Login.css"
import Col from 'react-bootstrap/Col';
 import Logo from "../Logo/TF_Logo.PNG"
import Row from 'react-bootstrap/Row';
import 'bootstrap/dist/css/bootstrap.min.css';
import OTPPage from './OTPPage.js';
import axios from "axios";
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import OTPPage_External from './OTPPage_External.js'
import SecondComponent from '../Admin/SecondComponent.js';


function Login() {
    console.log(" in login page ")
  
var t
    const [loginStatus, setLoginStatus] = useState(false)
    // const [loginData, setLoginData] = useState()
    const [loginClicked, setLoginClicked] = useState(false)
    const [logoutStatus,setLogoutStatus] = useState(false)
    const [loginClickedExternal, setLoginClickedExternal] = useState(false)
   
   
    const [hidePassword, setHidePassword] = useState(false)
    const [loginStatusForExternal, setLoginStatusForExternal] = useState(false)
    const [externalUserData, setExternalUserData] = useState([])
    const [emailEntered, setEmailEntered]= useState("")
    const [passwordEntered, setPasswordEntered]= useState("")
    const [email, setEmail] = useState("")
    const [message, setMessage] = useState(null)
    const [showOTPScreen, setShowOTPScreen]= useState(false)
    //const[externalLoginSuccessful,setExternalLoginSuccessful]= useState(false)
     const navigate = useNavigate();

    //  window.onpopstate = () => {
    //     navigate("/");
    //   }
     

     
    console.log("login clicked",loginClicked)
    const formInitialSchema = {

        email: '',
        password: '',

    }

    const formValidationSchema = yup.object().shape({

        email: yup.string().required('Email is required').email("Please enter Valid email").matches(
            /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
          ,"Please Enter Valid Email"),
        password: hidePassword ? "" : yup.string().required('Password is required'),
    });
    useEffect(() => {
        handleSessionTimeout()
        axios({
            method: "get",
                url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/orgs?paths[]=_id",
                headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
        })
        .then((res) => {
            console.log("use effect response headers", res.headers)
            console.log(" response1111", res);
        })
        
    })
    const handleSessionTimeout=()=>{
        clearTimeout(t)
        document.addEventListener("keydown",handleSessionTimeout)
        document.addEventListener("mousemove",handleSessionTimeout)
        document.addEventListener("touchstart",handleSessionTimeout)
        if(loginClickedExternal){
            
            t= setTimeout(() => {
                 if(logoutStatus){
                 alert(" Your session has expired.  Please Login back to continue.")
                 window.location.reload()
                 navigate("/login")
                // sessionStorage.clear()
                 }
                 axios({
                     method: "post",
                     url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/me/logout",
                     data: { "email": emailEntered, "password": passwordEntered },
                     headers: { "medable-client-key": "XAwz1iPreVSkNY0RPaVcSX" },
                 })
                 .then((res) => {
                     console.log("logout response headers", res.headers)
                     if (res.status === 200) {
                         if (res.data) {
                             setLogoutStatus(true)
                         }
                     }
                     console.log("logout response", res);
                 })
 
             }, 20*1000);
             
         }
    }
    const handleFormSubmit = (values) => {
        setEmailEntered(values.email)
        setPasswordEntered(values.password)
        if (loginStatus) {

            axios({
                method: "get",
                url: `https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/validateUser?emailId=${values.email}`,
                headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
            })
            .then((res) => {
                console.log("login response internal user", res)
                if (res.status === 200) {
                  
                    window.location.replace ('https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/saml2/sp/login?RelayState=http%3A%2F%2Flocalhost%3A3000/success&email=')
                   
                    if (res.data) {
                        // setLoginClicked(true)

                    }
                }

               
            })
            .catch((err) => {
                setMessage(err.res.data.message)
                alert(err.res.data.message)
                console.log("ERRROR", err.res.data.message)
            });

        }

        if (loginStatusForExternal) {
            //This is for the external user login
            axios({
                method: "post",
                withCredentials:true,
                url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/login",
                data: { "email": values.email, "password": values.password },
                 headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
            })
                .then((res) => {
                    console.log("login response headers", res.headers)
                    if (res.status === 200||res.status===403) {
                        
                        console.log("hy")
                        if (res.data) {
                            setExternalUserData(res.data)
                            setMessage(res.message)
                            setLoginClickedExternal(true)
                            localStorage.setItem('user',res.data._id) //for successful login
                        }
                        if(res.data.code==='kNewLocation'||res.data.code==='kUnverifiedLocation'||res.data.code==='kLocationClientMismatch'){
                            setShowOTPScreen(true) // for showing OTP screen or directly navigating to logged in screen
                        }
                     

                       
                    }
                    console.log("login response", res);
                })
                .catch((err) => {
                    console.log('error',err)
                    if(err.response.data.code==='kUnverifiedLocation'||err.response.data.code==='kLocationClientMismatch'){
                        setLoginClickedExternal(true)
                        setShowOTPScreen(true) // for showing OTP screen or directly navigating to logged in screen
                    }
                    if(!(err.response.data.code==='kUnverifiedLocation'||err.response.data.code==='kLocationClientMismatch')){
                        setMessage(err.response.data.message)
                    alert(err.response.data.message)
                    }
                    console.log(" in catch block")
                    // setMessage(err.response.data.message)
                    // alert(err.response.data.message)
                    console.log("ERRROR", err.response.data.message)
                });
        }   
        console.log("Submitted value", values)
    }

    return (
       
        <>
          {
            loginClickedExternal?showOTPScreen?<OTPPage_External 
            setLoginClickedExternal={setLoginClickedExternal}
            email={emailEntered} password={passwordEntered}/>:<SecondComponent/>:

        

loginClicked ? <OTPPage setLoginClicked={setLoginClicked} /> :
                <div>
                    <div className='imageStyle'>
                        <img src={Logo} width="364px" height="144px"></img>
                    </div>
                    <p className="Header">Login to your Account</p>

                    <div className="form">

                        <Formik initialValues={formInitialSchema}
                            validationSchema={formValidationSchema}
                            onSubmit={(values => handleFormSubmit(values))}>
                            {(props) => (
                                <Form>
                                    <div >
                                        <label htmlFor="email" className='lab'>Email:</label>
                                        <Field type="text"
                                            name="email"
                                            value={props.values.email}
                                            onChange={(e) => {
                                                setEmail(e.currentTarget.value)
                                                setLoginStatusForExternal(false)
                                                setLoginStatus(false)
                                               
                                                

                                                if (e.currentTarget.value.includes("@thermofisher.com")) {
                                                    setHidePassword(true)
                                                    setLoginStatus(true)
                                                }
                                                if (!(e.currentTarget.value.includes("@thermofisher.com"))) {
                                                    setLoginStatusForExternal(true)
                                                    
                                                }
                                                if (e.currentTarget.value === "" || (!e.target.value.includes("@thermofisher.com"))) {
                                                    setHidePassword(false)
                                                }
                                                ; props.handleChange(e)
                                            }}
                                            placeholder="Enter Email"
                                            className="form-control" />
                                        <p className="text-danger">
                                            <ErrorMessage name="email" />
                                        </p>
                                    </div>
                                    {/* <div className='Forgot'>
                                    <a>Forgot Password</a>
                                </div> */}

                                    {hidePassword === false ?
                                        <div>
                                            <Row>
                                                <Col> <label htmlFor="password" className='lab'>Password:</label></Col>
                                                <Col style={{ paddingLeft: "90px" }}><label className='Forgot'>
                                                <Link style={{textDecoration:'none'}} to="/forgotpassword">Forgot Password?</Link>
                                                </label></Col>
                                            </Row>
                                            <Field type="password"
                                                name="password"
                                                placeholder="Enter Password"
                                                className="form-control" />
                                            <p className="text-danger">
                                                <ErrorMessage name="password" />
                                            </p>
                                        </div> :
                                        <div></div>
                                    }
                                    <br></br>
                                    <div>
                                        <button className="button"
                                            type="submit" 
                                        >Login
                                        </button>
                                    </div>
                                </Form>)
                            }

                        </Formik>
                        <Footer></Footer>
                    </div>
                </div>
            }
        </>
    )
}

export default Login

