import React from "react";
import { usePagination, useTable } from "react-table";
import  styled  from 'styled-components';

const Pagination = styled.div`
    position: absolute;
    right: 0;
    padding: 15px;
    button{
        border: none !important;
        background: #fff;
    }
    font-family: Helvetica;
    font-size: 16px;

`
const TableContainer = styled.div`
    width: 100%;
    position: relative;
    table{
        width: 100%;
        font-family: Helvetica;
        font-size: 16px;
        border: none !important;
    }
    td{
        border-right: none !important;
        border-bottom: 0.5px solid #C8C8C8 !important;
        font-size: 14px;
    }
    th{
        background: #C8C8C8;
        height: 40px;
        border: none !important;
    }
    button{
        border: 0.5px solid #C8C8C8;
        background: #fff;
        padding: 0 15px;
        color: #1E8AE7;
        font-weight: 
    }

`

const CustomTable = ({ columns, data }) => {
  const table = useTable(
    {
      columns,
      data,
      initialState: {
        pageSize: 10,
        pageIndex: 0,
      },
    },
    usePagination
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    prepareRow,
    page,
    canPreviousPage,
    canNextPage,
    pageOptions,
    pageCount,
    gotoPage,
    nextPage,
    previousPage,
    setPageSize,
    state: { pageIndex, pageSize },
  } = table;

  return (
    <TableContainer >
      <table {...getTableProps()} >
        <thead>
          {headerGroups.map((headerGroup) => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map((column) => (
                <th {...column.getHeaderProps()}>{column.render("Header")}</th>
              ))}
            </tr>
          ))}
        </thead>

        <tbody {...getTableBodyProps()}>
          {page.map((row) => {
            prepareRow(row);
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map((cell) => {
                  return (
                    <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
      <Pagination>
        <div>
          <button onClick={() => previousPage()} disabled={!canPreviousPage}>
            {"<"}
          </button>
          <span>
            <>
              {pageIndex + 1}  {"/"}  {pageOptions.length}
            </>{" "}
          </span>
          <button onClick={() => nextPage()} disabled={!canNextPage}>
            {">"}
          </button>
        </div>
      </Pagination>
    </TableContainer>
  );
};

export default CustomTable;
