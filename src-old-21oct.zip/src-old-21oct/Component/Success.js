import { useEffect } from "react"
import axios from "axios";
import { useNavigate } from "react-router-dom";


function Success() {
  const navigate = useNavigate()
 

  useEffect(() => {


    axios({
      method: "get",
      withCredentials: true,
      url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts",
      headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
    })
      .then((res) => {
        console.log("use effect response headers", res.headers)
        console.log(" response1111", res);
        if (res.status === 200) {
          console.log('200')
          console.log(res && res.data.data[0].roles[0], 'roles')

          if(res.data){
            console.log('id')
            localStorage.setItem('user',res.data.data[0]._id)
          }
          if (res && res.data.data[0].roles[0] === '000000000000000000000004') {

            navigate('/admindashboard')
          }
          if (res && res.data.data[0].roles[0] === '62f24d4cf8f151c943f90e0b') {

            navigate('/internalsitemanagerdashboard')
          }

        }

      })

  })
  return (
    <>
      <p>Sucess</p>

    </>
  )
}

export default Success