import React from 'react'
import { ErrorMessage, Field, Form, Formik } from 'formik';
import * as yup from 'yup';
import Footer from "../Footer/Footer.js"
import Logo from "../Logo/TF_Logo.PNG"
import './ResetPassword.css'
import { useNavigate} from 'react-router'


function ResetPassword() {
    const navigate = useNavigate();
    window.onpopstate = () => {
        navigate("/forgotpassword");
      }

    const formInitialSchema = {

        password: '',
        confirmpassword: '',

    }
    const formValidationSchema = yup.object().shape({

        password: yup.string().required('Password is required').matches(

            /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,

            "Does not match with below Criteria"

        ).test('test1', "Does not match with below Criteria", (value) => validate(value)).test('test2', "Does not match with below Criteria", (value) => validate2(value)).required('Password is required'),
        confirmpassword: yup.string().oneOf([yup.ref('password'), null], "Passwords do not match").required('Password is required')
    });

    function validate(pass) {
        console.log("validate called")

        var str = pass;
        var arr = ["2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032", "2033", "2034", "2035", "appliedbio", "fei", "fisher", "invitrogen", "lifetech", "patheon", "thermo"];

        if (str) {
            for (var i in arr) {
                var b = str.indexOf(arr[i]);
                if (b >= 0) {
                    console.log("invalid string");
                    return false;
                }
            }
        }

        return true;
    }


    const validate2 = (val) => {
        let result = [];
        var str = [val];

        if (val) {

            str.map(each => {
                let repeatedChars = 0;
                for (let i = 0; i < each.length - 1; i++) {
                    if (each[i] === each[i + 1] && each[i] === each[i - 1] && each[i] === each[i + 2]) {

                        repeatedChars += 1;
                    }
                }

                result.push(repeatedChars);
                console.log("repeatedChars", repeatedChars);

            });

            if (result[0] > 0) {
                return false
            }
            else {
                return true;
            }
        }
    };
    const handleFormSubmit = (values) => {
        console.log("Submitted values", values)
        navigate('/login')
    }


    return (
        <>
         <div className='imageStyle'>
                <img  src={Logo} width="364px" height="144px"></img>
                </div>
            <h2 className="Header">Reset Password</h2>


            <div className="form">

                <Formik initialValues={formInitialSchema}
                    validationSchema={formValidationSchema}
                    onSubmit={(values => handleFormSubmit(values))}>
                    {({ values }) =>
                        <Form>

                            <div >
                                <label htmlFor="password" className='lab'>Password:</label>
                                <Field type="password"

                                    name="password"
                                    placeholder="Enter your Password"
                                    className="form-control" />
                                <p className="text-danger">
                                    <ErrorMessage name="password" />
                                </p>
                            </div>





                            <div >
                                <label htmlFor="confirmpassword" className='lab'>Confirm Password:</label>
                                <Field type="password"
                                    name="confirmpassword"
                                    placeholder="Confirm Password"
                                    className="form-control" />
                                <p className="text-danger">
                                    <ErrorMessage name="confirmpassword" />
                                </p>
                            </div> 

                            <div className='instruction' >
                                <ul>

                                    <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain at least 8 characters</span></li>
                                    <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain an uppercase letter</span></li>
                                    <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain a lowercase letter</span></li>
                                    <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain a number</span></li>
                                    <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain a symbol</span></li>
                                    <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must not contain consecutive letters or numbers<span className='l'>i.e. 1111 or bbbb</span></span></li>
                                    <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must not contain any of the following <p><span>brand names:appliedbio, fei, fisher,invitrogen,</span><span> lifetech, patheon, thermo</span></p></span></li>



                                </ul>
                            </div>

                            <div>
                                <button className="button1"
                                    type="submit"
                                >Confirm
                                </button>
                            </div>
                           




                        </Form>


                    }

                </Formik>



            </div>


        </>
    )
}

export default ResetPassword