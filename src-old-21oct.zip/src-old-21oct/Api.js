import { useQuery } from "react-query";
import axios from 'axios'
const instance = axios.create({
    withCredentials: true
  })


export const GetInternalUsers = ({queryKey}) => {
    return instance.get(`https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/getUserList?userType=Internal`,{
        headers: {
            'medable-client-key':"ftH8GFHirevP0AbSEZXVgX"
          }
        
    })
}