import React from 'react'
import { useNavigate } from 'react-router-dom'

function InternalSiteManager() {
   const navigate =useNavigate()
   window.onpopstate = () => {
    console.log("hellloo")
    navigate("/");
  }

  return (
    <>
    <h3>Internal Site Manager</h3>
    </>
  )
}

export default InternalSiteManager