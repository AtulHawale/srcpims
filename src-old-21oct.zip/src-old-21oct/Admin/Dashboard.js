import React from 'react'


function Dashboard() {
 
  window.onbeforeunload = function() {localStorage.clear()}
  const Logout=()=>{
    localStorage.clear()
    
   
    window.location.href='https://aav0112.my.idaptive.app/applogout/appkey/3f986442-dbe0-4d4d-935e-c876390cdb1c/customerid/AAV0112'
    
  }

  

  
  return (
    <>
    <h3>Admin Dashboard</h3>
    <button onClick={Logout}>Log Out</button>
    </>
  )
}

export default Dashboard
