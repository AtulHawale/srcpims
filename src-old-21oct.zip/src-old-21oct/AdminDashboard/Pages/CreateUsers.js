import React,{useState, useRef} from 'react'
import './CreateInternalUsers.css'
import * as HiIcons from 'react-icons/hi';
import * as RiIcons from 'react-icons/ri';
import { ErrorMessage, Field, Form, Formik } from 'formik';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import * as yup from 'yup';
import{Link} from 'react-router-dom'
import Multiselect from 'multiselect-react-dropdown';
import axios from 'axios';

///accounts/register


const dropdownoptions = [
    {key:"Select Option",value:""},
    
    {key:"Trail01",value:"Trail01"},
    {key:"Trail02",value:"Trail02"},
    {key:"Trail03",value:"Trail03"},
    {key:"Trail04",value:"Trail04"},
    {key:"Trail05",value:"Trail05"},

]
const homecountrydata = [
    {key:"Select Option",value:""},
    
    {key:"India",value:"India"},
    {key:"Aus",value:"Aus"},
    {key:"England",value:"England"},
    {key:"USA",value:"USA"},
    {key:"NZ",value:"NZ"}
]

const countriesdata = [    
    {key:"India",value:"India"},
    {key:"Aus",value:"Aus"},
    {key:"England",value:"England"},
    {key:"USA",value:"USA"},
    {key:"NZ",value:"NZ"}
]

const countriesdatamulti = [
    "India","USA","CHINA"
]


const roledata = [
    {key:"Select Option",value:""},

    
    {key:"Admin",value:"Admin"},
    {key:"Site Manager",value:"Site Manager"},
    {key:"Internal Patiet Manager",value:"Internal Patiet Manager"},
    {key:"External Patiet Manager",value:"External Patiet Manager"}

    
]


 

function CreateUsers() {
    console.log(" i m here")
    const [homecountry1,setHomecountry] = useState("");
 const [role1,setRole] = useState("");
 const [timezone1,setTimezone] = useState("");
 const [site1,setSite] = useState("");
 


 const selectvalueref = useRef(null);
 const [selectedValue,setSelectedValue] = useState([]);
 var [mcountryvalue,setMcountryvalue] = useState([]);

var [arrayname,setArrayname] = useState([]);
//var arrayname = []; //use state only
var [flag,setFlag] = useState(false);
var arr = [];


//var flag = false;

    const formInitialSchema = {

        site: '',
        countries: '',
        //countries: [],

        email:'',
        role:'',
        mobilenumber:'',
        homecountry:'',
        timezone:'',
        fullname:'',
        checked:[],
        toggle:false

    }

   

    const formValidationSchema = yup.object().shape({
      
        
        email: yup.string().email("Please enter Valid email").required('Email is required').test('test4',"Email Id for Internal User",(value)=>validate(value)).matches(
            /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
          ,"Please Enter Valid Email"),
        
        
        fullname :yup.string().required('Fullname is required'),
        //countries : yup.array().required('Required')

    });

    const validate=(em)=>{
        if(em)
        {
            if(em.includes("@thermofisher.com"))
        {
            return true;
        }
        else{
            return false;
        }
        }
        

    }

    const onSelectcountries=(selectedList, selectedItem)=> {
        console.log("--",selectedList);
        setSelectedValue(selectedList);
       // console.log("--",selectedItem);
       setMcountryvalue(selectedList.map((val)=>{
            return val.key
       }))

    }



    const addnewinput = ()=>{
        if(flag!=true)
        {
        setFlag(true);
        }
        //flag = true;
        console.log(flag);
        console.log("add new input is called..")

        var obj = {
            key:"keydata",
            value:"valuedata"
        }
    
        arr.push(obj);
        console.log("arr",arr);
        setArrayname([...arrayname,...arr]);
        console.log("arrayname",arrayname);
    }



    const handleFormSubmit = (values) => {
        const headers = {
            'Medable-Client-Key': 'EYKm5YLKZjjRNi7MDkqxA3',
            'Origin': 'https://api.dev.medable.com'
          }
        console.log("Submitted values", values)
        console.log("selectedValue====>",mcountryvalue);
        

        var trialcountrydata = [
            {
             "t__trial_id": values.site,
             "t__trial_countries": mcountryvalue
            },{
                "t__trial_id": "TRIAL002",
                "t__trial_countries": ["USA", "IND"]
            }]

        const userdata = {
            "email": values.email,
            "mobile": values.mobilenumber.toString(),
            "password": "Testuser123",
            "t__status": "Active",
            "t__home_country": values.homecountry,
            "name": {
                      "first": values.fullname,
                      "last": "surname"
                     },
            "t__user_type": "Internal",
            "tz":"Etc/GMT-5",//"Etc/GMT-5" values.timezone
              "roles": [values.role],
              
            "t__trial_country": trialcountrydata
            }

           /* const userdata = {
                "email": "testuser2027676@thermofisher.com",
                "mobile":"+919867314120",
                "password": "Testuser123",
                "t__status": "Active",
                "t__home_country": "USA",
                "name": {
                          "first": "Test",
                          "last": "User20"
                         },
                "t__user_type": "Internal",
                "tz": "Etc/GMT-5",
                  "roles": ["000000000000000000000004"],
                  
                "t__trial_country":[
                        {
                         "t__trial_id": "TRIAL001",
                         "t__trial_countries": ["USA", "IND"]
                        },
                    {
                        "t__trial_id": "TRIAL002",
                        "t__trial_countries": ["USA", "IND"]
                    }]
                }*/


            console.log("userdata==>",userdata);
            axios.post("https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/register",userdata,{
                headers: headers
              }).then((res)=>{
                  console.log("response from backend",res)
              }).catch((err)=>{
                  alert(err);

              })

    }

    return (
        <>
            <p className='Heading6'>Internal Users</p>
            <div className='iconback'> <HiIcons.HiArrowSmLeft></HiIcons.HiArrowSmLeft> Back</div>
            <p className='Heading7'>Create new user</p>

            <div >

            <Formik initialValues={formInitialSchema}
                        validationSchema={formValidationSchema}
                        onSubmit={(values => handleFormSubmit(values))}>
                    {formik =>
                        <Form>
                            <div className='user'>
                                <div className="copo"> 
                                    <div >
                                    <label htmlFor="site" className='labcu'>Trial:  </label>
                                    <Field as='select'      
                                        name="site"
                                        placeholder="Select Site"
                                        className="form-select" 
                                        style={{ width: '224px'  }}

                                    >
                                        {dropdownoptions.map(option => {
                                            return (<option key={option.value} value={option.value}>
                                                {option.key}
                                            </option>
                                            )
                                        })}
                                    </Field>
                                    <p className="text-danger">
                                        <ErrorMessage name="role" />
                                    </p>

                                </div>
                                    <div >
                                    <label htmlFor="countries" className='labcu'>Countries:  </label>
                                    <Multiselect
                                    
                                    style={{ width: '224px', height: '48px',option:{color: "black"},chips:{background: "grey"}  }}
                                    
                                    onSelect={onSelectcountries}
                                    hidePlaceholder={true}
                                    placeholder="Select Countries"
                                    showCheckbox={true}
                                    ref={selectvalueref}
                                options={countriesdata}
                                showArrow={true}
                                displayValue="key"/>
                                    
                                    <p className="text-danger">
                                        <ErrorMessage name="countries" />
                                    </p>

                                </div>

                                

                                    
                                </div>

                                {/*{flag ? arrayname.map(val=>{
                                   return( <div className='labcu'>{val.key}</div>)

                                }) : null}*/}

                                {flag ? arrayname.map(val=>{
                                   return( <>
                                    <div className="copo"> 
                                   <div >
                                    
                                    <Field as='select'      
                                        name="site"
                                        placeholder="Select Site"
                                        className="form-select" 
                                        style={{ width: '224px'  }}

                                    >
                                        {dropdownoptions.map(option => {
                                            return (<option key={option.value} value={option.value}>
                                                {option.key}
                                            </option>
                                            )
                                        })}
                                    </Field>
                                    <p className="text-danger">
                                        <ErrorMessage name="role" />
                                    </p>

                                </div>
                                <div >
                                    
                                    <Multiselect
                                    
                                    style={{ width: '224px', height: '48px',option:{color: "black"},chips:{background: "grey"}  }}
                                    
                                    onSelect={onSelectcountries}
                                    hidePlaceholder={true}
                                    placeholder="Select Countries"
                                    showCheckbox={true}
                                    ref={selectvalueref}
                                options={countriesdata}
                                showArrow={true}
                                displayValue="key"/>
                                    
                                    <p className="text-danger">
                                        <ErrorMessage name="countries" />
                                    </p>

                                </div>
                                </div></>)
                                }) : null}   

                                 {/*{flag?<div  className='labcu'>Home Country  </div>:null}*/}

                                <button type='button' onClick={addnewinput} >Add new Site & Countries</button>
                                <br></br> <br></br>


                                <div className='rectangle'>

                                <div >
                                    <label htmlFor="fullname" className='labcu'>Full Name:</label>
                                    <Field type="text"

                                        name="fullname"
                                        placeholder="Enter your Full Name"
                                        className="form-controlcu" />
                                    <p className="text-danger">
                                        <ErrorMessage name="fullname" />
                                    </p>
                                </div>

                                <div >
                                    <label htmlFor="email" className='labcu'>Email:</label>
                                    <Field type="text"

                                        name="email"
                                        placeholder="Enter your Email"
                                        className="form-controlcu" />
                                    <p className="text-danger">
                                        <ErrorMessage name="email" />
                                    </p>
                                </div>

                                <div >
                                    <label htmlFor="mobilenumber" className='labcu'>mobile number</label>
                                    <Field type="number"
                                        name="mobilenumber"
                                        placeholder="Confirm mobile number with country code"
                                        className="form-controlcu" />
                                    <p className="text-danger">
                                        <ErrorMessage name="mobilenumber" />
                                    </p>
                                </div>
                                <div >
                                    <label htmlFor="role" className='labcu'>Role  </label>
                                    <Field as='select'

                                       
                                        name="role"
                                       
                                        className="form-select form-controlcu"

                                    >
                                        {roledata.map(option => {
                                            return (<option key={option.value} value={option.value}>
                                                {option.key}
                                            </option>
                                            )
                                        })}
                                    </Field>
                                    <p className="text-danger">
                                        <ErrorMessage name="role" />
                                    </p>

                                </div>
                                <div >
                                    <label htmlFor="homecountry" className='labcu'>Home Country  </label>
                                    <Field as='select'

                                
                                        
                                        /*onChange={(e)=>{
                                            setHomecountry(e.target.value)
                                            
                                            formik.handleChange(e);
                                        }}*/
                                        name="homecountry"
                                        className="form-select form-controlcu"

                                    >
                                        {homecountrydata.map(option => {
                                            return (<option key={option.value} value={option.value}>
                                                {option.key}
                                            </option>
                                            )
                                        })}
                                       


                                    </Field>
                                    <p className="text-danger">
                                        <ErrorMessage name="homecountry" />
                                    </p>

                                </div>
                                <div >
                                    <label htmlFor="timezone" className='labcu'>Time Zone</label>
                                    <Field as='select'

                                        id="1"
                                        name="timezone"
                                       
                                        className="form-select form-controlcu"

                                    >
                                        {dropdownoptions.map(option => {
                                            return (<option key={option.value} value={option.value}>
                                                {option.key}
                                            </option>
                                            )
                                        })}
                                       


                                    </Field>
                                    <p className="text-danger">
                                        <ErrorMessage name="timezone" />
                                    </p>

                                </div>
                                </div>
                                

                                {/*<div>
                                    <button className="button"
                                        type="submit"

                                    >Confirm
                                    </button>
    </div>*/}
                              </div>
                              <div>
                                    <button className="buttoncu"
                                        type="submit"

                                    >Save
                                    </button>

                                </div>


                        </Form>
                        
                    }

                </Formik>


            </div>
           

            





        </>
    )
}

export default CreateUsers