import React from "react";
import CustomTable from "../../Component/CustomTable";
import { useState, useEffect, useMemo } from "react";
import styled from "styled-components";
import jsondata from "../../Data/InternalUsersList.json";
import { Field } from "formik";
import Select from "react-select";
import { useQuery } from 'react-query';
import {GetInternalUsers} from "../../Api"
import axios from "axios"
import Loader from "react-loader";

const TableWrapper = styled.div`
  padding: 1rem;

  table {
    border-spacing: 0;
    border: 1px solid black;

    tr {
      :last-child {
        td {
          border-bottom: 0;
        }
      }
    }

    th,
    td {
      margin: 0;
      padding: 0.5rem;
      border-bottom: 1px solid black;
      border-right: 1px solid black;

      :last-child {
        border-right: 0;
      }
    }
  }
`;
const Search = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-family: Helvetica;
  font-size: 16px;
  input{
    height: 40px;
    border: 1px solid #C8C8C8;
    padding: 10px;
    border-radius: 4px;
  }
  .search-heading{
    font-weight: 700;
  }
  .select {
      height: 40px;  
      .mySelect__control{
          height: 100%;
      }
      .mySelect__single-value {
          height: 100%;
          line-height: 40px;
      }
      .mySelect__indicators {
          height: 100%;
      }
      .mySelect__indicator-separator{
          display: none;
      }
  }
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 20px 0;
`


function InternalUsers() {
  const [data, setData] = useState([]);
  const [pageCount, setPageCount] = React.useState(0);
  const [totalRecords, setTotalRecords] = useState();
  const [filteredArray, setFilteredArray] = useState([]);
  const [filteredText, setFilteredText] = useState();
  const [columnBy, setColumnBy] = useState({ label: "By email", value: "email" });
  const options = [
    { value: "email", label: "By email" },
    { value: "name", label: "By name" },
    { value: "role", label: "By role" },
  ];

  

  const columns = useMemo(() => [
    {
      Header: "Email",
      accessor: "email",
    },
    {
      Header: "Name",
      // accessor: "name",
    },
    {
      Header: "Role",
      // accessor: "role",
    },
    {
      Header: "Activation Status",
      // accessor: "status",
    },
    {
      Header: "Trail No",
      // accessor: "protocol",
    },
    {
      Header: "Site No",
      // accessor: "siteno",
    },
    {
      Header: "Country",
      // accessor: "country",
    },
    {
      Header: "",
      accessor: "access",
      Cell: ({ cell }) => <button>View/Edit</button>,
    },
  ]);
console.log("columnBy",columnBy)
  const handleSearch = (e) => {
    console.log("eee", e.target.value);
    setFilteredText(e.target.value);
    const dataArray = [...data];
    const newArray = dataArray.filter((item) =>
      item[columnBy.value].includes(e.target.value)
    );
    console.log("dataARRay", newArray);
    setFilteredArray(newArray);
  };

  console.log("data", data);

  const handleChange = (value) => {
    console.log("value", value);
    setColumnBy(value);
  };

  const GetInternalUsersApi = useQuery("GetInternalUsersApi",GetInternalUsers,{
      enabled: true,
      onSuccess:(res) => {
          console.log("res",res.data.data)
          setData(res.data.data)
      }
  })
  return (
    <TableWrapper>
      <Header>
        <h1>Internal Users</h1>
        <Search className="col-md-6">
          <div className="search-heading">Search User:</div>
          <div>
          <Select
            options={options}
            onChange={(value) => handleChange(value)}
            defaultValue={columnBy}
            className="select"
            classNamePrefix="mySelect"
          />
          </div>
        

          <input type="text" onChange={(e) => handleSearch(e)} placeholder="Enter Information"/>
        </Search>
      </Header>
      {
        GetInternalUsersApi.isLoading ? <Loader /> : 
      
      <CustomTable
        columns={columns}
        data={filteredText ? filteredArray : data}
      />
}
    </TableWrapper>
  );
}

export default InternalUsers;
