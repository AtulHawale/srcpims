import React from 'react'
import './Home.css'

function Home() {


  return (
 <>
 <h3 className='home'>Home</h3></>
  )
}

export default Home