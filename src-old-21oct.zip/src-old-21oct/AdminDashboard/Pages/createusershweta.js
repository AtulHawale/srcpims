import React, { useState } from 'react'
import './CreateUser.css'
import * as HiIcons from 'react-icons/hi';
import * as RiIcons from 'react-icons/ri';
import { ErrorMessage, Field, Form, Formik } from 'formik';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import * as yup from 'yup';
import { Link } from 'react-router-dom'
import ProfileHeader from '../ProfileHeader';


const dropdownoptions = [

    { key: "India", value: "India" }
]

function CreateUsers() {
    console.log(" i m here")
    const formInitialSchema = {

        site: '',
        countries: '',
        email: '',
        role: '',
        mobilenumber: '',
        homecountry: '',
        timezone: '',
        fullname: ''

    }

    //const [homecountry,homecountry]

    const formValidationSchema = yup.object().shape({


        email: yup.string().email("Please enter Valid email").required('Email is required').test('test4', "Email Id for Internal User", (value) => validate(value)).matches(
            /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
            , "Please Enter Valid Email"),


        fullname: yup.string().required('Fullname is required'),

    });

    const validate = (em) => {
        if (em) {
            if (em.includes("@thermofisher.com")) {
                return true;
            }
            else {
                return false;
            }
        }


    }

    const handleFormSubmit = (values) => {
        console.log("Submitted values", values)
    }

    return (
        <>
            <ProfileHeader />
            <p className='Heading6'>Internal Users</p>
            <div className='iconback'> <HiIcons.HiArrowSmLeft></HiIcons.HiArrowSmLeft> Back</div>
            <p className='Heading7'>Create new user</p>

            <div >

                <Formik initialValues={formInitialSchema}
                    validationSchema={formValidationSchema}
                    onSubmit={(values => handleFormSubmit(values))}>
                    {formik =>
                        <Form>
                            <div className='user'>
                                <div className="copo">


                                    <Row>
                                        <Col>
                                            <div >
                                                <label htmlFor="site" className='labcu'>Site:  </label>
                                                <Field as='select'


                                                    name="site"
                                                    placeholder="Select Site"
                                                    className="form-select"
                                                    style={{ width: '224px' }}

                                                >
                                                    {dropdownoptions.map(option => {
                                                        return (<option key={option.value} value={option.value}>
                                                            {option.key}
                                                        </option>
                                                        )
                                                    })}
                                                </Field>
                                                <p className="text-danger">
                                                    <ErrorMessage name="role" />
                                                </p>

                                            </div></Col>

                                        <Col>

                                            <div >
                                                <label htmlFor="countries" className='labcu'>Countries:  </label>
                                                <Field as='select'


                                                    name="countries"
                                                    placeholder="Select Site"
                                                    className="form-select"
                                                    style={{ width: '224px' }}

                                                >
                                                    {dropdownoptions.map(option => {
                                                        return (<option key={option.value} value={option.value}>
                                                            {option.key}
                                                        </option>
                                                        )
                                                    })}
                                                </Field>
                                                <p className="text-danger">
                                                    <ErrorMessage name="countries" />
                                                </p>

                                            </div>


                                        </Col>
                                    </Row>






                                </div>
                                <Link to='' style={{ textDecoration: 'none',fontWeight:'700'}}>Add new Site & Country</Link>
                                <br></br> <br></br>


                                <div className='rectangle'>

                                    <div >
                                        <label htmlFor="fullname" className='labcu'>Full Name:</label>
                                        <Field type="text"

                                            name="fullname"
                                            placeholder="Enter your Full Name"
                                            className="form-controlc" />
                                        <p className="text-danger">
                                            <ErrorMessage name="fullname" />
                                        </p>
                                    </div>

                                    <div >
                                        <label htmlFor="email" className='labcu'>Email:</label>
                                        <Field type="text"

                                            name="email"
                                            placeholder="Enter your Email"
                                            className="form-controlc" />
                                        <p className="text-danger">
                                            <ErrorMessage name="email" />
                                        </p>
                                    </div>

                                    <div >
                                        <label htmlFor="mobilenumber" className='labcu'>mobile number</label>
                                        <Field type="number"
                                            name="mobilenumber"
                                            placeholder="Confirm mobile number with country code"
                                            className="form-controlc" />
                                        <p className="text-danger">
                                            <ErrorMessage name="mobilenumber" />
                                        </p>
                                    </div>
                                    <div >
                                        <label htmlFor="role" className='labcu'>Role  </label>
                                        <Field as='select'


                                            name="role"
                                            placeholder="Select Role"
                                            className="form-selectc "

                                        >
                                            {dropdownoptions.map(option => {
                                                return (<option key={option.value} value={option.value}>
                                                    {option.key}
                                                </option>
                                                )
                                            })}
                                        </Field>
                                        <p className="text-danger">
                                            <ErrorMessage name="role" />
                                        </p>

                                    </div>
                                    <div >
                                        <label htmlFor="homecountry" className='labcu'>Home Country  </label>
                                        <Field as='select'


                                            placeholder="Select Country"
                                            name="homecountry"
                                            className="form-selectc "

                                        >
                                            {dropdownoptions.map(option => {
                                                return (<option key={option.value} value={option.value}>
                                                    {option.key}
                                                </option>
                                                )
                                            })}



                                        </Field>
                                        <p className="text-danger">
                                            <ErrorMessage name="homecountry" />
                                        </p>

                                    </div>
                                    <div >
                                        <label htmlFor="timezone" className='labcu'>Time Zone</label>
                                        <Field as='select'

                                            id="1"
                                            name="timezone"
                                            placeholder="Select Time Zone"
                                            className="form-selectc "

                                        >
                                            {dropdownoptions.map(option => {
                                                return (<option key={option.value} value={option.value}>
                                                    {option.key}
                                                </option>
                                                )
                                            })}



                                        </Field>
                                        <p className="text-danger">
                                            <ErrorMessage name="timezone" />
                                        </p>

                                    </div>
                                   
                                </div>
                                <Row>
      <Col><button className='btn4'>Save</button>
      </Col>
      <Col style={{paddingRight:'480px'}}><button className='btn5'>Cancel</button>
      </Col>
     </Row>

                                


                               
                            </div>
                           


                        </Form>

                    }

                </Formik>


            </div>








        </>
    )
}

export default CreateUsers