import React from "react";
import { Outlet } from "react-router-dom";
import SideBar from "./Sidebar";

function WithSide() {
  return (
    <div className="row" style={{width: '100%'}}>
      <div className="col-md-3">
        <SideBar />
      </div>
      <div className="col-md-9">
        <Outlet />
      </div>
    </div>
  );
}

export default WithSide;
