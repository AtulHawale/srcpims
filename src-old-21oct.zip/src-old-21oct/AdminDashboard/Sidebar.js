import React from 'react';

// import styled from 'styled-components'
// import {Link} from 'react-router-dom'
// import * as FaIcons from 'react-icons/fa';
import * as CgIcons from 'react-icons/cg';
import * as MdIcons from 'react-icons/md';
import * as AiIcons from 'react-icons/ai';
import * as BsIcons from 'react-icons/bs';
// import * as IoIcons from 'react-icons/io';
import * as RiIcons from 'react-icons/ri';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Sidebar.css'
import Logo from "../Logo/TF_Logo.PNG"
import SubMenu from './SubMenu';




const SidebarData = [
  {
    title: 'Home',
    path: '/home',
    icon: <MdIcons.MdDashboard style={{ width: '24px', height: '24px' }} />,
    // iconClosed: <RiIcons.RiArrowDownSFill />,
    // iconOpened: <RiIcons.RiArrowUpSFill />,
  },
  {
    title: 'Protocol',
    path: '/protocol',
    icon: <AiIcons.AiFillCheckSquare style={{ width: '24px', height: '24px' }} />,
    // iconClosed: <RiIcons.RiArrowDownSFill />,
    // iconOpened: <RiIcons.RiArrowUpSFill />,

  },
  {
    title: 'Internal users',
    path: '/internalusers',
    icon: <BsIcons.BsChatSquareTextFill style={{ width: '24px', height: '24px' }} />,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />,
    subNav: [
      {
        title: 'Create user',
        path: '/createuser',

      },
      {
        title: 'Upload users',
        path: '',

      }
    ]
  },
  {
    title: 'External users',
    path: '',
    icon: <CgIcons.CgProfile style={{ width: '24px', height: '24px' }} />,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />,
    subNav: [
      {
        title: 'Create user',
        path: '',

      },
      {
        title: 'Upload users',
        path: '',

      }
    ]
  },
  {
    title: 'Audit',
    path: '/audit',
    icon: <BsIcons.BsFillFileBarGraphFill style={{ width: '24px', height: '24px' }} />
  },
  {
    title: 'Contact us',
    path: '/contact',
    icon: <BsIcons.BsEnvelopeFill style={{ width: '24px', height: '24px' }} />
  },
  {
    title: 'Setting',
    path: '/setting',
    icon: <AiIcons.AiTwotoneSetting style={{ width: '24px', height: '24px' }} />
  },

  // {
  //   title: 'Logout',
  //   path: '',
  //   icon: <IoIcons.IoMdPeople />
  // },


];

const Logout = () => {
  localStorage.clear()


  window.location.href = 'https://aav0112.my.idaptive.app/applogout/appkey/3f986442-dbe0-4d4d-935e-c876390cdb1c/customerid/AAV0112'

}



const SideBar = () => {


  // const [sidebar,setSidebar]= useState(true)

  // const showSidebar=()=>setSidebar(sidebar);

  const navigate = useNavigate();

  window.onpopstate = () => {
    navigate("/admindashboard");
  }
  

  return (
    <>
      {/*        
            <Nav>
                <NavIcon to='#'>
                    <FaIcons.FaBars onClick={showSidebar}/>
                </NavIcon>
            </Nav> */}

      <div className="Sidebar">
        <div className='imageStyle'>
          <img src={Logo} width="166px" height="54px" style={{ marginTop: '64px' }}></img>
        </div>

        <div className='SidebarWrap'>
          {SidebarData.map((item, index) => {
            return <SubMenu item={item} key={index} />
          })}
        </div>

        <button style={{ marginTop: '100px',marginLeft:'20px',border: 'none', outline: 'none', background: '#DD1F25', color: 'white', fontSize: '16px', fontWeight: '700' }} onClick={Logout}><MdIcons.MdLogout style={{ width: '24px', height: '24px',marginRight:'18px' }} />Log out</button>


      </div>


    </>
  )
}

export default SideBar