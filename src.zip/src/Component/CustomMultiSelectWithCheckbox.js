import React, { useState, useEffect, useMemo } from "react";
import styled from "styled-components";
import { ReactComponent as ArrowDown } from "../../src/Logo/input_arrowdown.svg";
import { isEmpty, some, get } from "lodash";
import useOnclickOutside from "react-cool-onclickoutside";
const MultiSelectWrapper = styled.div`
  width: 300px;
  height: 40px;
  position: relative;
  font-family: Helvetica;
  font-size: 16px;

  div:hover{
    color: #212529;
    background-color: #fff;
    border-color: #86b7fe;
    outline: 0;
    box-shadow: 0 0 0 0.25rem rgb(13 110 253 / 25%);
  }

  
`;
const PlaceHolderDiv = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 16px;
  height: 40px;
  border: 1px solid #C8C8C8;
  border-radius: 4px;
  cursor:pointer;
  .select:hover{
    box-shadow:none;

  }
`;
const OptionsPlaceHolder = styled.div`
  max-height: 200px;
  min-width: 100%;
  border: 1px solid #C8C8C8;
  position: absolute;
  top: 35px;
  border-radius: 4px;
  background: white;
  z-index: 1;
  overflow-y: scroll;
  div{
    padding: 5px 16px;
  }
  div:hover{
    background: rgb(13 110 253 / 25%);
    background: rgb(13 110 253 / 25%);
    white-space: nowrap;
  }
  .check-box{
    margin-right: 10px;
    height: 20px;
    width: 20px;
  }
`;
const SearchDiv = styled.input`
  border-radius: 4px;
  padding: 5px 16px;
  border: 1px solid #C8C8C8;
`;

function CustomMultiSelectWithCheckbox({
  options,
  getMultiSelctedItem,
  showCheckbox,
  getseletedCountries,
  showSearch,
  handleSearchItem,
  indexItem,
  defaultOptions,
  setisDisabled

}) {
  const [show, setShow] = useState(false);
  const [selected, setSelected] = useState([]);
  const [searchValue, setSearchValue] = useState("");
  const [searchIndex, setSearchIndex] = useState(0)
  const ref = useOnclickOutside(() => setShow(false));
  const showOptionsPlaceHolder = () => {
    setShow(!show);
  };

  useEffect(() => {
    console.log("going here", getseletedCountries)
    let makeOptionsArray = [...defaultOptions];
    if (getseletedCountries.length > 0) {
      if (!getseletedCountries.includes("Select All")) {
        let newArray = makeOptionsArray.filter((item) =>
          getseletedCountries.some((item2) => item.t__name === item2)
        );
        console.log("newArr", newArray)
        setSelected(newArray);
      } else {
        setSelected(defaultOptions);

      }
    }
    else {

      setSelected([])

    }

  }, [getseletedCountries && getseletedCountries.length, options]);


  const handleItemSelection = (item, index) => {
    console.log("going here 93")
    let selectedArray = [...selected];

    console.log("selected 115", selectedArray)

    let filterSelectAll = selectedArray.filter((item) => item.t__code === "All");

    if (filterSelectAll.length > 0) {

      setSelected([]);

      getMultiSelctedItem([]);



    } else {
      if (!["Select All"].includes(item.t__name)) {
        if (selectedArray.includes(item)) {
          let filtered = selectedArray.filter(
            (sub) => sub.t__name !== item.t__name
          );
          setSelected(filtered);
          getMultiSelctedItem(filtered);
          console.log("going if")
        } else {
          selectedArray.push(item);
          setSelected(selectedArray);
          getMultiSelctedItem(selectedArray);
        }
      } else {
        if (options.length !== selected.length) {
          setSelected(options);
          getMultiSelctedItem(options);
        } else {
          setSelected([]);
          getMultiSelctedItem([]);
        }
      }

    }

  };

  // useEffect(() => {
  //   getMultiSelctedItem(selected);
  //   if(some(selected, {t__name:"All"})){
  //     setSelected(options)
  //   }
  // }, [selected && selected.length]);
  const handleSearch = (e, itemindx) => {
    setSearchValue(e.target.value);
    handleSearchItem(e.target.value, itemindx);

  };
  console.log(" 131 selected", selected)

  return (
    <div>
      <MultiSelectWrapper ref={ref} key={indexItem}>
        <PlaceHolderDiv onClick={showOptionsPlaceHolder}>
          <div className="select">
            {
              selected.length > 1 && selected[0].t__code !== 'All' ?
                <span>
                  {selected && selected.length > 1
                    ? get(selected, "[0].t__name", "") + " + ( " + (selected.length - 1) + " )"
                    : get(selected, "[0].t__name", "")}{" "}
                </span>
                : <span>
                  {selected && selected.length > 1
                    ? "All" + " ( " + (selected.length - 1) + " )"
                    : get(selected, "[0].t__name", "")}{" "}
                </span>
            }

            {selected.length < 1 && <span>{"Select"}</span>}
          </div>

          <ArrowDown />
        </PlaceHolderDiv>

        {show && (
          <OptionsPlaceHolder>
            {showSearch && (
              <SearchDiv
                key={indexItem}
                type="search"
                style={{ width: "100%" }}
                value={searchValue}
                onChange={(e) => handleSearch(e, indexItem)}
                placeholder="Please search"
              />
            )}
            {options &&
              options.map((item, index) => (
                <div onClick={() => handleItemSelection(item, index)} className="d-flex align-items-center">
                  {showCheckbox && (
                    <input
                      type="checkbox"
                      className="check-box"
                      key={index}
                      name={item.t__name}
                      checked={some(selected, { t__name: item.t__name })}
                    />
                  )}
                  {item.t__name}
                </div>
              ))}
          </OptionsPlaceHolder>
        )}
      </MultiSelectWrapper>
    </div>
  );
}

export default CustomMultiSelectWithCheckbox;
