import React, { useState ,useEffect} from "react";
import styled from "styled-components";
import { ReactComponent as ArrowDown } from "../../src/Logo/input_arrowdown.svg";
import { isEmpty } from "lodash";
import useOnclickOutside from "react-cool-onclickoutside";
import { Select } from 'react-select';
const MultiSelectWrapper = styled.div`
  width: ${(props) => (props.width ? props.width : "300px" )};
  height:40px;
  position: relative;
  font-family: Helvetica;
  font-size: 16px;

    div:hover{
    color: #212529;
    background-color: #fff;
    border-color: #86b7fe;
    outline: 0;
    box-shadow: 0 0 0 0.25rem rgb(13 110 253 / 25%);
  }
`;
const PlaceHolderDiv = styled.div`
  height:40px;
  border: 1px solid #C8C8C8;
  border-radius: 4px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px;
  line-height: 16px;
  cursor: pointer;

  .select:hover{
    box-shadow:none;

  }
`;
const OptionsPlaceHolder = styled.div`
  max-height: 200px;
  min-width: 100%;
  border: 1px solid #C8C8C8;
  position: absolute;
  top: 40px;
  overflow-y: scroll;
  border-radius: 4px;
  background: white;
  z-index: 1;
  cursor: pointer;
  div{
    padding: 5px 16px;
  }
  div:hover{
    background: rgb(13 110 253 / 25%);
   
  }
`;

function CustomMultiSelect({
  options,
  getSelctedItem,
  showCheckbox,
  seletedItem,
  optionKey,
  optionValue,
  getSelected,
  width
}) {
  const [show, setShow] = useState(false);
  const [selected, setSelected] = useState({});
  const [multiSelcted, setMultiSelected] = useState([]);
  const ref = useOnclickOutside(() => setShow(false));

  const showOptionsPlaceHolder = () => {
    setShow(!show);
  };

  const handleItemSelection = (item, index) => {
    setShow(false);
    setSelected(item);
    getSelctedItem(item);
  };
 

  console.log("custom selected", selected[optionKey] ,getSelected)
 
  
 
  return (
    <div>
      <MultiSelectWrapper ref={ref} width={width}>
        <PlaceHolderDiv onClick={showOptionsPlaceHolder}>
          <div className="d-flex select" >
           { console.log("consoles", !isEmpty(getSelected))}
          <span>{!isEmpty(getSelected)  ? getSelected : !selected[optionKey] === undefined ? selected[optionKey]: "Select "} </span>
          

          </div>
          
          <ArrowDown />
        </PlaceHolderDiv>
        {show && (
          <OptionsPlaceHolder>
            {options && options.length > 0
              ? options.map((item, index) => (
                  
                  <div onClick={() => handleItemSelection(item, index)} key={index}>
                   
                    { item[optionKey]}
                  </div>
                ))
              :  <span style={{paddingLeft:'16px'}}>No options </span>  }
          </OptionsPlaceHolder>
        )}
      </MultiSelectWrapper>
    </div>
  );
}

export default CustomMultiSelect;
