import React,{useState,useRef} from "react";
import '../AdminDashboard/Pages/CreateUser.css'
import * as HiIcons from 'react-icons/hi';
import * as RiIcons from 'react-icons/ri';
import { ErrorMessage, Field, Form, Formik } from 'formik';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import * as yup from 'yup';
import { Link } from 'react-router-dom'
import Multiselect from 'multiselect-react-dropdown';








const CreateInput = (props)=>{

    const [selectedValue, setSelectedValue] = useState([]);
    var [mcountryvalue, setMcountryvalue] = useState([]);
    const selectvalueref = useRef(null);

 

    const onSelectcountries = (selectedList, selectedItem) => {
        console.log("--", selectedList);
        setSelectedValue(selectedList);
        // console.log("--",selectedItem);
        setMcountryvalue(selectedList.map((val) => {
            return val.key
        }))

    }
    return(
        <><Row>
        <Col>
            <div >
                
                <Field as='select'
                    name="sitenew"
                    placeholder="Select Site"
                    className="form-select"
                    style={{ width: '224px', height: '48px' }}

                >
                    {props.datatrial.map(option => {
                        return (<option key={option.value} value={option.value}>
                            {option.key}
                        </option>
                        )
                    })}
                </Field>
              

            </div>
        </Col>

        <Col>
            <div >
               
                <Multiselect

                    style={{ width: '224px', height: '48px',inputField:{ height: '32px'}, option: { color: "black" }, chips: { background: "grey" } }}

                    onSelect={onSelectcountries}
                    hidePlaceholder={true}
                    placeholder="Select Countries"
                    showCheckbox={true}
                    ref={selectvalueref}
                    options={props.countrydata}
                    showArrow={true}
                    displayValue="key" />

                <p className="text-danger">
                    <ErrorMessage name="countries" />
                </p>

            </div>



        </Col>

        
        <Col style={{ marginRight:'480px' ,marginTop:'8px',width:'26.7px',height:'26.7px'}} ><RiIcons.RiCloseCircleLine style={{width:'26.7px',height:'26.7px'}} /></Col>
        
    </Row></>
    )
}

export default CreateInput;