import React from 'react'
import  styled  from 'styled-components';
import {ReactComponent as ArrowDown} from "../../src/Logo/input_arrowdown.svg"
const SelectWrapper = styled.div`
    height: 40px;
    border: 1px solid #C8C8C8;
    width: 136px;
    border-radius: 4px;


`
const SelectLabel = styled.div`

`

const CustomSelect = () => {
  return (
    <SelectWrapper>
        <SelectLabel>
            <p>select</p>
            <ArrowDown />
        </SelectLabel>
    </SelectWrapper>
  )
}

export default CustomSelect
