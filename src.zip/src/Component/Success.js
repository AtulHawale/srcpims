import { useEffect,useState } from "react"
import axios from "axios";
import { useNavigate } from "react-router-dom";


function Success() {
  const navigate = useNavigate()
  const[userId,setUserId]=useState('')

  
  // window.onpopstate = () => {
  //   navigate("/success");
  // }

  useEffect(() => {
   


    axios({
      method: "get",
      withCredentials: true,
      url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/me",
      headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
    })
      .then((res) => {
        console.log("use effect response headers", res.headers)
        console.log(" response1111", res);
        if (res.status === 200) {
          console.log('200')
          console.log(res && res.data.roles, 'roles')
          console.log(res && res.data._id, 'id')

          if(res.data){
            console.log('id')
            sessionStorage.setItem('user',res.data._id)
            sessionStorage.setItem('role',res.data.roles)
            sessionStorage.setItem('email',res.data.email)
           
          }
          console.log(res && res.data.roles[0])
          if (res && res.data.roles[0] === '000000000000000000000004') {
            console.log('home')
            
            
            // setUserId("shweta")
            // console.log('userid',userId)

            navigate('/home' )
          }
          if (res && res.data.roles[0] === '62f24d4cf8f151c943f90e0b') {
            // sessionStorage.setItem('user',res.data.data[0]._id)
            // sessionStorage.setItem('role',res.data.data[0].roles[0])

            navigate('/internalsitemanagerdashboard')
          }
          if (res && res.data.roles === '62f24d77f8f151c943f91365') {

            // navigate('/internalpatientmanagerdashboard')
          }
         

        }

      })

  })
  return (
    <>
      <p>You are being redirected</p>

    </>
  )
}

export default Success