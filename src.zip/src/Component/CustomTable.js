import React from "react";
import { usePagination, useTable, useSortBy } from "react-table";
import styled from "styled-components";
import * as IoIcons from "react-icons/io";
import * as TiIcons from "react-icons/ti";
import { ReactComponent as Arrowdown } from '../../src/Logo/arrow drop down.svg'


const Pagination = styled.div`
  position: absolute;
  right: 0;
  padding: 15px;
  button {
    border: none !important;
    background: #fff;
    display: inline-block !important;
    font-family: "Helvetica";
    font-style: normal;
    font-weight: 400;
    font-size: 16px;
  }
  font-family: Helvetica;
  font-size: 16px;
`;
const TableContainer = styled.div`
  width: 100%;
  position: relative;
  padding: 0;
 
  table {
    width: 100%;
    min-height:700px;
    font-family: Helvetica;
    font-size: 16px;
    border: none !important;
    table-layout: fixed;
    .new-tooltip .tool-tip {
      max-height: 400px;
    
    opacity: 1;
    white-space: normal;
      visibility: hidden;
      width: 100px;
      background-color: black;
      max-height:400px;
      overflow-y:scroll;
      
      
      color: #fff;
      text-align: center;
      border-radius: 6px;
      padding: 5px 0;
      position: absolute;
      z-index: 1;
      bottom: 80%;
      left: 0;
      cursor: pointer;
      padding: 0 10px;
    }

    .new-tooltip:hover .tool-tip {
      visibility: visible;
    }
  }
  td {
    border-right: none !important;
    border-bottom: 0.5px solid #c8c8c8 !important;
    font-size: 14px;
    position: relative;
    .td-text{
      overflow: hidden;
      text-overflow: ellipsis;
      width: 100%;
    }
  }
  td:last-child{
    padding-right: 0 !important;
    .tool-tip{
      display: none;
    }

  }
  th {
    background:  #E6E6E6;
    height: 40px;
    border: none !important;

    .sort-wrapper{
      display:flex;
      justify-content:space-between;
    }

  }
  th:last-child{
    
    svg{
      display: none;
    }

  }

  .view-edit-button {
    border: 1px solid #c8c8c8;
    background: #fff;
    padding: 8px 16px;
    color: #1e8ae7;
    font-weight: 700;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 32px;
    font-family: "Helvetica";
    font-style: normal;
    width: 100%;
  }
`;
const TableWrapper = styled.div`
@media screen and (max-width: 550px){
  overflow: scroll;
}

`

const CustomTable = ({ columns, data }) => {
  const table = useTable(
    {
      columns,
      data,
      initialState: {
        pageSize: 15,
        pageIndex: 0,
      },
    },
    useSortBy,
    usePagination
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    prepareRow,
    page,
    canPreviousPage,
    canNextPage,
    pageOptions,
    pageCount,
    gotoPage,
    nextPage,
    previousPage,
    setPageSize,
    state: { pageIndex, pageSize },
  } = table;



  return (
    <TableContainer>
      <TableWrapper>

        <table {...getTableProps()}>
          <thead>
            {headerGroups.map((headerGroup) => (
              <tr {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map((column) => (
                  <th {...column.getHeaderProps({
                    style: {  width: column.width },
                  })}

                  ><span className="sort-wrapper" >
                      {column.render("Header")}
                      <span {...column.getHeaderProps(column.getSortByToggleProps(),
                  )}> {column.isSorted ? (column.isSortedDesc ? <Arrowdown style={{ height: '19px', width: '19px' }} /> : <IoIcons.IoMdArrowDropup />) : <TiIcons.TiArrowUnsorted />}</span>
                    </span>

                  </th>
                ))}
              </tr>
            ))}
          </thead>

          <tbody {...getTableBodyProps()}>
            {page.map((row) => {
              prepareRow(row);


              return (
                <tr {...row.getRowProps()}>
                  {row.cells.map((cell) => {
                    return (

                      <td {...cell.getCellProps()} className="new-tooltip">
                        <div className="td-text">{cell.render("Cell")}</div>
                        <span className="tool-tip">{cell.render("Cell")}</span>
                      </td>


                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>

      </TableWrapper>

      <Pagination>
        <div>
          <button onClick={() => previousPage()} disabled={!canPreviousPage}>
            {"<"}
          </button>
          <span>
            <>
              {pageIndex + 1} {"/"} {pageOptions.length}
            </>{" "}
          </span>
          <button onClick={() => nextPage()} disabled={!canNextPage}>
            {">"}
          </button>
        </div>
      </Pagination>
    </TableContainer>
  );
};

export default CustomTable;
