import React from 'react'
import { Outlet } from 'react-router-dom'

function Withoutside() {
  return (
  <>
   <Outlet />
  </>
  )
}

export default Withoutside