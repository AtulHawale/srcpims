import { useEffect, useState } from 'react';

import { Navigate, Outlet ,useNavigate} from 'react-router-dom'

// const useAuth=()=>{
//     const user=sessionStorage.getItem('user')
//     const role=sessionStorage.getItem('role')
//     if(user && role){
//       return true
//     } else {
//       return false
//     }
//   }



const PrivateRoutes = (props) => {
  const [user1, setUser1] = useState(sessionStorage.getItem("user"))
  const [role1, setRole1] = useState(sessionStorage.getItem("role"))
  const [flag, setFlag] = useState(false)
  const navigate = useNavigate()
  useEffect(() => {
    if (user1 && role1) {
      console.log(user1, role1, "userdetails")
      setFlag(true)

    }
    if ( role1=== '000000000000000000000004') {
      console.log('home')

      navigate('/home')
    }
    if (role1 === '62f24d4cf8f151c943f90e0b') {
      

      navigate('/internalsitemanagerdashboard')
    }
   


  











  }, [user1, role1])
  console.log(user1, role1, "userRole")
console.log(sessionStorage.getItem("user"), "user1")
console.log(flag, "flag")




return user1 && role1 ? <Outlet /> : <Navigate to="/" />
}









export default PrivateRoutes