import React, { useEffect, useState } from 'react'
import { ErrorMessage, FastField, Field, Form, Formik, useFormik } from 'formik';
import { useNavigate } from 'react-router'
import * as yup from 'yup';
import Footer from '../Footer/Footer.js';
import { Link } from 'react-router-dom'
import "./Login.css"
import Col from 'react-bootstrap/Col';
import Logo from "../Logo/Logo.svg"
import Row from 'react-bootstrap/Row';
import 'bootstrap/dist/css/bootstrap.min.css';
import OTPPage from './OTPPage.js';
import axios from "axios";
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import OTPPage_External from './OTPPage_External.js'
import SecondComponent from '../Admin/SecondComponent.js';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";


function Login() {
    console.log(" in login page ")

    var t
    const [loginStatus, setLoginStatus] = useState(false)
    // const [loginData, setLoginData] = useState()
    const [loginClicked, setLoginClicked] = useState(false)
    const [logoutStatus, setLogoutStatus] = useState(false)
    const [loginClickedExternal, setLoginClickedExternal] = useState(false)


    const [hidePassword, setHidePassword] = useState(false)
    const [loginStatusForExternal, setLoginStatusForExternal] = useState(false)
    const [externalUserData, setExternalUserData] = useState([])
    const [emailEntered, setEmailEntered] = useState("")
    const [passwordEntered, setPasswordEntered] = useState("")
    const [email, setEmail] = useState("")
    const [message, setMessage] = useState(null)
    const [showOTPScreen, setShowOTPScreen] = useState(false)
    const [sessionExpired, setSessionExpired] = useState(false)
    //const[externalLoginSuccessful,setExternalLoginSuccessful]= useState(false)
    const navigate = useNavigate();

    //  window.onpopstate = () => {
    //     navigate("/");
    //   }



    console.log("login clicked", loginClicked)
    const formInitialSchema = {

        email: '',
        password: '',

    }

    const formValidationSchema = yup.object().shape({

        email: yup.string().required('Email is required').email("Please enter Valid email").matches(
            /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
            , "Please Enter Valid Email"),
        password: hidePassword ? "" : yup.string().required('Password is required'),
    });
    useEffect(() => {
        //handleSessionTimeout()
        axios({
            method: "get",
            url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/orgs?paths[]=_id",
            headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
        })
            .then((res) => {
                console.log("use effect response headers", res.headers)
                console.log(" response1111", res);
            })

    })

    const handleSessionTimeout = () => {
        console.log(" handlesession timeout called ")

        clearTimeout(t)
        document.addEventListener("keydown", handleSessionTimeout)
        document.addEventListener("mousemove", handleSessionTimeout)
        document.addEventListener("touchstart", handleSessionTimeout)
        if (loginClickedExternal) {

            t = setTimeout(() => {
                console.log("inside set timeout")

                if (logoutStatus) {
                    alert(" Your session has expired.  Please Log back in to continue.")
                    // toast.warning("Your session has expired.  Please Login back to continue.", {
                    //     position: toast.POSITION.TOP_CENTER,
                    //   });
                    
                    window.location.reload()
                    //navigate("/")
                    // sessionStorage.clear()
                }
                setSessionExpired(true)
                //var a=console.time('doSomething')

                axios({
                    method: "post",
                    url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/me/logout",
                    data: { "email": emailEntered, "password": passwordEntered },
                    headers: { "medable-client-key": "XAwz1iPreVSkNY0RPaVcSX" },
                })
                    .then((res) => {
                        console.log("logout response headers", res.headers)
                        if (res.status === 200) {
                            if (res.data) {
                                setLogoutStatus(true)
                            }
                        }
                        console.log("logout response", res);
                    })
            }, 5 * 60 * 1000);
        }
    }

    const handleExternalLogin = async (email, password) => {
        try {
            const resp = await axios({
                method: "get",
                url: `https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/validateUser?emailId=${email}`,
                headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
            })

            console.log("Validate user response111 ", resp.data.data.statusCode)
            if (resp.status === 200) {
                if (resp.data.data.statusCode == false) {
                    alert(resp.data.data.message)
                    try {
                        const responseFromEmail = await fetch("https://zbcax1fvhc.execute-api.ap-south-1.amazonaws.com/sendMail", {

                            mode: 'no-cors',
                            method: "post",
                            headers: {
                                Accept: 'application/json',
                                "Content-Type": "application/json",

                            },
                            body: JSON.stringify({
                                "to": email,
                                "subject": "Account Inactive Notification",
                                "htmlbody": ` 
                        <div style="width:600px;height:80px;display:flex;flex-direction:row;
                        border-style:solid;border-color: lightgrey; border-width: thin;">
                                            <div style="background-color:#d91111">
                                            <img src="https://psg-pims.s3.eu-west-1.amazonaws.com/tfslogo/Tsflogo_png.png" style="width:150px ;height:80px" ></img>
                                            </div>
                        
                        
                        
                                           <div style="display:flex;align-items:center;margin-left: 150px;color:black;margin-top:30px">
                                            <div ><b>Account Inactive Notification</b></div>
                                            </div>
                                            </div>
                        
                        
                        
                        <div>
                        <p style="color: black;">

                        Hello ${email},

                        <p style="padding-top:2px ;color: black;">Your account is now inactive due to expired password. </p>

                       

    

                        <p style="padding-top:2px ; color: black;">Please use this link <a href="http://localhost:3000/90days/?Id=${resp.data.data.token}&mail=${email}&id_=${resp.data.data.id}" style="text-decoration:none">[Account Settings] </a>  to update your account. </p>

                          <p style="padding-top:30px ;color: black;">This email is intended for ${email}</p>

                        </p>
                        </div>

                        
                        
                        
                        <div style="width:600px;height:220px;display:flex;flex-direction:row;background-color:rgb(84, 88, 90)">
                        <div style="width:560px;height:180px; font-size: 10px;color: white;margin-left:18px;
                        margin-top:12px
                        ">
                        <div>
                        <p>
                        @2021 Thermo Fisher Scientific Inc. All rights reserved. All trademarks are the <br>
                         property of Thermo Fisher Scientific and its subsidiaries unless otherwise<br>
                          specified <br>
                         <p style="padding-top:6px ;">View Thermo Fisher Scientific's privacy policy</p>
                        
                        
                        Thermo Fisher Scientific<br>
                        168 Third Avenue<br>
                        Wattham , MA 02451<br>
                        United States<br>
                      
                        
                        </p>
                        </div>
                        </div>
                        <div style="width:200px;height:180px;">
                        <img src="https://psg-pims.s3.eu-west-1.amazonaws.com/tfslogo/tfslogofooter.PNG" style="width:130px;padding-top:18px"></img>
                       </div>
                        
                                           
                                            </div>
                      
                       
                        `
                            })


                        })

                    }
                    catch (erroronMail) {
                        console.log(" error in mail", erroronMail)
                    }
                }
            }
            try {
                if (resp.data.data.statusCode) {

                    const responseFromLogin = await axios({
                        method: "post",
                        withCredentials: true,
                        url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/login",
                        data: { "email": email, "password": password },
                        headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
                    })
                    console.log("responseFromLogin", responseFromLogin)
                    if (responseFromLogin.status === 200 || responseFromLogin.status === 403) {

                        console.log("hy")
                        if (responseFromLogin.data) {
                            setExternalUserData(responseFromLogin.data)
                            setMessage(responseFromLogin.message)
                            setLoginClickedExternal(true)
                            sessionStorage.setItem('user', responseFromLogin.data._id) //for successful login

                        }
                        if (responseFromLogin.data.code === 'kNewLocation' || responseFromLogin.data.code === 'kUnverifiedLocation' || responseFromLogin.data.code === 'kLocationClientMismatch') {
                            console.log(" for 200 status but data code")
                            setShowOTPScreen(true) // for showing OTP screen or directly navigating to logged in screen

                        }



                    }

                }
            }
            catch (error) {
                if (error.response.data.code === 'kUnverifiedLocation' || error.response.data.code === 'kLocationClientMismatch') {
                    console.log(" in catch block")
                    setLoginClickedExternal(true)
                    setShowOTPScreen(true) // for showing OTP screen or directly navigating to logged in screen

                }
                if (!(error.response.data.code === 'kUnverifiedLocation' || error.response.data.code === 'kLocationClientMismatch')) {


                    if (error.response.data.errCode === 'cortex.accessDenied.invalidCredentials')
                        alert('Email and/or password is incorrect.  Please try again. ')
                        // toast.success("Email and/or password is incorrect.  Please try again.", {
                        //     position: toast.POSITION.TOP_CENTER,
                        //   });
                }

                console.log(" in catch block")
                // setMessage(err.response.data.message)
                //alert(err.response.data.message)
                console.log("ERRROR", error.response.data.message)
            }


        } catch (err) {
            // Handle Error Here
            console.log('error for Validate user api', err)
            alert(err.response.data.reason)
            // toast.error(err.response.data.reason, {
            //     position: toast.POSITION.TOP_CENTER,
            //   });
        }


    }
    const handleFormSubmit = (values) => {
        setEmailEntered(values.email)
        setPasswordEntered(values.password)
        if (loginStatus) {

            axios({
                method: "get",
                url: `https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/validateUser?emailId=${values.email}`,
                headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
            })
                .then((res) => {
                    console.log("login response internal user", res)
                    if (res.status === 200) {
                        if (res.data.data.message === 'Email is validated Successfully.')

                            window.location.replace('https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/saml2/sp/login?RelayState=http%3A%2F%2Flocalhost%3A3000/success&email=')
                        if (res.data.data.reason === 'User is not active') {
                            alert("User is not active")
                        }
                        // navigate('/home')
                        if (res.data) {
                            // setLoginClicked(true)

                        }
                    }


                })
                .catch((err) => {
                    console.log(err, 'error')
                    if (err.response.data.errCode === 'cortex.invalidArgument.emailAddress')
                        alert('This email address is not linked to an account.  Please work with your clinical study contact ')
                        // toast.error('This email address is not linked to an account.  Please work with your clinical study contact ', {
                        //     position: toast.POSITION.TOP_CENTER,
                        //   });
                    if (err.response.data.errCode === "pims.userNotActive") {

                        alert(err.response.data.reason)
                        // toast.error(err.response.data.reason, {
                        //     position: toast.POSITION.TOP_CENTER,
                        //   });

                    }

                });

        }

        if (loginStatusForExternal) {
            console.log(" external login clicked")
            //Checking valid user for external users 
            handleExternalLogin(values.email, values.password)
        }
        console.log("Submitted value", values)
    }

    return (

        <>
            {
                loginClickedExternal ? showOTPScreen ? <OTPPage_External
                    setLoginClickedExternal={setLoginClickedExternal}
                    email={emailEntered} password={passwordEntered} /> : <SecondComponent /> :



                    loginClicked ? <OTPPage setLoginClicked={setLoginClicked} /> :
                        <div>
                            <div className='imageStyle'>
                                <img src={Logo} width="364px" height="144px"></img>
                            </div>
                            <p className="Header">Login to your Account</p>

                            <div className="form">

                                <Formik initialValues={formInitialSchema}
                                    validationSchema={formValidationSchema}
                                    onSubmit={(values => handleFormSubmit(values))}>
                                    {(props) => (
                                        <Form>
                                            <div >
                                                <label htmlFor="email" className='lab'>Email:</label> <br></br>
                                                <Field type="text"
                                                    name="email"
                                                    value={props.values.email}
                                                    onChange={(e) => {
                                                        setEmail(e.currentTarget.value)
                                                        setLoginStatusForExternal(false)
                                                        setLoginStatus(false)



                                                        if (e.currentTarget.value.includes("@thermofisher.com")) {
                                                            setHidePassword(true)
                                                            setLoginStatus(true)
                                                        }
                                                        if (!(e.currentTarget.value.includes("@thermofisher.com"))) {
                                                            setLoginStatusForExternal(true)

                                                        }
                                                        if (e.currentTarget.value === "" || (!e.target.value.includes("@thermofisher.com"))) {
                                                            setHidePassword(false)
                                                        }
                                                        ; props.handleChange(e)
                                                    }}
                                                    placeholder="Enter Email"
                                                    className="form-control" />
                                                <p className="text-danger">
                                                    <ErrorMessage name="email" />
                                                </p>
                                            </div>
                                            {/* <div className='Forgot'>
                                    <a>Forgot Password</a>
                                </div> */}

                                            {hidePassword === false ?
                                                <div>
                                                    <Row>
                                                        <Col> <label htmlFor="password" className='lab'>Password:</label></Col>
                                                        <Col style={{ paddingLeft: "90px" }}><label className='Forgot'>
                                                            <Link style={{ textDecoration: 'none' }} to="/forgotpassword">Forgot Password?</Link>
                                                        </label></Col>
                                                    </Row>
                                                    <Field type="password"
                                                        name="password"
                                                        placeholder="Enter Password"
                                                        className="form-control" />
                                                    <p className="text-danger">
                                                        <ErrorMessage name="password" />
                                                    </p>
                                                </div> :
                                                <div></div>
                                            }
                                            <br></br>
                                            <div>
                                                <button className="button"
                                                    type="submit"
                                                >Login
                                                </button>
                                            </div>
                                        </Form>)
                                    }

                                </Formik>
                                <Footer></Footer>
                            </div>
                            <ToastContainer limit ={1} />
                        </div>
            }
        </>
    )
}

export default Login

