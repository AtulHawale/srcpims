import React, { useEffect, useState } from "react";
import { ErrorMessage, Field, Form, Formik } from 'formik';
import * as yup from 'yup';
import Footer from "../Footer/Footer.js"
import Logo from "../Logo/Logo.svg"
import axios from "axios";
import './ResetPassword.css'
import { useNavigate,useLocation} from 'react-router'
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";


function ResetPassword() {
    const navigate = useNavigate();
    const[receivedToken,setReceivedToken]=useState('')
    const [emailEntered, setEmailEntered]= useState('')
    window.onpopstate = () => {
        navigate("/forgotpassword");
      }
      const location = useLocation();
      
      useEffect(() => {
        // if(location && location.state && location.state.data){
        //     setReceivedToken(location.state.data)
        // }
        const id = new URLSearchParams(location.search).get('Id')
        const mail = new URLSearchParams(location.search).get('mail')
        setReceivedToken(id)
        setEmailEntered(mail)
       
          console.log(" location props", location);
        
      });

    const formInitialSchema = {

        password: '',
        confirmpassword: '',

    }
    const formValidationSchema = yup.object().shape({

        password: yup.string().required('Password is required').matches(

            /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,

            "Does not match with below Criteria"

        ).test('test1', "Does not match with below Criteria", (value) => validate(value)).test('test2', "Does not match with below Criteria", (value) => validate2(value)).required('Password is required'),
        confirmpassword: yup.string().oneOf([yup.ref('password'), null], "Passwords do not match").required('Password is required')
    });

    function validate(pass) {
        console.log("validate called")

        var str = pass;
        var arr = ["2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032", "2033", "2034", "2035", "appliedbio", "fei", "fisher", "invitrogen", "lifetech", "patheon", "thermo"];

        if (str) {
            for (var i in arr) {
                var b = str.indexOf(arr[i]);
                if (b >= 0) {
                    console.log("invalid string");
                    return false;
                }
            }
        }

        return true;
    }


    const validate2 = (val) => {
        let result = [];
        var str = [val];

        if (val) {

            str.map(each => {
                let repeatedChars = 0;
                for (let i = 0; i < each.length - 1; i++) {
                    if (each[i] === each[i + 1] && each[i] === each[i - 1] && each[i] === each[i + 2]) {

                        repeatedChars += 1;
                    }
                }

                result.push(repeatedChars);
                console.log("repeatedChars", repeatedChars);

            });

            if (result[0] > 0) {
                return false
            }
            else {
                return true;
            }
        }
    };

    function handleEmail() {
console.log(" handle email called in reset password", emailEntered)
       

        console.log("handleEmail called")
        fetch("https://zbcax1fvhc.execute-api.ap-south-1.amazonaws.com/sendMail", {

            mode: 'no-cors',
            method: "post",
            headers: {
                Accept: 'application/json',
                "Content-Type": "application/json",

            },
            body: JSON.stringify({
                "to": emailEntered,
                "subject": "Account Updated",
                "htmlbody": ` 
                    <div style="width:600px;height:80px;display:flex;flex-direction:row;
                    border-style:solid;border-color: lightgrey; border-width: thin;">
                                        <div style="background-color:#d91111">
                                        <img src="https://psg-pims.s3.eu-west-1.amazonaws.com/tfslogo/Tsflogo_png.png" style="width:150px ;height:80px" ></img>
                                        </div>
                    
                    
                    
                                       <div style="display:flex;align-items:center;margin-left: 150px;color:black;margin-top:30px">
                                        <div ><b>Account Updated</b></div>
                                        </div>
                                        </div>
                    
                    
                    
                    <div>
                    <p style="color: black;">
                    Hello ${emailEntered},
                    <p style="padding-top:2px ;color: black;">Your account has been updated.</p>
                    <p style="padding-top:2px ; color: black;">If updates are incorrect, please contact us immediately by replying to this email.<br> Note: Account updates include user setting/password changes and protocol permissions.</p>
                    
                   
                    
                    
                    <p style="padding-top:30px ;color: black;">This email is intended for ${emailEntered}</p>
                    
                    
                    
                    </p>
                    </div>
                    
                    
                    
                    <div style="width:600px;height:220px;display:flex;flex-direction:row;background-color:rgb(84, 88, 90)">
                    <div style="width:560px;height:180px; font-size: 10px;color: white;margin-left:18px;
                    margin-top:12px
                    ">
                                        <div>
                                        <p>
                                        @2021 Thermo Fisher Scientific Inc. All rights reserved. All trademarks are the <br>
                                         property of Thermo Fisher Scientific and its subsidiaries unless otherwise<br>
                                          specified <br>
                                         <p style="padding-top:6px ;">View Thermo Fisher Scientific's privacy policy</p>
                                        
                                        
                                        Thermo Fisher Scientific<br>
                                        168 Third Avenue<br>
                                        Wattham , MA 02451<br>
                                        United States<br>
                                      
                                        
                                        </p>
                                        </div>
                                        </div>
                                        <div style="width:200px;height:180px;">
                                        <img src="https://psg-pims.s3.eu-west-1.amazonaws.com/tfslogo/tfslogofooter.PNG" style="width:130px;padding-top:18px"></img>
                                       </div>
                    
                    
                    
                                       
                                        </div>
                  
                   
                    `
            })


        })







    }

    const handleFormSubmit = (values) => {
        console.log("Submitted values", values)
        axios({
            method: "post",
            withCredentials:true,
            url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/reset-password",
            data: { "token": receivedToken, "password":values.password },
             headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
        })
        .then((res) => {
            console.log("login response headers", res.headers)
            if (res.status === 200) {
                if(res.data){
                    // toast.success("Your password has been reset", {
                    //     position: toast.POSITION.TOP_CENTER,
                    //   });
                    alert("Your password has been reset")
                console.log(res,"hy")
                handleEmail()
                }
               
               
             

               
            }
            console.log("login response", res);
        })
        .catch((err) => {
            console.log(err.response.data.message,'error')
            alert(err.response.data.message)
            
           
            
        });

        // navigate('/')
    }


    return (
        <>
         <div className='imageStyle'>
                <img  src={Logo} width="364px" height="144px"></img>
                </div>
            <h2 className="Header">Reset Password</h2>


            <div className="form">

                <Formik initialValues={formInitialSchema}
                    validationSchema={formValidationSchema}
                    onSubmit={(values => handleFormSubmit(values))}>
                    {({ values }) =>
                        <Form>

                            <div >
                                <label htmlFor="password" className='lab'>Password:</label>
                                <Field type="password"

                                    name="password"
                                    placeholder="Enter your Password"
                                    className="form-control" />
                                <p className="text-danger">
                                    <ErrorMessage name="password" />
                                </p>
                            </div>





                            <div >
                                <label htmlFor="confirmpassword" className='lab'>Confirm Password:</label>
                                <Field type="password"
                                    name="confirmpassword"
                                    placeholder="Confirm Password"
                                    className="form-control" />
                                <p className="text-danger">
                                    <ErrorMessage name="confirmpassword" />
                                </p>
                            </div> 

                            <div className='instruction' >
                                <ul>

                                    <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain at least 8 characters</span></li>
                                    <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain an uppercase letter</span></li>
                                    <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain a lowercase letter</span></li>
                                    <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain a number</span></li>
                                    <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain a symbol</span></li>
                                    <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must not contain consecutive letters or numbers<span className='l'>i.e. 1111 or bbbb</span></span></li>
                                    <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must not contain any of the following <p><span>brand names:appliedbio, fei, fisher,invitrogen,</span><span> lifetech, patheon, thermo</span></p></span></li>



                                </ul>
                            </div>

                            <div>
                                <button className="button10"
                                    type="submit"
                                >Confirm
                                </button>
                            </div>
                           




                        </Form>


                    }

                </Formik>
                <ToastContainer limit ={1} />



            </div>


        </>
    )
}

export default ResetPassword