import React, { useState, useEffect } from 'react'
import { ErrorMessage, Field, Form, Formik } from 'formik';
import * as yup from 'yup';
import Modal from 'react-bootstrap/Modal';
import './ForgotPassword.css'
import Footer from '../Footer/Footer.js';
import Logo from "../Logo/Logo.svg"

import { Navigate } from 'react-router-dom';
import { useNavigate, Link } from "react-router-dom"
import axios from 'axios';
import Button from 'react-bootstrap/Button';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";




var data = [
];






//var qdata= [...data];


function ForgotPassword() {

    const [email, setEmail] = useState("");
    const [cemail, setCemail] = useState("");
    const [counter, setCounter] = useState(0);
    const [cnt, setCnt] = useState(0);
    const navigate = useNavigate();
    const [apicounter, setApicounter] = useState(0);
    const [show, setShow] = useState(0);
    const [showinvalid, setShowinvalid] = useState(0);
    const [qdata, setQdata] = useState([]);
    const [validuser, setValiduser] = useState(0);
    const [emailEntered, setEmailEntered] = useState("");
    const [tokenReceived, setTokenReceived] = useState("");

    window.onpopstate = () => {
        navigate("/");
    }



    const formInitialSchema = {

        email: '',
        confirmemail: '',
        selectQ: '',
        answer: ''

    }

    const [selectQ, setSelectQ] = useState("");
    const [showmsg, setShowmsg] = useState(0);
    const [backdata, setBackdata] = useState(false);





    useEffect(() => {
        if (cnt > 0) {
            if (data.length > 1) {
                console.log("database will delete now");
                let index1 = data.findIndex(item => item.key === selectQ)
                data.splice(index1, 1);
                //setShowmsg(0);
                qdata = [...data];
                setCnt(0);
                if (qdata.length == 1) {
                    alert("contact administrator");
                }
            }

        }

    }, [cnt])

    const handleClose = () => {
        setShow(0);
        setShowinvalid(0);
    }


    /*useEffect(()=>{
        if(backdata)
        {

        
        const headers = {
            'Medable-Client-Key': 'EYKm5YLKZjjRNi7MDkqxA3',
            'Origin': 'https://api.dev.medable.com'
          }
        axios.get(`https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/validateUser?emailId=atulsai78@gmail.com`,{
            headers: headers
          }).then((res)=>{
              console.log("response from backend",res.data.data);
              var resqdata = res.data.data;
              var resdata=[
                {key:'Select option',value:'',},
                {key:resqdata.t__security_questions_1,value:resqdata.t__security_questions_1,},
                {key:resqdata.t__security_questions_2,value:resqdata.t__security_questions_2,},
                {key:resqdata.t__security_questions_3,value:resqdata.t__security_questions_3,}

              ]
              console.log("response from backend resdata",resdata);
              data = [...resdata];
              qdata=[...resdata];

              
            }).catch((err)=>{
              console.log(err);
              alert("create account failed :")
          });
            setCounter(1);
        }

    },[backdata]);*/

    const formValidationSchema = yup.object().shape({


        email: yup.string().email("Please enter Valid email").required('Email is required').test('test4', "You are internal user,Please contact Administrator", (value) => validate(value)).matches(
            /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
            , "Please Enter Valid Email"),
        confirmemail: yup.string().oneOf([yup.ref('email'), null], "Email does not match").email("Please enter Valid email").required('Confirm Email is required'),
        selectQ: yup.string().required('Select Question is required'),
        answer: yup.string().required('Answer is required'),

    });

    const validate = (em) => {
        if (em) {
            if (em.includes("@thermofisher.com")) {
                return false;
            }
            else {
                return true;
            }
        }


    }

    const clickonemail = (v) => {
        const headers = {
            'Medable-Client-Key': 'EYKm5YLKZjjRNi7MDkqxA3',
            'Origin': 'https://api.dev.medable.com'
        }

        if (email != v) {
            setCounter(0);
        }

        if (counter == 0) {

            if (email == v) {
                console.log("security q aanedo======================");
                //setBackdata(true);

                axios.get(`https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/validateEmail?emailId=${email}`, {
                    headers: headers
                }).then((res) => {
                    console.log("response from backend", res.data.data);
                    var resqdata = res.data.data;
                    var resdata = [
                        { key: 'Select option', value: '', },
                        { key: resqdata.t__security_questions_1, value: resqdata.t__security_questions_1, },
                        { key: resqdata.t__security_questions_2, value: resqdata.t__security_questions_2, },
                        { key: resqdata.t__security_questions_3, value: resqdata.t__security_questions_3, }

                    ]
                    console.log("response from backend resdata", resdata);
                    setQdata(resdata);
                    setValiduser(1);
                    //data = [...resdata];
                    //qdata=[...resdata];


                }).catch((err) => {
                    console.log(err, "err1");
                    if (err.response.data.errCode === "cortex.invalidArgument.emailAddress") {
                        alert('Invalid EmailId, Please enter correct EmailId')

                    }

                    //setShow(1);
                    setShowinvalid(1);
                    //alert("Your Email Id is Not Register:Please Contact Administrator")
                });
                setCounter(1);
            }
        }
        console.log("click on mail working", email, cemail, v);
    }

    function handleEmail(emailreceived, tokengenerated) {

        // console.log(emailEntered, tokenReceived, "email")


        console.log("handleEmail called")
        fetch("https://zbcax1fvhc.execute-api.ap-south-1.amazonaws.com/sendMail", {

            mode: 'no-cors',
            method: "post",
            headers: {
                Accept: 'application/json',
                "Content-Type": "application/json",

            },
            body: JSON.stringify({
                "to": emailreceived,
                "subject": "Reset Password",
                "htmlbody": ` 
                    <div style="width:600px;height:80px;display:flex;flex-direction:row;
                    border-style:solid;border-color: lightgrey; border-width: thin;">
                                        <div >
                                        <img src="https://psg-pims.s3.eu-west-1.amazonaws.com/tfslogo/Tsflogo_png.png" style="width:150px ;height:80px" ></img>
                                        </div>
                    
                    
                    
                                       <div style="display:flex;align-items:center;margin-left: 150px;color:black;margin-top:30px">
                                        <div ><b>Activate Account</b></div>
                                        </div>
                                        </div>
                    
                    
                    
                    <div>
                    <p style="color: black;">
                    Hello ${emailreceived},
                    <p style="padding-top:2px ;color: black;">Your account has been reset on PIMS.</p>
                    <p style="padding-top:2px ; color: black;">Please use this link <a href="http://localhost:3000/reset/?Id=${tokengenerated}&mail=${emailreceived}" style="text-decoration:none">[Account Settings] </a>  to update your user account access settings. The link is only<br> valid for 48 hours and require your immediate attention.</p>
                    <p style="padding-top:2px ; color: black;">If you did not request account reset or the link has expired, please contact us immediately by<br>  replying to this email.
                    </p>
                    
                    
                    <p style="padding-top:30px ;color: black;">This email is intended for ${emailreceived}</p>
                    
                    
                    
                    </p>
                    </div>
                    
                    
                    
                    <div style="width:600px;height:220px;display:flex;flex-direction:row;background-color:rgb(84, 88, 90)">
                    <div style="width:560px;height:180px; font-size: 10px;color: white;margin-left:18px;
                    margin-top:12px
                    ">
                                        <div style="color: white">
                                        <p>
                                        @2021 Thermo Fisher Scientific Inc. All rights reserved. All trademarks are the <br>
                                         property of Thermo Fisher Scientific and its subsidiaries unless otherwise<br>
                                          specified <br>
                                         <p style="padding-top:6px ;">View Thermo Fisher Scientific's privacy policy</p>
                                        
                                        
                                        Thermo Fisher Scientific<br>
                                        168 Third Avenue<br>
                                        Wattham , MA 02451<br>
                                        United States<br>
                                      
                                        
                                        </p>
                                        </div>
                                        </div>
                                        <div style="width:200px;height:180px;">
                     <img src="https://psg-pims.s3.eu-west-1.amazonaws.com/tfslogo/tfslogofooter.PNG" style="width:130px;padding-top:18px"></img>
                    </div>
                    
                    
                    
                                       
                                        </div>
                  
                   
                    `
            })


        })







    }
    const handleFormSubmit = (values) => {
        console.log("Submitted values", values)
        setEmailEntered(values.email)
        const headers2 = {
            'Medable-Client-Key': 'EYKm5YLKZjjRNi7MDkqxA3',
            'Origin': 'https://api.dev.medable.com'
        }

        let index = qdata.findIndex(item => item.key === values.selectQ)
        console.log("index", index);
        /* console.log("database",qdata);
         console.log("select q",values.selectQ);
 
         let index = qdata.findIndex(item=>item.key === values.selectQ)
         console.log("index",index);
         console.log("actual ans",qdata[index].answer);*/
        if (index == 1) {
            var validatedata = {
                "email": values.email,
                "t__security_questions_1": values.selectQ,
                "t__confirm_answer_1": values.answer
            }

        }


        if (index == 2) {
            var validatedata = {
                "email": values.email,
                "t__security_questions_2": values.selectQ,
                "t__confirm_answer_2": values.answer
            }

        }

        if (index == 3) {
            var validatedata = {
                "email": values.email,
                "t__security_questions_3": values.selectQ,
                "t__confirm_answer_3": values.answer
            }

        }

        console.log("validate data", validatedata);




        /*var validatedata = {
            "email": "atulsai78@gmail.com",
            "t__security_questions_1": "What is name of your brother?",
            "t__confirm_answer_1": "amol"
        }*/

        console.log("validate data to pass", validatedata);
        if (apicounter < 3) {
            axios.post("https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/verifyUser", validatedata, {
                headers: headers2
            }).then((res) => {
                console.log("response from backend", res);

                console.log(res.data.data.token, "token")
                if (res.status === 200 && res.data.data.message === "User is verified.") {
                    console.log("ANSWER IS RIGHT")
                    alert("Email is sent to your email id to reset password")

                    // toast.success("Email is sent to your email id to reset password", {
                    //     position: toast.POSITION.TOP_CENTER,
                    //   });

                    // setTokenReceived(res.data.data.token)
                    // console.log(emailEntered,tokenReceived,"dddgfhjk")
                    handleEmail(values.email, res.data.data.token)


                    // navigate("/reset" ,{state:{data:res.data.data.token}})
                }
                if (res.data.data.message === "User is not verified.") {
                    console.log('ANSWER IS WRONG')
                    setApicounter(apicounter + 1);
                    //qdata.splice(index,1);
                    setShowmsg(1);
                    if (apicounter == 2) {
                        // toast.error("Your account is now inactivated.  Please work with your clinical study contact", {
                        //     position: toast.POSITION.TOP_CENTER,
                        //   });
                        alert("Your account is now inactivated. Please work with your clinical study contact")
                        setShow(1);
                    }
                    //setCnt(1);
                    if (qdata.length == 1) {
                        // toast.error("please contact administrator", {
                        //     position: toast.POSITION.TOP_CENTER,
                        //   });
                        alert("Please contact administrator")
                        
                    }
                }


            }).catch((err) => {
                console.log(err, 'err');
                console.log(err.response.data.reason, "errresponse");
                if (err.response.data.reason === "User is not verified") {
                    console.log('ANSWER IS WRONG')
                    setApicounter(apicounter + 1);
                    //qdata.splice(index,1);
                    setShowmsg(1);


                    if (apicounter == 2) {
                        // toast.error("Your account is now inactivated. Please work with your clinical study contact", {
                        //     position: toast.POSITION.TOP_CENTER,
                        //   });
                        alert("Your account is now inactivated. Please work with your clinical study contact")
                        setShow(1);
                    }
                    //setCnt(1);
                    if (qdata.length == 1) {
                        // toast.error("Your account is now inactivated. Please work with your clinical study contact", {
                        //     position: toast.POSITION.TOP_CENTER,
                        //   });
                        alert("Your account is now inactivated. Please work with your clinical study contact")
                    }






                }
                else {
                    alert(err);
                }

            });

        }
        else {
            // toast.error("Your account is now inactivated. Please work with your clinical study contact", {
            //     position: toast.POSITION.TOP_CENTER,
            //   });
             alert("Your account is now inactivated. Please work with your clinical study contact")
        }




        //if(qdata[index].answer.toLowerCase() === values.answer.toLowerCase())



    }

    return (
        <>
            <div >
                    <div className='imageStyle'>
                    <img src={Logo} width="364px" height="144px"></img>
                </div>
                <p className="Header">Forgot Password?</p>


                <div className="form">

                    <Formik initialValues={formInitialSchema}
                        validationSchema={formValidationSchema}
                        onSubmit={(values => handleFormSubmit(values))}>
                        {formik =>
                            <Form>

                                <div >
                                    <label htmlFor="email" className='lab'>Email:</label> <br></br>
                                    <Field type="text"
                                        name="email"
                                        placeholder="Enter your Email"
                                        onChange={(e) => {
                                            setEmail(e.target.value)

                                            formik.handleChange(e);
                                        }}
                                        className="form-control" />
                                    <p className="text-danger">
                                        <ErrorMessage name="email" />
                                    </p>
                                </div>

                                <div >
                                    <label htmlFor="confirmemail" className='lab'>Confirm Email:</label><br></br>
                                    <Field type="text"
                                        name="confirmemail"
                                        placeholder="Confirm Email"
                                        onChange={(e) => {
                                            setCemail(e.target.value)
                                            clickonemail(e.target.value);
                                            formik.handleChange(e);
                                        }
                                        }
                                        className="form-control" />
                                    <p className="text-danger">
                                        <ErrorMessage name="confirmemail" />
                                    </p>
                                </div>






                                {counter && validuser ? <div >
                                    <label htmlFor="selectQ" className='lab'>Select Security Question:</label> <br></br>
                                    <Field as='select'
                                        id="1"
                                        name="selectQ"
                                        className="form-select"
                                        onChange={(e) => {
                                            setSelectQ(e.currentTarget.value);
                                            setShowmsg(0);
                                            formik.handleChange(e);
                                        }
                                        }
                                    >
                                        
                                        {qdata.map(option => {
                                            return (<option key={option.value} value={option.value}>
                                                {option.key}
                                            </option>
                                            )
                                        })}
                                         
                                    </Field>
                                    <p className="text-danger">
                                        <ErrorMessage name="selectQ" />
                                    </p>
                                    <div >
                                        <label htmlFor="answer" className='lab'>Confirm Answer:</label> <br></br>
                                        <Field type="text"
                                            name="answer"
                                            placeholder="Confirm Answer"
                                            onChange={(e) => {

                                                setShowmsg(0);
                                                formik.handleChange(e);
                                            }
                                            }
                                            className="form-control"/>
                                        <p className="text-danger">
                                            <ErrorMessage name="answer" />
                                            {showmsg ? <div><div>Incorrect answer. </div>
                                                <div>Please select a different question </div></div> : null}
                                        </p>
                                    </div>
                                </div>
                                    : null}
                                <br></br>

                                <div>
                                    <button className="button"
                                        type="submit"
                                    >Send Reset Instruction
                                    </button>
                                </div>


                            </Form>
                        }

                    </Formik> <br></br> <br></br>
                    {/* {show?<Modal show={show} onHide={handleClose}>
        <Modal.Header >
          <Modal.Title>Contact Administrator</Modal.Title>
        </Modal.Header>
        <Modal.Body>Your account is now inactivated.  Please work with your clinical study contact.</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>:null}

      {showinvalid?<Modal show={showinvalid} >
       
        <Modal.Body>Invalid EmailId, Please enter correct EmailId</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>:null} */}
                    <Footer></Footer>


                </div><ToastContainer limit ={1}/>
        



            </div>




        </>
    )
}


export default ForgotPassword