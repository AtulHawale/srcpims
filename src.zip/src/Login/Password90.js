import React, { useState,useEffect } from 'react'
import { ErrorMessage, Field, Form, Formik, useFormik } from 'formik';
import * as yup from 'yup';
//import Form from 'react-bootstrap/Form'
import './Password90.css'
// import Footer from '../Footer/Footer.js';
import { useNavigate,useLocation} from "react-router-dom"

import Logo from "../Logo/Logo.svg"
import axios from 'axios'
import Footer from '../Footer/Footer.js';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import * as AiIcons from 'react-icons/ai';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
//import crypto from 'crypto'
//import request from 'request'


//import Select from '../Select/Select';

const dropdownoptions = [
    { key: 'Select option', value: '' },
    { key: 'what is your name', value: 'what is your name?' },
    { key: 'who is your hero', value: 'who is your hero?' },
    { key: 'what is your nick name', value: 'what is your nick name?' },
    { key: 'In what city were you born', value: 'In what city were you born?' },
    { key: 'What high school did you attend?', value: 'What high school did you attend?' },
    { key: 'What was the name of your elementary school?', value: 'What was the name of your elementary school?' },
    { key: 'What was the make of your first car?', value: 'What was the make of your first car?' },
    { key: 'Where did you meet your spouse?', value: 'Where did you meet your spouse?' },
    { key: 'What year was your father (or mother) born?', value: 'What year was your father (or mother) born?' },
    { key: 'What is name of your mother', value: 'What is name of your mother?' },
    { key: 'What is name of your father', value: 'What is name of your father?' },
    { key: 'What is name of your brother', value: 'What is name of your brother?' },
    { key: 'What is name of your friend', value: 'What is name of your friend?' },
    { key: 'What is name of your sister', value: 'What is name of your sister?' },
    { key: 'What is name of your pet', value: 'What is name of your pet?' },
    { key: 'What is name of your teacher', value: 'What is name of your teacher?' },
    { key: 'What is name of your uncle', value: 'What is name of your uncle?' },
    { key: 'What is name of your aunty', value: 'What is name of your aunty?' },
    { key: 'What is name of your godfather', value: 'What is name of your godfather?' },
    { key: 'What is name of your wife', value: 'What is name of your wife?' },



]

function Password90() {
    const formInitialSchema = {
        email: '',
        password: '',
        confirmpassword: '',
        selectOption1: '',
        answer1: '',
        selectOption2: '',
        answer2: '',
        selectOption3: '',
        answer3: '',
        mobilenumber: ''
    }

    const checkchar = /^(?!.*(appliedbio|fei|fisher|invitrogen|lifetech|patheon|thermo))/
    const checkyear = /(0{3}\d|00[1-9]\d|0[1-9]\d{2}|1\d{3}|200\d|201[0-4])|(203[6-9]|20[4-9]\d|2[1-9]\d{2}|[3-9]\d{3}|10000)/



    const navigate = useNavigate();
    const location =useLocation();
    const [selectOption1, setSelectOption1] = useState('');
    const [selectOption2, setSelectOption2] = useState('');
    const [selectOption3, setSelectOption3] = useState('');
    const[receivedToken,setReceivedToken]=useState('')
    const [emailEntered, setEmailEntered]= useState('')
    const [objectId, setObjectId]= useState('')

    const [generatedToken, setGeneratedToken]= useState("")

    window.onpopstate = () => {
        navigate("/");
      }

      useEffect(() => {
        axios({
            method: "get",
                url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/generateToken",
                headers: { "medable-client-key": "Q4dVKqZz85inZ65ceF1vpm" },
        })
        .then((res) => {
            console.log("use effect response headers", res.headers)
            console.log(" response1111", res);
            setGeneratedToken(res.data.data)
        })

        const id = new URLSearchParams(location.search).get('id_')
        const token= new URLSearchParams(location.search).get('Id')
        const mail = new URLSearchParams(location.search).get('mail')
        console.log(" object id ", id)


      setObjectId(id)
      setReceivedToken(token)
      setEmailEntered(mail)

        // // const id = new URLSearchParams(location.search).get('Id')
       
        // // const objectId = new URLSearchParams(location.search).get('id_')
        // setReceivedToken(id)
        
        // setObjectId(objectId)

        
      },[]);






    const handleoptionchange1 = (opt) => {
        setSelectOption1(opt)

    }
    const handleoptionchange2 = (opt) => {
        setSelectOption2(opt)

    }
    const handleoptionchange3 = (opt) => {
        setSelectOption3(opt)

    }


    const formValidationSchema = yup.object().shape({

        // email: yup.string().required('Email is required').email("Please enter Valid email").matches(
        //     /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
        //     , "Please Enter Valid Email"),
        password: yup.string().required('Password is required').matches(

            /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,

            "Does not match with below Criteria"

        ).test('test1', "Does not match with below Criteria", (value) => validate(value)).test('test2', "Does not match with below Criteria", (value) => validate2(value)).required('Password is required'),
        confirmpassword: yup.string().oneOf([yup.ref('password'), null], "Password does not match").required('Confirm Password is required'),
        //selectOption1: yup.string().required('Option is required'),
        selectOption1: yup.string().notOneOf([
            yup.ref('selectOption2'),
            yup.ref('selectOption3')
        ], "Should be a different question").required('Option is required'),
        selectOption2: yup.string().notOneOf([
            yup.ref('selectOption1'),
            yup.ref('selectOption3')
        ], "Should be a different question").required('Option is required'),
        selectOption3: yup.string().notOneOf([
            yup.ref('selectOption2'),
            yup.ref('selectOption1')
        ], "Should be a different question").required('Option is required'),
        answer1: yup.string().required('Answer is required'),
        answer2: yup.string().required('Answer is required'),
        answer3: yup.string().required('Answer is required'),
        mobilenumber : yup.string().required('Mobile number is required')



    });

    function validate(pass) {
        console.log("validate called")

        var str = pass;
        var arr = ["2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032", "2033", "2034", "2035", "appliedbio", "fei", "fisher", "invitrogen", "lifetech", "patheon", "thermo"];

        if (str) {
            for (var i in arr) {
                var b = str.toLowerCase().indexOf(arr[i]);
                if (b >= 0) {
                    console.log("invalid string");
                    return false;
                }
            }
        }

        return true;
    }


    const validate2 = (val) => {
        let result = [];
        var str = [val];

        if (val) {

            str.map(each => {
                let repeatedChars = 0;
                for (let i = 0; i < each.length - 1; i++) {
                    if (each[i] === each[i + 1] && each[i] === each[i - 1] && each[i] === each[i + 2]) {

                        repeatedChars += 1;
                    }
                }

                result.push(repeatedChars);
                console.log("repeatedChars", repeatedChars);

            });

            if (result[0] > 0) {
                return false
            }
            else {
                return true;
            }
        }
    };

    const handleConfirm=async (createdata,password)=>{
        console.log(" in handle confirm function ", password)
        console.log(" in handle confirm function1111 ", `https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/${[objectId]}`)
        console.log(" payload", createdata)
        try {
            const resp = await axios({
                method: "put",
                withCredentials:true,
                url: `https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/${[objectId]}`,
                data:  createdata,
                headers: { "medable-client-key": "Q4dVKqZz85inZ65ceF1vpm" ,
            
        "Authorization":"Bearer "+generatedToken },
            })
            console.log(" response from update api",resp )
            if(resp.status===200){
                
                  try{
                    const responsefromReset=  await axios({
                        method: "post",
                        withCredentials:true,
                        url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/reset-password",
                        data: { "token": receivedToken, "password":password },
                         headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
                    })
                    console.log("GGGGGGGG", responsefromReset)
                    if(responsefromReset.status==200){
                        // toast.success("Your password has been reset", {
                        //     position: toast.POSITION.TOP_CENTER,
                        //   });

                        alert("Your password has been reset")
                       
                        console.log(" response from reset password", responsefromReset)

                        try{
                            const responseFromEmail= await fetch("https://zbcax1fvhc.execute-api.ap-south-1.amazonaws.com/sendMail", {
                    
                                mode: 'no-cors',
                                method: "post",
                                headers: {
                                    Accept: 'application/json',
                                    "Content-Type": "application/json",
                    
                                },
                                body: JSON.stringify({
                                    "to": emailEntered,
                                    "subject": "Account Updated",
                                    "htmlbody": ` 
                                        <div style="width:600px;height:80px;display:flex;flex-direction:row;
                                        border-style:solid;border-color: lightgrey; border-width: thin;">
                                                            <div style="background-color:#d91111">
                                                            <img src="https://psg-pims.s3.eu-west-1.amazonaws.com/tfslogo/Tsflogo_png.png" style="width:150px ;height:80px" ></img>
                                                            </div>
                                        
                                        
                                        
                                                           <div style="display:flex;align-items:center;margin-left: 150px;color:black;margin-top:30px">
                                                            <div ><b>Account Updated</b></div>
                                                            </div>
                                                            </div>
                                        
                                        
                                        
                                        <div>
                                        <p style="color: black;">
                                        Hello ${emailEntered},
                                        <p style="padding-top:2px ;color: black;">Your account has been updated.</p>
                                        <p style="padding-top:2px ; color: black;">If updates are incorrect, please contact us immediately by replying to this email.<br> Note: Account updates include user setting/password changes and protocol permissions.</p>
                                        
                                       
                                        
                                        
                                        <p style="padding-top:30px ;color: black;">This email is intended for ${emailEntered}</p>
                                        
                                        
                                        
                                        </p>
                                        </div>
                                        
                                        
                                        
                                        <div style="width:600px;height:220px;display:flex;flex-direction:row;background-color:rgb(84, 88, 90)">
                                        <div style="width:560px;height:180px; font-size: 10px;color: white;margin-left:18px;
                                        margin-top:12px
                                        ">
                                                            <div>
                                                            <p>
                                                            @2021 Thermo Fisher Scientific Inc. All rights reserved. All trademarks are the <br>
                                                             property of Thermo Fisher Scientific and its subsidiaries unless otherwise<br>
                                                              specified <br>
                                                             <p style="padding-top:6px ;">View Thermo Fisher Scientific's privacy policy</p>
                                                            
                                                            
                                                            Thermo Fisher Scientific<br>
                                                            168 Third Avenue<br>
                                                            Wattham , MA 02451<br>
                                                            United States<br>
                                                          
                                                            
                                                            </p>
                                                            </div>
                                                            </div>
                                                            <div style="width:200px;height:180px;">
                                                            <img src="https://psg-pims.s3.eu-west-1.amazonaws.com/tfslogo/tfslogofooter.PNG" style="width:130px;padding-top:18px"></img>
                                                           </div>
                                        
                                        
                                                           
                                                            </div>
                                      
                                       
                                        `
                                })
                    
                    
                            })
                        }
                        catch(errorinMail){

                        }
                    }
                  }
                  catch(err){

                  }
                }
        }

            catch(err){

            }


    }


    const handleFormSubmit = (values) => {
        var createdata = {
            "email": emailEntered,
            "t__security_questions_1": values.selectOption1,
            "t__confirm_answer_1": values.answer1,
            "t__security_questions_2": values.selectOption2,
            "t__confirm_answer_2": values.answer2,
            "t__security_questions_3": values.selectOption3,
            "t__confirm_answer_3": values.answer3,
           
            "mobile" : values.mobilenumber.toString(),

           // "password": values.password,
            
        }

        console.log("Submitted values", values.email);
        console.log("data to send", createdata);
        //://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/register

        handleConfirm(createdata,values.password)
       
    }







    const formik = useFormik({
        formInitialSchema,
        handleFormSubmit,
        formValidationSchema
    });
    return (
        <>
            <div >
                <div className='imageStyle'>
                    <img src={Logo} width="364px" height="144px"></img>
                </div>
                <h2 className="Header">Reset Password</h2>


                <div className="form">

                    <Formik initialValues={formInitialSchema}
                        validationSchema={formValidationSchema}
                        onSubmit={(values => handleFormSubmit(values))}>
                        {({ values }) =>
                            <Form>

                                <div >
                                    <label htmlFor="email" className='lab'>Email:</label>
                                    <Field type="text"

                                        name="email"
                                        value={emailEntered}
                                        disabled={true}
                                        placeholder="Enter your Email"
                                        className="form-control" />
                                    <p className="text-danger">
                                        <ErrorMessage name="email" />
                                    </p>
                                </div>

                                <div >
                                   
                                    <label htmlFor="password" className='lab'> Password</label>

                                    <Field type="password"

                                        name="password"


                                        placeholder="Enter your Password"
                                        className="form-control" />

                                    <p className="text-danger">
                                        <ErrorMessage name="password" />
                                    </p>


                                </div>

                                <div >
                                    <label htmlFor="confirmpassword" className='lab'>Confirm Password:</label>
                                    <Field type="password"
                                        name="confirmpassword"
                                        placeholder="Confirm Password"
                                        className="form-control" />
                                    <p className="text-danger">
                                        <ErrorMessage name="confirmpassword" />
                                    </p>
                                </div>

                                <p>Important Note to Set a password:</p>

<div className='instruction' >
    <ul>

        <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain at least 8 characters</span></li>
        <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain an uppercase letter</span></li>
        <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain a lowercase letter</span></li>
        <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain a number</span></li>
        <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain a symbol</span></li>
        <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must not contain consecutive letters or numbers<span className='l'>i.e. 1111 or bbbb</span></span></li>
        <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must not contain any of the following <p><span>brand names:appliedbio, fei, fisher,invitrogen,</span><span> lifetech, patheon, thermo</span></p></span></li>



    </ul>
</div>


                                <div >
                                    <label htmlFor="mobilenumber" className='lab'>Enter mobile number with country code:</label>
                                    <Field type="number"
                                        name="mobilenumber"
                                        placeholder="Enter mobile number with country code"
                                        className="form-control mnumber" />
                                    <p className="text-danger">
                                        <ErrorMessage name="mobilenumber" />
                                    </p>
                                </div>


                                <div >
                                    <label htmlFor="selectOption1" className='lab'>Select Security Question 1:  </label>
                                    <Field as='select'

                                        id="1"
                                        name="selectOption1"
                                        className="form-select"

                                    >
                                        {dropdownoptions.map(option => {
                                            return (<option key={option.value} value={option.value}>
                                                {option.key}
                                            </option>
                                            )
                                        })}
                                        {handleoptionchange1(values.selectOption1)}


                                    </Field>
                                    <p className="text-danger">
                                        <ErrorMessage name="selectOption1" />
                                    </p>

                                </div>



                                <div >
                                    <label htmlFor="answer1" className='lab'>Confirm Answer:</label>
                                    <Field type="text"
                                        name="answer1"
                                        placeholder="Confirm Answer"
                                        className="form-control" />
                                    <p className="text-danger">
                                        <ErrorMessage name="answer1" />
                                    </p>
                                </div>

                                <div >
                                    <label htmlFor="selectOption2" className='lab'>Select Security Question 2:</label>
                                    <Field as='select'
                                        id="2"
                                        name="selectOption2"
                                        className="form-select"
                                    >

                                        {dropdownoptions.map(option => {
                                            return (<option key={option.value} value={option.value}>
                                                {option.key}
                                            </option>
                                            )
                                        })}
                                        {handleoptionchange2(values.selectOption2)}
                                    </Field>
                                    <p className="text-danger">
                                        <ErrorMessage name="selectOption2" />
                                    </p>
                                </div>


                                <div >
                                    <label htmlFor="answer2" className='lab'>Confirm Answer:</label>
                                    <Field type="text"
                                        name="answer2"
                                        placeholder="Confirm Answer"
                                        className="form-control" />
                                    <p className="text-danger">
                                        <ErrorMessage name="answer2" />
                                    </p>
                                </div>

                                <div >
                                    <label htmlFor="selectOption3" className='lab'>Select Security Question 3:</label>
                                    <Field as='select'
                                        id="3"
                                        name="selectOption3"
                                        className="form-select">
                                        {dropdownoptions.map(option => {
                                            return (<option key={option.value} value={option.value}>
                                                {option.key}
                                            </option>
                                            )
                                        })}
                                        {handleoptionchange3(values.selectOption3)}
                                    </Field>
                                    <p className="text-danger">
                                        <ErrorMessage name="selectOption3" />
                                    </p>
                                </div>


                                <div >
                                    <label htmlFor="answer3" className='lab'>Confirm Answer:</label>
                                    <Field type="text"
                                        name="answer3"
                                        placeholder="Confirm Answer"
                                        className="form-control" />
                                    <p className="text-danger">
                                        <ErrorMessage name="answer3" />
                                    </p>
                                </div>
                              



                                <div>
                                    <button className="button"
                                        type="submit"
                                       

                                    >Confirm
                                    </button>
                                </div>


                            </Form>
                        }

                    </Formik>
                    <Footer></Footer>



                </div>
                <ToastContainer limit ={1}/>



            </div>




        </>
    )
}


export default Password90