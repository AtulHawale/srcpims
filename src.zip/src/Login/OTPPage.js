import React, { useState } from 'react'
import { ErrorMessage, Field, Form, Formik } from 'formik';
import { useNavigate,useHistory,useLocation} from 'react-router'
import * as yup from 'yup';
import './OTPPage.css'
import Footer from '../Footer/Footer.js';
import Logo from "../Logo/Logo.svg"
import * as HiIcons from 'react-icons/hi';
import 'bootstrap/dist/css/bootstrap.min.css';
import FirstComponent from '../Admin/FirstComponent';





function OTPPage(props){
   
    const navigate = useNavigate();
    const [otpConfimed,setOtpConfirmed]= useState(false)
 
    const formInitialSchema = {

        otp: '',

    }
    const formValidationSchema = yup.object().shape({

        otp: yup.string().required('OTP is required')
    })
    const handleFormSubmit = (values) => {
        setOtpConfirmed(true)
        console.log(" submitted otp", values)
        //  navigate('/admin')
    }
    const handleBackButton=()=>{
        props.setLoginClicked(false)
        // navigate(-1)
    }
    return (
        <>
        {otpConfimed?<FirstComponent/>:
         <div >
         <div className='imageStyle'>
                    <img  src={Logo} width="364px" height="144px"></img>
                    </div>
                    <p className="Header">Login to your Account</p>
                    <div style={{textAlign:"center",fontSize:"25px",color:"blue",right:"183px",position:"relative"}}>
                        <HiIcons.HiArrowSmLeft onClick={handleBackButton}/></div>
                   
    
                    <div className="form">
    
                        <Formik initialValues={formInitialSchema}
                            validationSchema={formValidationSchema}
                            onSubmit={(values => handleFormSubmit(values))}>
                            {({ values }) =>
                                <Form>
                                   
                                    <div >
                                    <label htmlFor="otp" className='lab'>Verification Token:</label>
                                        <Field type="text"
                                        
                                            name="otp"
                                            placeholder="Enter verification token"
                                            className="form-control" />
                                        <p className="text-danger">
                                            <ErrorMessage name="otp" />
                                        </p>
                                    </div>
                                   
                                        
    
    
    
                                   
    
                                    <div>
                                        <button className="button"
                                            type="submit"
                                        >Confirm
                                        </button>
                                    </div>
    
    
                                </Form>
                            }
    
                        </Formik> <br></br> <br></br>
                        {/* <div>
                            <label style={{fontSize:"12px"}}>Didn't receive OTP?</label>
                            <label> <a style={{color:"#1E8AE7",fontSize:"12px", paddingLeft:"2px"}}>Resend</a></label>
                        </div> */}
                   {/* <Footer></Footer> */}
    
                      
                    </div>
                    
    
    
                </div>
    
                                    
        
                        }
        </>
      )
}


export default OTPPage