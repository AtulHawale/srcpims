import { useQuery } from "react-query";
import axios from "axios";
// export const axiosinstance = axios.create({
//     withCredentials: true
//   })

export const GetInternalUsers = async ({ queryKey }) => {
  const res = await axios.get(
    `https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/getUserList?userType=${queryKey[1]}`,
    {
      headers: {
        "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3",
      },
      withCredentials: true,
    }
  );
  return res;
};
export const GetAllAccount = async ({ queryKey }) => {
  const res = await axios.get(
    `https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/${queryKey[1]} `,
    {
      headers: {
        "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3",
      },
      withCredentials: true,
    }
  );
  return res;
};

export const GetControlData = async () => {
  const response = await axios.get(
    `https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/controlData `,
    {
      headers: {
        "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3",
      },
      withCredentials: true,
    }
  );
  return response;
};

export const SaveData = async ({ id, payload }) => {
  
  const response = await axios.put(
    `https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/${id}`,
    payload,
    {
      headers: {
        "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3",
      },
      withCredentials: true,
    }
  );
  return response;
};
export const CreateUserRegister = async ({ payload }) => {
  console.log("querkey", payload);
  const res = await axios.post(
    `https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/register`,
    payload,
    {
      headers: {
        "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3",
      },
      withCredentials: true,
    }
  );
  return res;
};
export const CreateExternalRegister = async ({ payload }) => {
  console.log("querkey", payload);
  const res = await axios.post(
    `https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/registerExtUser`,
    payload,
    {
      headers: {
        "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3",
      },
      withCredentials: true,
    }
      
    
  );
  return res;
};
