import React, { useState } from 'react'
import { ErrorMessage, Field, Form, Formik, useFormik } from 'formik';
import * as yup from 'yup';
//import Form from 'react-bootstrap/Form'
import './CreateAccount.css'
// import Footer from '../Footer/Footer.js';
import { useNavigate } from "react-router-dom"
import Logo from "../Logo/Logo.svg"
import axios from 'axios'
import Footer from '../Footer/Footer.js';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import * as AiIcons from 'react-icons/ai';
//import crypto from 'crypto'
//import request from 'request'


//import Select from '../Select/Select';

const dropdownoptions = [
    { key: 'Select option', value: '' },
    { key: 'what is your name', value: 'what is your name?' },
    { key: 'who is your hero', value: 'who is your hero?' },
    { key: 'what is your nick name', value: 'what is your nick name?' },
    { key: 'In what city were you born', value: 'In what city were you born?' },
    { key: 'What high school did you attend?', value: 'What high school did you attend?' },
    { key: 'What was the name of your elementary school?', value: 'What was the name of your elementary school?' },
    { key: 'What was the make of your first car?', value: 'What was the make of your first car?' },
    { key: 'Where did you meet your spouse?', value: 'Where did you meet your spouse?' },
    { key: 'What year was your father (or mother) born?', value: 'What year was your father (or mother) born?' },
    { key: 'What is name of your mother', value: 'What is name of your mother?' },
    { key: 'What is name of your father', value: 'What is name of your father?' },
    { key: 'What is name of your brother', value: 'What is name of your brother?' },
    { key: 'What is name of your friend', value: 'What is name of your friend?' },
    { key: 'What is name of your sister', value: 'What is name of your sister?' },
    { key: 'What is name of your pet', value: 'What is name of your pet?' },
    { key: 'What is name of your teacher', value: 'What is name of your teacher?' },
    { key: 'What is name of your uncle', value: 'What is name of your uncle?' },
    { key: 'What is name of your aunty', value: 'What is name of your aunty?' },
    { key: 'What is name of your godfather', value: 'What is name of your godfather?' },
    { key: 'What is name of your wife', value: 'What is name of your wife?' },



]

function Tabs() {
    const formInitialSchema = {
        email: '',
        password: '',
        confirmpassword: '',
        selectOption1: '',
        answer1: '',
        selectOption2: '',
        answer2: '',
        selectOption3: '',
        answer3: '',
        mobilenumber: ''
    }

    const checkchar = /^(?!.*(appliedbio|fei|fisher|invitrogen|lifetech|patheon|thermo))/
    const checkyear = /(0{3}\d|00[1-9]\d|0[1-9]\d{2}|1\d{3}|200\d|201[0-4])|(203[6-9]|20[4-9]\d|2[1-9]\d{2}|[3-9]\d{3}|10000)/



    const navigate = useNavigate();
    const [selectOption1, setSelectOption1] = useState('');
    const [selectOption2, setSelectOption2] = useState('');
    const [selectOption3, setSelectOption3] = useState('');

    window.onpopstate = () => {
        navigate("/");
      }








    const handleoptionchange1 = (opt) => {
        setSelectOption1(opt)

    }
    const handleoptionchange2 = (opt) => {
        setSelectOption2(opt)

    }
    const handleoptionchange3 = (opt) => {
        setSelectOption3(opt)

    }


    const formValidationSchema = yup.object().shape({

        email: yup.string().required('Email is required').email("Please enter Valid email").matches(
            /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
            , "Please Enter Valid Email"),
        password: yup.string().required('Password is required').matches(

            /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,

            "Does not match with below Criteria"

        ).test('test1', "Does not match with below Criteria", (value) => validate(value)).test('test2', "Does not match with below Criteria", (value) => validate2(value)).required('Password is required'),
        confirmpassword: yup.string().oneOf([yup.ref('password'), null], "Password does not match").required('Confirm Password is required'),
        //selectOption1: yup.string().required('Option is required'),
        selectOption1: yup.string().notOneOf([
            yup.ref('selectOption2'),
            yup.ref('selectOption3')
        ], "Should be a different question").required('Option is required'),
        selectOption2: yup.string().notOneOf([
            yup.ref('selectOption1'),
            yup.ref('selectOption3')
        ], "Should be a different question").required('Option is required'),
        selectOption3: yup.string().notOneOf([
            yup.ref('selectOption2'),
            yup.ref('selectOption1')
        ], "Should be a different question").required('Option is required'),
        answer1: yup.string().required('Answer is required'),
        answer2: yup.string().required('Answer is required'),
        answer3: yup.string().required('Answer is required'),
        mobilenumber : yup.string().required('Mobile number is required')



    });

    function validate(pass) {
        console.log("validate called")

        var str = pass;
        var arr = ["2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032", "2033", "2034", "2035", "appliedbio", "fei", "fisher", "invitrogen", "lifetech", "patheon", "thermo"];

        if (str) {
            for (var i in arr) {
                var b = str.toLowerCase().indexOf(arr[i]);
                if (b >= 0) {
                    console.log("invalid string");
                    return false;
                }
            }
        }

        return true;
    }


    const validate2 = (val) => {
        let result = [];
        var str = [val];

        if (val) {

            str.map(each => {
                let repeatedChars = 0;
                for (let i = 0; i < each.length - 1; i++) {
                    if (each[i] === each[i + 1] && each[i] === each[i - 1] && each[i] === each[i + 2]) {

                        repeatedChars += 1;
                    }
                }

                result.push(repeatedChars);
                console.log("repeatedChars", repeatedChars);

            });

            if (result[0] > 0) {
                return false
            }
            else {
                return true;
            }
        }
    };

    
    function handleEmail() {
        console.log("handleEmail called")
      
    fetch ("https://zbcax1fvhc.execute-api.ap-south-1.amazonaws.com/sendMail" ,{
        mode:'no-cors',
        method: "post",
        headers:{
            Accept:'application/json', 
            "Content-Type":"application/json",

        },
        body:JSON.stringify({
            "to":"shwetapadhy44@gmail.com",
            "subject": "Test email",
            "htmlbody":"<H1>http://localhost:3000/createaccount<H1>"
        })

    })

    }


    const handleFormSubmit = (values) => {
        const headers = {
            'Medable-Client-Key': 'EYKm5YLKZjjRNi7MDkqxA3',
            'Origin': 'https://api.dev.medable.com'
        }
        var createdata = {
            "email": values.email,
            "t__security_questions_1": values.selectOption1.toLowerCase(),

            "t__confirm_answer_1": values.answer1.toLowerCase(),

            "t__security_questions_2": values.selectOption2.toLowerCase(),

            "t__confirm_answer_2": values.answer2.toLowerCase(),

            "t__security_questions_3": values.selectOption3.toLowerCase(),

            "t__confirm_answer_3": values.answer3.toLowerCase(),
           
            "mobile" : values.mobilenumber.toString(),

            "password": values.password,

            
           
            
        }

        console.log("Submitted values", values.email);
        console.log("data to send", createdata);
        //://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/register

        axios.post("https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/register", createdata, {
            headers: headers
        }).then((res) => {
            console.log("response from backend", res);
            if (res.status == 200) {
              
                handleEmail()
                alert("Account Created successfully");
                
               
            }
        }).catch((err) => {
            console.log(err,'error')
           
            alert(err.response.data.faults[0].message)
         
        });
       
    }







    const formik = useFormik({
        formInitialSchema,
        handleFormSubmit,
        formValidationSchema
    });
    return (
        <>
            <div >
                <div className='imageStyle'>
                    <img src={Logo} width="364px" height="144px"></img>
                </div>
                <h2 className="Header">Create Your Account</h2>


                <div className="form">

                    <Formik initialValues={formInitialSchema}
                        validationSchema={formValidationSchema}
                        onSubmit={(values => handleFormSubmit(values))}>
                        {({ values }) =>
                            <Form>

                                <div >
                                    <label htmlFor="email" className='lab'>Email:</label>
                                    <Field type="text"

                                        name="email"
                                        placeholder="Enter your Email"
                                        className="form-control" />
                                    <p className="text-danger">
                                        <ErrorMessage name="email" />
                                    </p>
                                </div>

                                <div >
                                   
                                    <label htmlFor="password" className='lab'> Password</label>

                                    <Field type="password"

                                        name="password"


                                        placeholder="Enter your Password"
                                        className="form-control" />

                                    <p className="text-danger">
                                        <ErrorMessage name="password" />
                                    </p>


                                </div>

                                <div >
                                    <label htmlFor="confirmpassword" className='lab'>Confirm Password:</label>
                                    <Field type="password"
                                        name="confirmpassword"
                                        placeholder="Confirm Password"
                                        className="form-control" />
                                    <p className="text-danger">
                                        <ErrorMessage name="confirmpassword" />
                                    </p>
                                </div>

                                <p>Important Note to Set a password:</p>

<div className='instruction' >
    <ul>

        <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain at least 8 characters</span></li>
        <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain an uppercase letter</span></li>
        <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain a lowercase letter</span></li>
        <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain a number</span></li>
        <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must contain a symbol</span></li>
        <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must not contain consecutive letters or numbers<span className='l'>i.e. 1111 or bbbb</span></span></li>
        <li style={{ color: "green" }}> <span style={{ color: "black" }}>Must not contain any of the following <p><span>brand names:appliedbio, fei, fisher,invitrogen,</span><span> lifetech, patheon, thermo</span></p></span></li>



    </ul>
</div>


                                <div >
                                    <label htmlFor="mobilenumber" className='lab'>Enter Mobile Number with Country code:</label>
                                    <Field type="number"
                                        name="mobilenumber"
                                        placeholder="Enter mobile number with country code"
                                        className="form-control mnumber" />
                                    <p className="text-danger">
                                        <ErrorMessage name="mobilenumber" />
                                    </p>
                                </div>


                                <div >
                                    <label htmlFor="selectOption1" className='lab'>Select Security Question 1:  </label>
                                    <Field as='select'

                                        id="1"
                                        name="selectOption1"
                                        className="form-select"

                                    >
                                        {dropdownoptions.map(option => {
                                            return (<option key={option.value} value={option.value}>
                                                {option.key}
                                            </option>
                                            )
                                        })}
                                        {handleoptionchange1(values.selectOption1)}


                                    </Field>
                                    <p className="text-danger">
                                        <ErrorMessage name="selectOption1" />
                                    </p>

                                </div>



                                <div >
                                    <label htmlFor="answer1" className='lab'>Confirm Answer:</label>
                                    <Field type="text"
                                        name="answer1"
                                        placeholder="Confirm Answer"
                                        className="form-control" />
                                    <p className="text-danger">
                                        <ErrorMessage name="answer1" />
                                    </p>
                                </div>

                                <div >
                                    <label htmlFor="selectOption2" className='lab'>Select Security Question 2:</label>
                                    <Field as='select'
                                        id="2"
                                        name="selectOption2"
                                        className="form-select"
                                    >

                                        {dropdownoptions.map(option => {
                                            return (<option key={option.value} value={option.value}>
                                                {option.key}
                                            </option>
                                            )
                                        })}
                                        {handleoptionchange2(values.selectOption2)}
                                    </Field>
                                    <p className="text-danger">
                                        <ErrorMessage name="selectOption2" />
                                    </p>
                                </div>


                                <div >
                                    <label htmlFor="answer2" className='lab'>Confirm Answer:</label>
                                    <Field type="text"
                                        name="answer2"
                                        placeholder="Confirm Answer"
                                        className="form-control" />
                                    <p className="text-danger">
                                        <ErrorMessage name="answer2" />
                                    </p>
                                </div>

                                <div >
                                    <label htmlFor="selectOption3" className='lab'>Select Security Question 3:</label>
                                    <Field as='select'
                                        id="3"
                                        name="selectOption3"
                                        className="form-select">
                                        {dropdownoptions.map(option => {
                                            return (<option key={option.value} value={option.value}>
                                                {option.key}
                                            </option>
                                            )
                                        })}
                                        {handleoptionchange3(values.selectOption3)}
                                    </Field>
                                    <p className="text-danger">
                                        <ErrorMessage name="selectOption3" />
                                    </p>
                                </div>


                                <div >
                                    <label htmlFor="answer3" className='lab'>Confirm Answer:</label>
                                    <Field type="text"
                                        name="answer3"
                                        placeholder="Confirm Answer"
                                        className="form-control" />
                                    <p className="text-danger">
                                        <ErrorMessage name="answer3" />
                                    </p>
                                </div>
                              



                                <div>
                                    <button className="button"
                                        type="submit"
                                       

                                    >Confirm
                                    </button>
                                </div>


                            </Form>
                        }

                    </Formik>
                    <Footer></Footer>



                </div>



            </div>




        </>
    )
}


export default Tabs