import React,{useEffect} from 'react'
// import styled from 'styled-components'
// import {Link} from 'react-router-dom'
// import * as FaIcons from 'react-icons/fa';
import * as CgIcons from 'react-icons/cg';
import { useLocation} from 'react-router-dom';
import * as MdIcons from 'react-icons/md';
import * as AiIcons from 'react-icons/ai';
import * as BsIcons from 'react-icons/bs';
// import * as IoIcons from 'react-icons/io';
import * as RiIcons from 'react-icons/ri';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Logo from "../Logo/Logo.svg"
import SubMenuSite from './SubMenuSite';








const SidebarData = [
  {
    title: 'Home',
    path: '/homesite',
    icon: <MdIcons.MdDashboard style={{ width: '24px', height: '24px' }} />,
    // iconClosed: <RiIcons.RiArrowDownSFill />,
    // iconOpened: <RiIcons.RiArrowUpSFill />,
  },

  {
    title: 'Sites Tool',
    path: '',
    icon: <BsIcons.BsChatSquareTextFill style={{ width: '24px', height: '24px' }} />,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />,
    subNav: [
      {
        title: 'Create user',
        path: '',

      },
      {
        title: 'Upload users',
        path: '',

      }
    ]
  },


  {
    title: 'Contact us',
    path: '',
    icon: <BsIcons.BsEnvelopeFill style={{ width: '24px', height: '24px' }} />
  },
  {
    title: 'Setting',
    path: '',
    icon: <AiIcons.AiTwotoneSetting style={{ width: '24px', height: '24px' }} />
  },




];


const Logout = () => {
  sessionStorage.clear()


  window.location.href = 'https://aav0112.my.idaptive.app/applogout/appkey/3f986442-dbe0-4d4d-935e-c876390cdb1c/customerid/AAV0112'

}



function SidebarSite() {
  const navigate = useNavigate();
  const location =useLocation();

  

  
  return (
    <>
      <div className="Sidebar">
        <div className='imageStyle'>
          <img src={Logo} width="166px" height="54px" style={{ marginTop: '64px' }}></img>
        </div>

        <div className='SidebarWrap'>
          {SidebarData.map((item, index) => {
            return <SubMenuSite item={item} key={index} />
          })}
        </div>
        <h3 >{location.state && location.state.data.email? location.state.data.email :''}</h3>

        <button style={{ marginTop: '100px', marginLeft: '20px', border: 'none', outline: 'none', background: '#DD1F25', color: 'white', fontSize: '16px', fontWeight: '700' }} onClick={Logout}><MdIcons.MdLogout style={{ width: '24px', height: '24px', marginRight: '18px' }} />Log out</button>


      </div>

    </>
  )
}

export default SidebarSite