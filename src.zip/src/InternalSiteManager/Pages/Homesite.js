import React from 'react'

function Homesite() {
  return (
    <h1 style={{display:'flex'}}>Home</h1>
  )
}

export default Homesite