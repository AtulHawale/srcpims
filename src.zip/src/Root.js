import { BrowserRouter, BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Login from "./Login/Login";
import FirstComponent from "./Admin/FirstComponent.js"
import SecondComponent from "./Admin/SecondComponent";
import CreateAccount from "./Onboarding_ExternalUser/CreateAccount.js"
import Idletimer from "react-idle-timer"
import { useRef } from "react"
import { useNavigate } from 'react-router'
import App from "./App.js"
import ForgotPassword from "./Login/ForgotPassword.js";
import ResetPassword from "./Login/ResetPassword.js";
import Dashboard from "./Admin/Dashboard"
import InternalSiteManager from "./Admin/InternalSiteManager"
import Password90 from "./Login/Password90";
import PrivateRoutes from "./Component/PrivateRoute";
import Success from "./Component/Success";
import SideBar from "./AdminDashboard/Sidebar";
import WithSide from "./AdminDashboard/WithSide";
import Home from "./AdminDashboard/Pages/Home";
import InternalUsers from "./AdminDashboard/Pages/InternalUsers/InternalUsers";
import InternalPatientManager from "./Admin/InternalPatientManager";
import SidebarSite from "./InternalSiteManager/SidebarSite";
import CreateUsers from "./AdminDashboard/Pages/InternalUsers/CreateUser";
import UploadUsers from "./AdminDashboard/Pages/UploadUsers";
import ViewUser from "./AdminDashboard/Pages/InternalUsers/ViewUser";
import ExternalUsers from "./AdminDashboard/Pages/ExternalUsers/ExternalUsers";
import ExternalCreateUsers from "./AdminDashboard/Pages/ExternalUsers/ExternalCreateUsers";
import ExternalViewUser from "./AdminDashboard/Pages/ExternalUsers/ExternalViewUser";
import Trial from "./AdminDashboard/Pages/Trial/Trial";

import CreateTrial from "./AdminDashboard/Pages/Trial/CreateTrial";


function Root() {
    const idleTimeRef = useRef(null)
    const navigate = useNavigate()
    // const handleOnIdle=()=>{
    //     console.log(" on handle idle called")
    //     alert(" You have been inactive for 15 min, Please login again")
    //     navigate("/login")
    //     window.location.reload()
    //     sessionStorage.clear()
    // }
    return (
        <div>
            {/* <Idletimer ref={idleTimeRef} timeout={5*1000} onIdle={handleOnIdle} /> */}

            <Routes>

                <Route element={<PrivateRoutes />}>
                    
                    {/* <Route path='/admindashboard'  exact element={<Dashboard/>} /> */}
                    <Route path='/internalsitemanagerdashboard' exact element={<SidebarSite/>} />
                    <Route path='/internalpatientmanagerdashboard' exact element={<InternalPatientManager />} />

                    <Route path='/admindashboard' exact element={<SideBar />} />





                </Route>
                <Route element={<PrivateRoutes />}>
                    <Route element={<WithSide />}>
                        <Route path='/home' exact element={<Home />} />
                        <Route path='/trial' exact element={<Trial />} />
                        <Route path='/trial/createtrial' exact element={<CreateTrial/>} />
                        <Route path='/internalusers' exact element={<InternalUsers />} />
                        <Route path='/internalusers/createuser' exact element={<CreateUsers />} />
                        <Route path='/viewusers' exact element={<ViewUser />} />
                        <Route path='/externalusers' exact element={<ExternalUsers />} />
                        <Route path='/externalusers/createuser' exact element={<ExternalCreateUsers />} />
                        <Route path='/viewuserexternal' exact element={<ExternalViewUser />} />


                    </Route>

                </Route>




                <Route path='/createaccount' exact element={<CreateAccount />} />
                <Route path='/' exact element={<Login />} />
                <Route path='/reset' exact element={<ResetPassword />} />

                <Route path='/forgotpassword' exact element={<ForgotPassword />} />
                {/* <Route path='/home'  exact element={<Home/>} /> */}

                {/* <Route path='/reset'  exact element={<ResetPassword/>} /> */}

                <Route path='/90days' exact element={<Password90 />} />
                {/* <Route path='/admindashboard'  exact element={<SideBar/>} /> */}







                {/* <Route path='/otppage'  exact element={<OTPPage/>} />  */}
                {/* <Route path='/admin'  exact element={<FirstComponent/>} />  */}
                <Route path='/adminExternal' exact element={<SecondComponent />} />
                <Route path='/success' exact element={<Success />} />

















                {/* <Route path='/forgotpassword'  exact element={<ForgotPassword/>} />  */}

            </Routes>
        </div>
    )

}

export default Root

