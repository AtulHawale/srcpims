export const rolesArray = [
    {
      roleName: "Administrator",
  
      roleId: "000000000000000000000004",
    },
  
    {
      roleName: "Internal Site Manager",
  
      roleId: "62f24d4cf8f151c943f90e0b",
    },
  
    {
      roleName: "Internal Patient Manager",
  
      roleId: "62f24d77f8f151c943f91365",
    },
  
    {
      roleName: "External Patient Manager",
  
      roleId: "62f24da4f8f151c943f91f0b",
    },
  ];
  