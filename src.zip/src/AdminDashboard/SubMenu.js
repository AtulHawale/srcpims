import React, { useState } from "react";
import { Link,useLocation } from "react-router-dom";
import styled from "styled-components";

const SidebarLink = styled(Link)`
  display: flex;
  color: #e1e9fc;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  list-style: none;
  height: 48px;
  text-decoration: none;
  font-size: 18px;
  text-decoration: none;
  color: #fff !important;
import SubMenu from './SubMenu';

  &:active , &:focus,&:hover{
    background: rgba(0, 0, 0, 0.15);
    a{
      background: rgba(0, 0, 0, 0.15);
    }
    a: hover{
      text-decoration: none;
      color: #fff;

    }

  }

  &:hover {

    color: #e1e9fc
   
    cursor: pointer;
  }
`;

const SidebarLabel = styled.span`
  margin-left: 20px;
  font-family: Helvetica;
  font-size: 16px;
  font-weight: 700;
`;

const DropdownLink = styled(Link)`
  color: #fff;
  background: #dd1f25;
  height: 42px;
  padding-left: 2.7rem;
  padding-bottom: 16px;
  padding-top:16px;
  display: flex;
  align-items: center;
  text-decoration: none;
  font-size: 18px;

  &:hover,
  &:active {
    color: #fff;
    cursor: pointer;
    background: rgba(0, 0, 0, 0.15);
  }
`;
const SubMenus = styled.div`
  .active{
    background: rgba(0,0,0,0.15) !IMPORTANT;
  }
`

const SubMenu = ({ item ,className}) => {
  const [subnav, setSubnav] = useState(false);

  const showSubnav = () => setSubnav(!subnav);
  


  return (
    <SubMenus> 
      <SidebarLink to={item.path} onClick={item.subNav && showSubnav} className={className}>
        <div>
          {item.icon}
          <SidebarLabel>{item.title}</SidebarLabel>
        </div>
        <div>
          {item.subNav && subnav
            ? item.iconOpened
            : item.subNav
            ? item.iconClosed
            : null}
        </div>
      </SidebarLink>
      {subnav &&
        item.subNav.map((item, index) => {
          return (
            <DropdownLink to={item.path} key={index} className={className}>
              {item.icon}

              <SidebarLabel>{item.title}</SidebarLabel>
            </DropdownLink>
          );
        })}
    </SubMenus>
  );
};

export default SubMenu;
