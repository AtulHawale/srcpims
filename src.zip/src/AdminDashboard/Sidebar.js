import React, { useEffect, useState } from "react";

// import styled from 'styled-components'
// import {Link} from 'react-router-dom'
// import * as FaIcons from 'react-icons/fa';


// import * as IoIcons from 'react-icons/io';
import * as RiIcons from "react-icons/ri";
import { useNavigate, useLocation } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Sidebar.css";
import Logowhite from "../Logo/Logowhite.svg";
import Externaluser from "../Logo/Externaluser.svg";
import Internaluser from "../Logo/Internaluser.svg";
import setting from "../Logo/setting.svg";
import Protocol from "../Logo/Protocol.svg";
import Home from "../Logo/Home.svg";
import audit from "../Logo/audit.svg";
import Contact from "../Logo/Contact.svg";
import logout from "../Logo/logout.svg";
import SubMenu from "./SubMenu";
import styled from "styled-components";
import axios from 'axios';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const LogoutButton = styled.button`
  border: none;
  outline: none;
  background: #dd1f25;
  color: white;
  font-size: 16px;
  font-weight: 700;
  width: 100%;
  position: absolute;
  @media screen and (max-width: 550px){
    position: relative;
    bottom: unset;
    .logout-wrapper{
      padding: 0 0 0 20px !important;
    }
  }
  left: 0;
  padding: 16px 0 16px 0px;
  .logout-wrapper{
    text-align: left;
    height: 48px;
    line-height: 48px;
    padding-left: 36px;
    &:hover ,&:active{
      background:  rgba(0,0,0,0.15);
    }
  }
`;
const MobileFooter = styled.div`
display: none;
@media screen and (max-width: 550px){
font-family: Helvetica;
display: block;
font-weight: 400;
font-size:12px;
color: #fff;
}




`
const SidebarData = [

  {

    title: "Home",

    path: "/home",

    icon: <img src={Home} style={{ width: "24px", height: "24px" }} />,

    // iconClosed: <RiIcons.RiArrowDownSFill />,

    // iconOpened: <RiIcons.RiArrowUpSFill />,

  },

  {

    title: "Trial",

    path: "/trial",

    icon: <img src={Protocol} style={{ width: "24px", height: "26.67px" }} />,

    iconClosed: <RiIcons.RiArrowDropDownLine style={{ width: "24px", height: "26.67px" }} />,

    iconOpened: <RiIcons.RiArrowUpSLine style={{ width: "16px", height: "16px" }} />,
    subNav: [

      {

        title: "Create trial",

        path: "/trial/createtrial",

      },

      {

        title: "Upload users",

        path: "/viewuserexternal",

      },

    ],

  },

  

  {

    title: "Internal users",

    path: "/internalusers",

    icon: <img src={Internaluser} style={{ width: "24px", height: "26.67px" }} />,

    iconClosed: <RiIcons.RiArrowDropDownLine style={{ width: "24px", height: "26.67px" }} />,

    iconOpened: <RiIcons.RiArrowUpSLine style={{ width: "16px", height: "16px" }} />,

    subNav: [

      {

        title: "Create user",

        path: "/internalusers/createuser",

      },

      {

        title: "Upload users",

        path: "/viewuserexternal",

      },

    ],

  },

  {

    title: "External users",

    path: "/externalusers",

    icon: <img src={Externaluser} style={{ width: "24px", height: "26.67px" }} />,
    iconClosed: <RiIcons.RiArrowDropDownLine style={{ width: "24px", height: "26.67px" }} />,

    iconOpened: <RiIcons.RiArrowUpSLine style={{ width: "16px", height: "16px" }} />,



    subNav: [

      {

        title: "Create user",

        path: "/externalusers/createuser",

      },

      {

        title: "Upload users",

        path: "",

      },

    ],

  },

  {

    title: "Audit",

    path: "/audit",

    icon: <img src={audit} style={{ width: "24px", height: "24px" }} />,

  },

  {

    title: "Contact us",

    path: "/contantus",

    icon: <img src={Contact} style={{ width: "26.67px", height: "21.33px" }} />,

  },



  {

    title: "Setting",

    path: "/setting",

    icon: <img src={setting} style={{ width: "25px", height: "26px" }} />,

  },




];
var t



const SideBar = () => {
  // const [sidebar,setSidebar]= useState(true)

  // const showSidebar=()=>setSidebar(sidebar);
  

  const navigate = useNavigate();
  const [emailValue, setEmailValue] = useState(sessionStorage.getItem("email"))
  const[logoutStatus,setLogoutStatus]=useState(false)

  const location = useLocation()

  useEffect(() => {
    //  handleSessionTimeout()


  })
  const Logout = () => {
    console.log(sessionStorage.getItem("email"), "email")
    sessionStorage.clear();


    // window.location.href =
    //   "https://aav0112.my.idaptive.app/applogout/appkey/3f986442-dbe0-4d4d-935e-c876390cdb1c/customerid/AAV0112 " ;
    axios({
      method: "post",
      url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/me/logout",
      data: { "email": emailValue },
      headers: { "medable-client-key": "XAwz1iPreVSkNY0RPaVcSX" },
    })
      .then((res) => {
        console.log("logout response headers", res.headers)
        if (res.status === 200) {
          navigate('/')

          if (res.data) {
           
          }
        }
        console.log("logout response", res);
      })






  };

  const handleSessionTimeout = () => {
    clearTimeout(t)
    document.addEventListener("keydown", handleSessionTimeout)
    document.addEventListener("mousemove", handleSessionTimeout)
    document.addEventListener("touchstart", handleSessionTimeout)
   
    t= setTimeout(() => {
        sessionStorage.clear();
     
        // toast.warning("Your session has expired.  Please Login back to continue.", {
        //   position: toast.POSITION.TOP_CENTER,
        // });
        alert("Your session has expired.  Please Login back to continue.")
      window.location.reload()
      navigate("/")
     
      axios({
          method: "post",
          url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/accounts/me/logout",
          data: { "email": emailValue},
          headers: { "medable-client-key": "XAwz1iPreVSkNY0RPaVcSX" },
      })
      .then((res) => {
          console.log("logout response headers", res.headers)
          if (res.status === 200) {
              if (res.data) {
                // setLogoutStatus(true)
                
              }
          }
          console.log("logout response", res);
      })

  }, 1*60*1000);
  }

  console.log(location, "location")

  const activepath = location.pathname

    console.log(activepath, 'active')

    window.onpopstate = () => {
      console.log("back");
      navigate("/admindashboard");
    };
    // window.onbeforeunload = function() {
    //   window.history.forward()
    //  }

    return (
      <>
        {/*        
            <Nav>
                <NavIcon to='#'>
                    <FaIcons.FaBars onClick={showSidebar}/>
                </NavIcon>
            </Nav> */}

        <div className="Sidebar">
          <div className="imageStyle">
            <img
              src={Logowhite}
              width="160px"
              height="34px"
             
            ></img>
          </div>

          <div className="SidebarWrap">
            {SidebarData.map((item, index) => {

              return <SubMenu item={item} key={index} className={`${activepath.includes(item.path) ? "active" : ""}`} />;
            })}


            <LogoutButton onClick={Logout}>
              <div className="logout-wrapper">
                <img
                  src={logout}
                  style={{ width: "24px", height: "24px", marginRight: "10px" }}
                />
                Log out
              </div>


            </LogoutButton>
            <MobileFooter>
              {sessionStorage.getItem('email')}
            </MobileFooter>
          </div>
          <ToastContainer limit ={1}/>

        </div>
      </>
    );
  };

  export default SideBar;
