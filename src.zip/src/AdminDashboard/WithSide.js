import React, { useState } from "react";
import { Outlet } from "react-router-dom";
import SideBar from "./Sidebar";
import styled from "styled-components";
import { FaBars } from "react-icons/fa";
import Logowhite from "../Logo/Logowhite.svg";
import { ReactComponent as Notification } from "../Logo/Notifications.svg";
import { ReactComponent as HamburgerIcon } from "../Logo/hamburger_menu.svg";
import useOnClickOutside from "react-cool-onclickoutside";

const AdminContainer = styled.div`
  width: 100%;
  flex-direction: row;
  display: flex;
  height: 100%;
  position: relative;

  .sidebar-div {
    display: inline-block;
    position: relative;
  }
  .hamburger-icon {
    display: none;
  }
  .mobile-sidebar-hide,
  .mobile-sidebar-div {
    display: none;
  }
  .mobile-header {
    display: none;
  }
  @media screen and (max-width: 550px) {
    .mobile-header {
      display: flex;
      width: 100%;
      background: #dd1f25;
      height: 60px;
      position: absolute;
      justify-content: space-around;
      align-items: center;
    }
    .hamburger-icon {
      display: block;
      color: red;

      width: 40px;
      height: 40px;
    }
    .sidebar-div {
      display: none;
    }
    .mobile-sidebar-div {
      display: block;
      position: absolute;
      z-index: 1;
      width: 80%;
      height: 100%;
    }
   
  }
  .outlet-container {
    display: inline-block;
    flex: 1 1 0;
    padding: 64px 30px;
    width: 100%;
    min-height: 750px;
  }
`;

function WithSide() {
  const [showMobileHeader, setshowMobileHeader] = useState(false);
  const ref = useOnClickOutside(() => setshowMobileHeader(false));
  return (
    <>
      <AdminContainer>
        <div className="sidebar-div">
          <SideBar />
        </div>
        <div className="mobile-header">
          <HamburgerIcon
            onClick={() => setshowMobileHeader(true)}
            className="hamburger-icon"
          />
          <img src={Logowhite} width="160px" height="34px" ></img>
          <Notification style={{ color: "white" }} />
        </div>

        <div
          className={`${
            showMobileHeader ? "mobile-sidebar-div" : "mobile-sidebar-hide"
          }`}
          ref={ref}
        >
          <SideBar />
        </div>
        <div className="outlet-container">
          <Outlet />
        </div>
      </AdminContainer>
    </>
  );
}

export default WithSide;
