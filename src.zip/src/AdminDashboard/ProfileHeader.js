import React from "react";
import "./Pages/Header.css";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Notifications from "../Logo/Notifications.svg";
import Account from "../Logo/Account.svg";
import styled from "styled-components";

const EmailSeparator = styled.div`
  p{
    font-family: Helvetica;
    font-size: 14px;
    color: #808080;
    cursor: pointer;
  }
  @media screen and (max-width: 550px) {
    display: none;
  }
`;

function ProfileHeader() {
  return (
    <>
      <EmailSeparator>
        <div className="d-flex justify-content-between">
          <p>
            <img src={Account} style={{ width: "26.67px", height: "26.67px" }} />{"  "}
            {sessionStorage.getItem("email")}
          </p>
       
        </div>

        <div className="line"></div>
      </EmailSeparator>
    </>
  );
}

export default ProfileHeader;
