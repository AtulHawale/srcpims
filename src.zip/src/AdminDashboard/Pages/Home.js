import React, { useEffect } from "react";
import "./Home.css";
import { useLocation } from "react-router-dom";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Card from "react-bootstrap/Card";

import ProfileHeader from "../ProfileHeader";
import styled from "styled-components";
const HomeWrapper = styled.div`
  @media screen and (max-width: 550px) {
      width: 100%;
      .mobile-cards {
        width: 100%;
        .card{
          margin: 0 !Important;
          padding-bottom: 24px;
        }
      }
      .button1{
        margin-top:140px ;
        display:flex;
        justify-content:center;
        
      }
      .button2{
        margin-top:140px;
        display:flex;
        justify-content:center;
      }
      .button3{
        margin-top:140px;
        display:flex;
        justify-content:center;
      }

      

     
    
  }
`;

function Home() {
  const location = useLocation();
  useEffect(() => {
    if (location.state && location.state.data) {
      console.log(" location props", location.state.data.email);
    }
  });

  return (
    <>
      <ProfileHeader />

      <p className="heading">Home</p>

      <HomeWrapper className="home mobile-home">
        <div style={{ width: "100%" }}>
          <div className="d-flex flex-wrap" style={{ width: "100%" }}>
            <div className="col-md-6 mobile-cards">
              <Card
                style={{ height: "354px", border: "none", marginRight: "16px" }}
              >
                <Card.Header
                  style={{
                    width: "100%",
                    height: "80px",
                    fontSize: "32px",
                    paddingLeft: "50px",
                    backgroundColor: "#FFFFFF",
                    border: "1px solid #C8C8C8",
                    fontWeight: "700",
                  }}
                >
                  <p>Internal Users</p>
                </Card.Header>
                <Card.Body
                  style={{
                    backgroundColor: "#FDFCFC",
                    border: "1px solid #C8C8C8",
                  }}
                >
                  <Card.Title></Card.Title>
                  <Card.Text></Card.Text>
                  <button className="button1">See Internal Users</button>
                </Card.Body>
              </Card>
            </div>

            <div className="col-md-6  mobile-cards">
              <Card
                style={{ height: "354px", border: "none", marginLeft: "32px" }}
              >
                <Card.Header
                  style={{
                    width: "100%",
                    height: "80px",
                    fontSize: "32px",
                    paddingLeft: "50px",
                    backgroundColor: "#FFFFFF",
                    border: "1px solid #C8C8C8",
                    fontWeight: "700",
                  }}
                >
                  External Users
                </Card.Header>
                <Card.Body
                  style={{
                    backgroundColor: "#FDFCFC",
                    border: "1px solid #C8C8C8",
                  }}
                >
                  <Card.Title></Card.Title>
                  <Card.Text></Card.Text>
                  <button className="button2">See External Users</button>
                </Card.Body>
              </Card>
            </div>

            <div className="col-md-6 mobile-cards">
              <Card
                style={{
                  height: "354px",
                  marginTop: "30px",
                  border: "none",
                  marginRight: "16px",
                }}
              >
                <Card.Header
                  style={{
                    width: "100%",
                    height: "80px",
                    fontSize: "32px",
                    paddingLeft: "50px",
                    backgroundColor: "#FFFFFF",
                    border: "1px solid #C8C8C8",
                    fontWeight: "700",
                  }}
                >
                  Protocol
                </Card.Header>
                <Card.Body
                  style={{
                    backgroundColor: "#FDFCFC",
                    border: "1px solid #C8C8C8",
                  }}
                >
                  <Card.Title></Card.Title>
                  <Card.Text></Card.Text>
                  <button className="button3">Create New Protocol</button>
                </Card.Body>
              </Card>
            </div>
          </div>
        </div>
      </HomeWrapper>
    </>
  );
}

export default Home;
