
import React, { useEffect } from "react";
import styled from "styled-components";
import * as BiIcons from "react-icons/bi";
import * as IoIcons from "react-icons/io";
import { Link, useLocation } from "react-router-dom";
import ProfileHeader from "../../ProfileHeader";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Multiselect from "multiselect-react-dropdown";
import { useState } from "react";
import { Select } from "react-select";
import { flatten, get, isEmpty } from "lodash";
import { useRef } from "react";
import Form from "react-bootstrap/Form";
import CustomMultiSelect from '../../../Component/CustomMultiselect';
import CustomMultiSelectWithCheckbox from "../../../Component/CustomMultiSelectWithCheckbox";
import { useQuery, useMutation } from "react-query";
import {
  CreateUserRegister,
  GetAllAccount,
  GetControlData,
  SaveData,
} from "../../../Api";
import { rolesArray } from "../../../Constants";
import { ToastContainer, toast } from "react-toastify"; 

import "react-toastify/dist/ReactToastify.css";
import "./CreateUser.css"


const View = styled.div`
  .viewheading {
    padding-top: 20px;
  }
  .viewheading1 {
    padding-top: 20px;
    font-weight: 700;
    font-size: 24px;
    margin-top: 48px;
  }
  .iconback1 {
    color: #1e8ae7;
    padding-top: 32px;
    font-weight: 700;
    font-size: 16px;
  }
  .viewuser {
    font-weight: 700;
    font-size: 24px;
    font-style: normal;
    padding-top: 24px;
    font-family: Helvetica;
  }
  .viewuser1 {
    font-weight: 700;
    font-size: 24px;
    font-style: normal;
    padding-top: 24px;
    margin-right: 500px;
  }
  .view2 {
    font-weight: 700;
    font-size: 24px;
    font-style: normal;
    padding-top: 46px;
  }
`;
const Rectangle = styled.div`
  box-sizing: border-box;
  width: 100%;
  background: #ffffff;
  border: 1px solid #c8c8c8;
  border-radius: 4px;
`;
const UserForm = styled.div`
  .form-label {
    display: block;
    font-family: Helvetica;
    font-weight: 700;
    font-size: 16px;
    margin-bottom: 0;
  }
  .normal-input {
    height: 40px;
    width: 100%;
    border: 1px solid #c8c8c8;
    border-radius: 4px;
    margin-bottom: 24px;
    padding: 0 16px;
   
  
  }
  .normal-input:focus{
  
    color: #212529;
    background-color: #fff;
    border-color: #86b7fe;
    outline: 0;
    box-shadow: 0 0 0 0.25rem rgb(13 110 253 / 25%);
  }
  .col-md-6 {
    padding: 5px;
  }
  .searchWrapper {
    height: 40px;
  }
  .close-icon {
    height: 30px;
    width: 30px;
    position: absolute;
    right: 0;
  }
  .Inactive {
    height: 8px;
    width: 8px;
    border: 1px solid #ee3134;
    background: #ee3134;
    border-radius: 50%;
    display: inline-block;
    margin-right: 5px;
    font-size: 16px;
    font-weight: 400;
  }
  .Active {
    height: 8px;
    width: 8px;
    border: 1px solid #1bba3e;
    background: #1bba3e;
    border-radius: 50%;
    display: inline-block;
    margin-right: 5px;
    font-size: 16px;
    font-weight: 400;
  }
  .pending {
    height: 8px;
    width: 8px;
    border: 1px solid #eb9411;
    background: #eb9411;
    border-radius: 50%;
    display: inline-block;
    margin-right: 5px;
    font-size: 16px;
    font-weight: 400;
  }

  .icon-close {
    height: 26px;
    width: 26px;
    color: #808080;
  }
  .icon-close:hover {
    color: black;
  }
  .disabled {
    opacity: 0.5;
  }
  .disable-wrapper {
    opacity: 0.5;
    pointer-events: none;
  }
   
`;


const initialState = {
  trailsArray: [{ t__trial_id: "Select", t__trial_countries: [] }],
  trailsOriginalList: [],
  trailsFilteredData: [],
  trailcountryList: [],
  trailcountryFilteredData: [],
  searchCountyList: [],
  timezonelist: [],
  homecountrylist:[]
};

const ErrorList = {
  nameError: true,
  emailError: true,
  roleError: true,
  countryError: true,
  timezoneError: true,
  validEmailError: true,
  trailError: true,
};

function CreateUsers() {
  const [viewState, setViewState] = useState(initialState);
  const [errorState, setErrorState] = useState(ErrorList);

  const [email, setEmail] = useState("");
  const [name, setName] = useState("");

  const [mobile, setMobile] = useState();
  const [searchIndex ,setSearchIndex] = useState();


  const [selectedRole, setSelectedRole] = useState("");
  const [selectedCountry, setSelectedCountry] = useState("");
  const [selectedTimezone, setSelectedTimezone] = useState("");
  const [Active, setActive] = useState(false);
  const [isdisabled, setisDisabled] = useState(true);

  // const [trailsArray ,setTrailsArray] = useState([{trail: "", country:""},{trail: "", country:""}])

  const handleTrailRemove = (e) => {};
  useEffect(() => {
    setViewState({
      ...viewState,
      trailsArray: [{ t__trial_id: "Select", t__trial_countries: [] }],
      trailsOriginalList: get(GetControlApi, "data.data.data.trialList",[]),
      trailsFilteredData: get(GetControlApi,"data.data.data.trialList",[]),
    });
   
    
  }, [selectedRole])
  
  const handleTrialAdd = () => {
    let newObject = { t__trial_id: "Select", t__trial_countries: [] };
    let newArray = [...viewState.trailsArray];
    newArray.push(newObject);
    setViewState({
      ...viewState,
      trailsArray: newArray,
    });
  };
  const getSelctedItem = (value, index) => {
    let List = [...viewState.trailsArray];
    List[index].t__trial_id = value.t__trial_name;
    let filteredItem = viewState.trailsOriginalList.filter(
      (item) => !List.some((item2) => item.t__trial_name === item2.t__trial_id)
    );

    setViewState({
      ...viewState,
      trailsArray: List,
      trailsFilteredData: filteredItem,
    });
  };
  const getMultiSelctedItem = (selectedArray, index) => {
    let MultiList = [...viewState.trailsArray];
    MultiList[index].t__trial_countries = flatten(
      selectedArray.map((item) => item.t__name)
    );

    setViewState({
      ...viewState,
      trailsArray: MultiList,
    });
  };
  const handleRoleSelection = () => {};
  const removeRow = (item, index) => {
    let trailsList = [...viewState.trailsArray];
    trailsList.splice(index, 1);

    let filteredArray = [...viewState.trailsFilteredData];
    let newObject = {
      t__trial_id: item.t__trial_id,
      t__trial_name: item.t__trial_id,
    };
    filteredArray.push(newObject);

    setViewState({
      ...viewState,
      trailsArray: trailsList,
      trailsFilteredData: filteredArray,
    });
  };
  const handleSearchItem = (value,key) => {
    setSearchIndex(key)
    let searchList = [...viewState.trailcountryFilteredData];
    let newArray = searchList.filter((item) =>
      item.t__name.toLowerCase().includes(value.toLowerCase())
    );
    setViewState({
      ...viewState,
      searchCountyList: newArray,
    });
  };
  const getSelectedTimeZone = (timezone) => {
    setSelectedTimezone(timezone);
  };
  const getSelectedRole = (role) => {
    let previousValue = selectedRole;
    if (viewState.trailsArray.length === 0) {
      let trailsNewArray = [];
      if (["Administrator"].includes(role.roleName)) {
        trailsNewArray = [];
      } else {
        trailsNewArray = [{ t__trial_id: "Select", t__trial_countries: [] }];
      }
      setViewState({
        ...viewState,
        trailsArray: trailsNewArray,
      });
    }

    setSelectedRole(get(role,"roleName",""));
  };
  const getSelectedCountry = (country) => {
    setSelectedCountry(country);
  };
  const GetControlApi = useQuery(["GetControlApi"], GetControlData, {
    enabled: true,
    onSuccess: (res) => {
      setViewState({
        ...viewState,
        trailsOriginalList: res.data.data.trialList,
        trailsFilteredData: res.data.data.trialList,
        trailcountryList: res.data.data.countryList,
        trailcountryFilteredData: res.data.data.countryList,
        timezonelist: res.data.data.timezoneList,
        homecountrylist:res.data.data.homeCountryList
       
      });
    },
  });

  

  const SaveDataApi = useMutation("SaveDataApi", CreateUserRegister, {
    onSuccess: (res) => {
     
      // toast.success("Data saved successfully", {
      //   position: toast.POSITION.TOP_CENTER,
      // });
      alert("Internal user created successfully")
    },

    onError: () => {
      // toast.error("Error encountered while saving ", {
      //   position: toast.POSITION.TOP_CENTER,
      // });
      alert("Error while creating user")
    },
  });
  

  const updateApi = useMutation("updateApi", SaveData, {
    enabled: false,
    onSuccess: (res) => {
     
    },
    onError: () => {
    
    },
  });
  useEffect(() => {
    if(SaveDataApi.status === "success"){
      let roleString = rolesArray.filter(
        (item) => item.roleName === selectedRole
      );
      let payload = {       
        roles: !isEmpty(roleString) ? [roleString[0].roleId] : ""       
      };
    console.log("res",get(SaveDataApi,"data.data._id"))
    let id = get(SaveDataApi,"data.data._id")
    updateApi.mutate({id,payload})
    }
    console.log("saveDatat status",SaveDataApi.status)
  
  }, [SaveDataApi.isLoading])
  
  const handleErrorValidation = () => {
    let namefiled = !isEmpty(name) ? true : false;
    let emailfield = !isEmpty(email) ? true : false;
    let valiedemailfield =
      (!isEmpty(email) && email.includes("@thermofisher.com")) || isEmpty(email)
        ? false
        : true;
    let countryField = !isEmpty(selectedCountry) ? true : false;
    let roleField = !isEmpty(selectedRole) ? true : false;
    let timezone = !isEmpty(selectedTimezone) ? true : false;
    let trailRecord = viewState.trailsArray[0];
  
    let trailsErrorCheck =  true;
    if(!["Administrator"].includes(selectedRole)){
      trailsErrorCheck = !isEmpty(trailRecord.t__trial_countries) ?   true : false;
    } else{
      trailsErrorCheck = true
    }
    
    

    console.log("trailsErrorCheck",  !isEmpty(trailRecord.t__trial_countries) ,(selectedRole.includes(["Administrator"])),selectedRole)
    setErrorState({
      ...errorState,
      nameError: namefiled,
      emailError: emailfield,
      roleError: roleField,
      countryError: countryField,
      timezoneError: timezone,
      validEmailError: valiedemailfield,
      trailError: trailsErrorCheck
    });
    if (
      namefiled &&
      emailfield &&
      countryField &&
      roleField &&
      timezone &&
      !valiedemailfield &&
      trailsErrorCheck
       
    ) {
      return true;
    } else {
      return false;
    }
  };

  const handleSave = () => {
    const checkFlag = handleErrorValidation();

    let roleString = rolesArray.filter(
      (item) => item.roleName === selectedRole
    );
    let lastspaceindex = name.lastIndexOf(" ");
    let firstName = isEmpty(name.substring(0, lastspaceindex)) ?name.substring(lastspaceindex + 1) : name.substring(0, lastspaceindex) ;

    let lastName = isEmpty(name.substring(0, lastspaceindex))  ? "" : name.substring(lastspaceindex + 1);

    let newArray = viewState.trailsArray.map((item) => {
      return {
        t__trial_id: item.t__trial_id,
        t__trial_countries: item.t__trial_countries,
      };
    });

    let payload = {
      email: email,
      password: "Testuser123",
      t__status: "Active",
      t__home_country: selectedCountry.t__code,
      // mobile: mobile ? mobile.toString():"",
      name: {
        first: !isEmpty(firstName) ? firstName : "",
        last: !isEmpty(lastName) ? lastName : "",
      },
     
      tz: selectedTimezone.t__code,

      t__trial_country: !["Administrator"].includes(selectedRole)
        ? newArray
        : [],
      t__user_type: "Internal",
    };
    if (checkFlag) {
      SaveDataApi.mutate({ payload });
    }
  };

  console.log("valids object", selectedCountry, selectedRole, selectedTimezone);

  const handlecancel = () => {
    // GetAllAccountApi.refetch();
    setName("");
    setEmail("");
    setMobile("")
    setSelectedRole("");
    setSelectedCountry("");
    setSelectedTimezone("");
    console.log(" get(GetControlApi", get(GetControlApi,"data.data.data.trialList",[]))
    setViewState({
      ...viewState,
      trailsArray: [{ t__trial_id: "Select", t__trial_countries: [] }],
      trailsFilteredData: get(GetControlApi,"data.data.data.trialList",[])
    });
    setErrorState({
      ...errorState,
      nameError: true,
      emailError: true,
      roleError: true,
      countryError: true,
      timezoneError: true,
      validEmailError: true,
      trailError:true,
    });
  };
  console.log("selectedRole", selectedRole);
  console.log("SaveDataApi",SaveDataApi)

  return (
    <>
      <ProfileHeader />
      <View>
        <h1 className="Heading6">Internal Users</h1>
        <div className="iconback1">
          {" "}
          <BiIcons.BiArrowBack
            style={{ height: "24px", width: "24px", color: "#1E8AE7" }}
          />{" "}
          <Link style={{ textDecoration: "none" }} to="/internalusers">
            {" "}
            Back
          </Link>
        </div>
        <Row>
          <Col className="col-md-3">
            {" "}
            <p className="Heading7 ">Create new user</p>
          </Col>
        </Row>
        <Row>
          <Col className="col-md-12">
          
              <UserForm>
                <div>
                  <div
                    style={{
                      marginTop: "24px",
                      border: "1px solid #C8C8C8",
                      borderRadius: "4px",
                      padding: "32px 16px 32px 32px",
                    }}
                    className="d-flex flex-wrap"
                  >
                    <div
                      style={{ display: "inline-block" }}
                      className="col-md-4"
                    >
                      <lable className="form-label"> Name:</lable>
                      <input
                        className="normal-input"
                        type="text"
                        name="name"
                        placeholder="Enter name"
                        value={name}
                        onChange={(e) => {
                          setName(e.target.value);
                          setisDisabled(false);
                        }}
                        style={{
                          height: "40px",
                          width: "calc(100% - 16px)",

                          border: "1px solid #C8C8C8",
                        }}
                      ></input>
                      {!errorState.nameError && isEmpty(name) && (
                        <p style={{ color: "red", marginTop: "-25px" }}>
                          Name is required
                        </p>
                      )}
                    </div>
                    <div
                      style={{ display: "inline-block" }}
                      className="col-md-4"
                    >
                      <div>
                        <Row>
                          <Col>
                            <lable className="form-label">Email:</lable>
                          </Col>
                        </Row>
                      </div>
                      <input
                        type="text"
                        className="normal-input"
                        placeholder="Enter email"
                        name="email"
                        value={email}
                        style={{
                          height: "40px",
                          width: "calc(100% - 16px)",

                          borderRadius: "4px",
                          border: "1px solid #C8C8C8",
                        }}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                      {!errorState.emailError && isEmpty(email) && (
                        <p style={{ color: "red" ,marginTop:"-24px"}}>Email is required</p>
                      )}
                      {errorState.validEmailError &&
                        !isEmpty(email) &&
                        !email.includes("@thermofisher.com") && (
                          <p style={{ color: "red" ,marginTop:"-24px"}}>Enter Valid Email</p>
                        )}
                    </div>
                    <div
                      style={{ display: "inline-block" }}
                      className="col-md-4"
                    >
                      <div>
                        <Row>
                          <Col>
                            <lable className="form-label">Mobile (Optional):</lable>
                          </Col>
                        </Row>
                      </div>
                      <input
                        type="number"
                        className="normal-input"
                        placeholder="Enter mobile number"
                        name="mobile"
                        value={mobile}
                        style={{
                          height: "40px",
                          width: "calc(100% - 16px)",

                          borderRadius: "4px",
                          border: "1px solid #C8C8C8",
                        }}
                        onChange={(e) => setMobile(e.target.value)}
                      />
                    </div>

                    <div
                      style={{ display: "inline-block" }}
                      className="col-md-4"
                    >
                      <div>
                        {" "}
                        <lable className="form-label">Role:</lable>
                        <CustomMultiSelect
                          key={"role-dropdown"}
                          options={rolesArray}
                          getSelctedItem={(e) => {
                            getSelectedRole(e);
                          }}
                          getSelected={selectedRole}
                          optionKey={"roleName"}
                          optionValue={"roleId"}
                          width={"calc(100% - 16px)"}
                        />
                        {!errorState.roleError && isEmpty(selectedRole) && (
                          <p style={{ color: "red" }}>Role is required</p>
                        )}
                      </div>
                    </div>

                    <div
                      style={{ display: "inline-block" }}
                      className="col-md-4"
                    >
                      <lable className="form-label">Country:</lable>
                      <CustomMultiSelect
                        key={"country-dropdown"}
                        options={viewState.homecountrylist.filter(item =>item.t__code !== "All")}
                        getSelctedItem={(e) => getSelectedCountry(e)}
                        getSelected={get(selectedCountry, "t__name", "")}
                        optionKey={"t__name"}
                        optionValue={"t__code"}
                        width={"calc(100% - 16px)"}
                      />
                      {!errorState.countryError && isEmpty(selectedCountry) && (
                        <p style={{ color: "red" }}>Country is required</p>
                      )}
                    </div>

                    <div
                      style={{ display: "inline-block" }}
                      className="col-md-4"
                    >
                      <div>
                        {" "}
                        <lable className="form-label">Time zone:</lable>
                        <CustomMultiSelect
                          options={get(
                            GetControlApi,
                            "data.data.data.timezoneList",
                            []
                          )}
                          getSelctedItem={(e) => getSelectedTimeZone(e)}
                          getSelected={get(selectedTimezone, "t__name", "")}
                          optionKey={"t__name"}
                          optionValue={"t__code"}
                          width={"calc(100% - 16px)"}
                        />
                        {!errorState.timezoneError &&
                          isEmpty(selectedTimezone) && (
                            <p style={{ color: "red" }}>Time zone is required</p>
                          )}
                      </div>
                    </div>
                  </div>

                  {!["Administrator"].includes(selectedRole) && (
                    <div className="trial-country-wrapper">
                      <p className="viewheading1 ">Trial and Country</p>

                      {viewState.trailsArray && viewState.trailsArray.map((item, index) => (
                        <div
                          key={index}
                          className="d-flex trail-rows"
                          style={{ marginBottom: "24px" }}

                        >
                          <div style={{ display: "inline-block" }}>
                            <lable className="form-label">Trial:</lable>
                            {console.log("item.t__trial_id",item.t__trial_id)}
                            <CustomMultiSelect
                              key={index}
                              options={viewState.trailsFilteredData}
                              getSelctedItem={(e) => getSelctedItem(e, index)}
                              getSelected={item.t__trial_id}
                              optionKey={"t__trial_id"}
                              optionValue={"t__trial_name"}
                            />
                              {
                            !errorState.trailError && viewState.trailsArray[0].t__trial_id === "Select" && <p style={{ color: "red" }}>Trial is required</p>
                          }
                          </div>
                          <div
                            style={{
                              display: "inline-block",
                              marginLeft: "16px",
                            }}
                          >
                            <lable className="form-label">Trial country:</lable>
                            {console.log("item.t__trial_countries",item.t__trial_countries)}
                            <CustomMultiSelectWithCheckbox
                              key={index}
                              indexItem={index}
                              options={
                                searchIndex === index &&
                                viewState.searchCountyList &&
                                viewState.searchCountyList.length > 0
                                  ? viewState.searchCountyList
                                  : viewState.trailcountryFilteredData
                              }
                              getMultiSelctedItem={(e) =>
                                getMultiSelctedItem(e, index)
                              }
                              getseletedCountries={item.t__trial_countries}
                              showCheckbox={true}
                              showSearch={true}
                              handleSearchItem={handleSearchItem}
                              defaultOptions={ viewState.trailcountryFilteredData}
                            />
                             {
                            !errorState.trailError && viewState.trailsArray[0].t__trial_countries.length === 0 && <p style={{ color: "red" }}>Trial county is required</p>
                          }
                          </div>
                         
                          <div
                            style={{ 
                              marginTop: "32px",
                              marginLeft: "16px",
                              display: "inline-block",
                            }}
                          >
                            {
                               viewState.trailsArray.length >1 &&
                              <IoIcons.IoMdCloseCircle
                              className="icon-close"
                              key={index}
                              onClick={() => removeRow(item, index)}
                            />
                            }
                            
                          </div>
                        </div>
                      ))}

                      <button
                        type="button"
                        onClick={() => handleTrialAdd()}
                        style={{
                          textDecoration: "none",
                          fontWeight: "700",
                          outline: "none",
                          border: "none",
                          color: "#1E8AE7",
                          background: "white",
                          marginTop: "10px",
                        }}
                      >
                        Add new Trial & Country
                      </button>
                    </div>
                  )}
                </div>

                <div>
                  <div style={{ display: "inline-block" }}>
                    <button className={`btn4`} onClick={handleSave}>
                      Save
                    </button>
                    <button
                      type="button"
                      className="btn5"
                      onClick={handlecancel}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
                <ToastContainer />
              </UserForm>
           
          </Col>
        </Row>
      </View>
    </>
  );
}

export default CreateUsers;
