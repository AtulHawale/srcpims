import React from 'react'
import ProfileHeader from '../ProfileHeader'
import './UploadUsers.css'
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";




function UploadUsers() {
    return (
        <>
            <ProfileHeader />

            <h2 className="heading-upload ">Internal Users</h2>
            <div className="upload-heading">Upload new users</div>
            < div className="Download">Download Excel Template</div>
            <div className='rectangle'>
                <div className='text-rect'>
                    Drag and drop Excel files here to import <br>
                    </br>or browse files
                </div>
            </div>

            <Row >
                <Col>
                    <button className="btn4">Upload</button>
                    <button type="button" className="btn5">Cancel</button>
                </Col>
            </Row>





        </>
    )
}

export default UploadUsers