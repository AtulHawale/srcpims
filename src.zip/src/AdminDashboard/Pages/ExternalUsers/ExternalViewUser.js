import React, { useEffect } from "react";
import styled from "styled-components";
import * as BiIcons from "react-icons/bi";
import * as IoIcons from "react-icons/io";
import { Link, useLocation } from "react-router-dom";
import ProfileHeader from "../../ProfileHeader";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Multiselect from "multiselect-react-dropdown";
import { useState } from "react";
import { Select } from "react-select";
import { flatten, get, isEmpty,_ } from "lodash";
import { useRef } from "react";
import Form from "react-bootstrap/Form";

import CustomMultiSelect from '../../../Component/CustomMultiselect';
import { useQuery, useMutation } from "react-query";
import { GetAllAccount, GetControlData, SaveData } from "./../../../Api";
import { rolesArray } from "../../../Constants";
import Loader from "react-loader";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const View = styled.div`
  .viewheading {
    padding-top: 20px;
  }
  .viewheading1 {
    padding-top: 20px;
    font-weight: 700;
    font-size: 24px;
    margin-top: 48px;
  }
  .iconback1 {
    color: #1e8ae7;
    padding-top: 32px;
    font-weight: 700;
    font-size: 16px;
    padding-left: 10px;
  }
  .viewuser {
    font-weight: 700;
    font-size: 24px;
    font-style: normal;
    padding-top: 24px;
    font-family: Helvetica;
  }
  .viewuser1 {
    font-weight: 700;
    font-size: 24px;
    font-style: normal;
    padding-top: 24px;
    margin-right: 500px;
  }
  .view2 {
    font-weight: 700;
    font-size: 24px;
    font-style: normal;
    padding-top: 46px;
  }
`;
const UserForm = styled.div`
  .form-label {
    display: block;
    font-family: Helvetica;
    font-weight: 700;
    font-size: 16px;
    margin-bottom: 0;
  }
  .normal-input {
    height: 40px;
    width: 100%;
    border: 1px solid #c8c8c8;
    border-radius: 4px;
    outline:none;
   
    padding: 0 16px;
    cursor: pointer;
  }
  .normal-input:focus{
  
    color: #212529;
    background-color: #fff;
    border-color: #86b7fe;
    outline: 0;
    box-shadow: 0 0 0 0.25rem rgb(13 110 253 / 25%);
  }
  .col-md-6 {
    padding: 5px;
  }
  .searchWrapper {
    height: 40px;
  }
  .close-icon {
    height: 30px;
    width: 30px;
    position: absolute;
    right: 0;
  }
  .inactive {
    height: 8px;
    width: 8px;
    border: 1px solid #ee3134;
    background: #ee3134;
    border-radius: 50%;
    display: inline-block;
    margin-right: 5px;
    font-size: 16px;
    font-weight: 400;
  }
  .active {
    height: 8px;
    width: 8px;
    border: 1px solid #1bba3e;
    background: #1bba3e;
    border-radius: 50%;
    display: inline-block;
    margin-right: 5px;
    font-size: 16px;
    font-weight: 400;
  }
  .pending {
    height: 8px;
    width: 8px;
    border: 1px solid #eb9411;
    background: #eb9411;
    border-radius: 50%;
    display: inline-block;
    margin-right: 5px;
    font-size: 16px;
    font-weight: 400;
  }

  .icon-close {
    height: 26px;
    width: 26px;
    color: #808080;
  }
  .icon-close:hover {
    color: black;
  }
  .disabled {
    opacity: 0.5;
  }
  .disable-wrapper {
    opacity: 0.5;
    pointer-events: none;
  }
`;

const countriesdata = [
  { trial: "All", trialCountry: "*" },
  { trial: "India", trialCountry: "India" },
  { trial: "Aus", trialCountry: "Aus" },
  { trial: "England", trialCountry: "England" },
  { trial: "USA", trialCountry: "USA" },
  { trial: "NZ", trialCountry: "NZ" },
];
const trialsData = [
  { key: "All", value: "*" },
  { key: "India", value: "India" },
  { key: "Aus", value: "Aus" },
  { key: "England", value: "England" },
  { key: "USA", value: "USA" },
  { key: "NZ", value: "NZ" },
];
const initialState = {
  trailsArray: [{ t__trial_id: "Select", t__trial_sites: "" }],
  trailsOriginalList: [],
  trailsFilteredData: [],
  trailcountryList: [],
  trailcountryFilteredData: [],
  searchCountyList: [],
  timezonelist: [],
  sitesList:[],
  sitesFilteredList:[],
  sitesOriginalList:[]

};

function ExternalViewUsers() {
  const [viewState, setViewState] = useState(initialState);
  const [rolesRemoved, setRolesRemoved] = useState([]);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const multiselectRef = useRef();
  // const [selectedItem,setSelectedItem] = useState("Select")
  const location = useLocation();
  const id = new URLSearchParams(location.search).get("id");
  const [selectedRole, setSelectedRole] = useState("");
  const [selectedCountry, setSelectedCountry] = useState("");
  const [selectedTimezone, setSelectedTimezone] = useState("");
  const [Active, setActive] = useState();
  const [isdisabled, setisDisabled] = useState(true);
  const [searchIndex ,setSearchIndex] = useState();
  const [mobile,setMobile] = useState("")

  // const [trailsArray ,setTrailsArray] = useState([{trail: "", country:""},{trail: "", country:""}])

  const handleTrailRemove = (e) => {};
  const handleTrialAdd = () => {
    let newObject = { t__trial_id: "Select", t__trial_sites: "" };
    let newArray = [...viewState.trailsArray];
    newArray.push(newObject);
    setViewState({
      ...viewState,
      trailsArray: newArray,
    });
  };
  const getSelctedItem = (value, index) => {
    let List = [...viewState.trailsArray];
    List[index].t__trial_id = value.t__trial_name;
    let filteredItem = viewState.trailsOriginalList.filter(
      (item) => !List.some((item2) => item.t__trial_name === item2.t__trial_id)
    );

    setViewState({
      ...viewState,
      trailsArray: List,
      trailsFilteredData: filteredItem,
    });
  };
 
  const removeRow = (item, index) => {
    console.log("item 226",item)
    let trailsList = [...viewState.trailsArray];
    trailsList.splice(index, 1);

    let filteredArray = [...viewState.trailsFilteredData];
    let newObject = {
      t__trial_id: item.t__trial_id,
      t__trial_name: item.t__trial_id,
    };
    let filtedSite = [...viewState.sitesFilteredList];
    filtedSite.push(item.t__trial_sites)
    
    filteredArray.push(newObject);

    setViewState({
      ...viewState,
      trailsArray: trailsList,
      trailsFilteredData: filteredArray,
      sitesFilteredList: filtedSite
    });
  };
  const handleSearchItem = (value,key) => {
    setSearchIndex(key)
    let searchList = [...viewState.trailcountryFilteredData];
   
    console.log("values in item",value)
    
    let newArray = searchList.filter((item) =>
      item.t__name.toLowerCase().includes(value.toLowerCase())
    );
    console.log("newArray",newArray)
    const optionsArray = []
   
    setViewState({
      ...viewState,
      searchCountyList: newArray,
    });
  };
  const getSelectedTimeZone = (timezone) => {
    setSelectedTimezone(timezone);
  };
  const getSelectedRole = (role) => {
    let previousValue = selectedRole;
    if (viewState.trailsArray.length === 0) {
      let trailsNewArray = [];
      if (["Administrator"].includes(role.roleName)) {
        trailsNewArray = [];
      } else {
        trailsNewArray = [{ t__trial_id: "Select", t__trial_countries: [] }];
      }
      setViewState({
        ...viewState,
        trailsArray: trailsNewArray,
      });
    }

    setSelectedRole(role.roleName);
  };
  const getSelectedSite = (value,index) => {
    console.log("getSelectedSite",value,index)
    let List = [...viewState.trailsArray];
    List[index].t__trial_sites = value.t__name;
    console.log("sitesOriginalList",viewState.sitesOriginalList,List)
    let filteredItem = viewState.sitesOriginalList.filter(
      (item) => !List.some((item2) => item.t__name
      === item2.t__trial_sites)
    );

    setViewState({
      ...viewState,
      trailsArray: List,
      sitesFilteredList: filteredItem,
    });

  }
  const getSelectedCountry = (country) => {
    setSelectedCountry(country);
  };
  const GetControlApi = useQuery(["GetControlApi"], GetControlData, {
    enabled: true,
    onSuccess: (res) => {
      setViewState({
        ...viewState,
        trailsOriginalList: res.data.data.trialList,
        trailsFilteredData: res.data.data.trialList,
        trailcountryList: res.data.data.countryList,
        trailcountryFilteredData: res.data.data.countryList,
        timezonelist: res.data.data.timezoneList,
        sitesList:res.data.data.siteList,
        sitesFilteredList:res.data.data.siteList,
        sitesOriginalList:res.data.data.siteList
      });
    },
  });

  const GetAllAccountApi = useQuery(["GetAllAccountApi", id], GetAllAccount, {
    enabled: !GetControlApi.isLoading,
    onSuccess: (res) => {
      setisDisabled(true);
      setEmail(res.data.email);
      console.log("mobile",parseInt(res.data.mobile))     
      setMobile(parseInt(res.data.mobile));
      let countryList = [...viewState.trailcountryList];
      let countryRecord = countryList.filter(
        (item) => item.t__code === res.data.t__home_country || item.t__name === res.data.t__home_country
      );
      console.log("countryRecord",countryRecord)
      setSelectedCountry(get(countryRecord, "[0]", ""));
      let timezoneList = [...viewState.timezonelist];
      let timezonerecord = timezoneList.filter(
        (item) => item.t__code === res.data.tz
      );

      setSelectedTimezone(get(timezonerecord, "[0]", ""));
      let roleString = rolesArray.filter(
        (item) => item.roleId === res.data.roles[0]
      );
      if (roleString && roleString.length > 0) {
        setSelectedRole(roleString[0].roleName);
      }

      let fullName = [res.data.name.first, res.data.name.last]
        .filter(Boolean)
        .join(" ");
      // fullName.replaceAll(",", " ").replace(/\s/g, "");
      setName(fullName);

      let initialFilteredList = [...viewState.trailsFilteredData];
      let finalFinalFilteredList = initialFilteredList.filter(
        (item) =>
          !res.data.t__trial_sites.some(
            (item2) => item.t__trial_id == item2.t__trial_id
          )
      );

      let status = get(res, "data.t__status","");
      setActive(status)

      // if (["Active", "active", "ACTIVE"].includes(status)) {
      //   setActive(true);
      // } else {
      //   setActive(false);
      // }

      setViewState({
        ...viewState,
        trailsArray: res.data.t__trial_sites,
        trailsFilteredData: finalFinalFilteredList,
      });
    },
    onError: (res) => {
      alert(res);
    },
  });

  const SaveDataApi = useMutation("SaveDataApi", SaveData, {
    onSuccess: (res) => {
      // toast.success("Account updated successfully", {
      //   position: toast.POSITION.TOP_CENTER,
      // });
      alert("Account updated successfully")
      GetAllAccountApi.refetch()
    },

    onError: () => {
      // toast.error("Error encountered while saving ", {
      //   position: toast.POSITION.TOP_CENTER,
      // });
      alert("Error encountered while saving")
    },
  });
  const handlevalidation = () => {
    let nameError = !isEmpty(name)
    let mobileError = !isEmpty(mobile)
    // let trailIdError = viewState.trailsArray[0].t__trial_id !== "Select"
    // let trailCountryError = viewState.trailsArray[0].t__trial_countries. length > 0 ? true : false
   return nameError && mobileError

  }

  const handleSave = () => {
    const checkFlag = handlevalidation()
    console.log("checkFlag",checkFlag)
    let roleString = rolesArray.filter(
      (item) => item.roleName === selectedRole
    );
    
    // let lastspaceindex = name.lastIndexOf(" ");
    // console.log("lastspaceindex",lastspaceindex,name.split(" "))
    
   
    // let firstName = isEmpty(name.substring(0, lastspaceindex)) ?name.substring(lastspaceindex + 1) : name.substring(0, lastspaceindex) ;
    // let lastName = isEmpty(name.substring(0, lastspaceindex))  ? "" : name.substring(lastspaceindex + 1);

    let newArray = viewState.trailsArray.map((item) => {
      return {
        t__trial_id: item.t__trial_id,
        t__trial_sites: item.t__trial_sites,
      };
    });
    let newArray1 = newArray.filter(item => item.t__trial_id !== "Select")

    let payload = {
      email: email,
      t__status: Active,      
      name: {
        first: !isEmpty(name) ? name : ""        
      },
      mobile:mobile.toString(),
      roles: !isEmpty(roleString) ? [roleString[0].roleId] : "",
      
      t__trial_sites: newArray1
    };
    if(checkFlag){
      SaveDataApi.mutate({ id, payload });
    }
    
  };

  const handlecancel = () => {
    GetAllAccountApi.refetch();
    setSelectedRole("")
   
  };
  console.log("viewState",mobile)

 
  return (
    <>
      <ProfileHeader />
      <View>
        <h1 className="Heading6">External Users</h1>
        <div className="iconback1">
          {" "}
          <BiIcons.BiArrowBack
            style={{ height: "24px", width: "24px", color: "#1E8AE7" }}
          />{" "}
          <Link style={{ textDecoration: "none" }} to="/externalusers">
            {" "}
            Back
          </Link>
        </div>
        <Row>
          <Col className="col-md-3">
            {" "}
            <h3 className="viewuser ">View user</h3>
          </Col>
          <Col className="col-md-9">
            {" "}
            <h3 className="viewuser1 ">Information</h3>
            {!GetAllAccountApi.isLoading && !GetControlApi.isLoading ? (
              <UserForm>
                <div style={{ display: "inline-block" }}>
                  <div>
                    <Row style={{ marginTop: "16px" }}>
                      <Col style={{ marginRight: "20px" }}>
                        <lable className="form-label">Email:</lable>
                      </Col>
                      <Col>
                        <div>
                          <div className={Active.toLowerCase()}></div>
                          <span>{Active}</span>
                        </div>
                      </Col>
                    </Row>
                  </div>
                  <input
                    type="text"
                    name="email"
                    value={email}
                    style={{
                      height: "40px",
                      width: "300px",
                      padding: "0 16px",
                      borderRadius: "4px",
                      border: "1px solid #C8C8C8",
                      background: "#E6E6E6",
                    }}
                    onChange={(e) => setEmail(e.target.email)}
                    disabled={true}
                  />{" "}
                  {
                    ["inactive"].includes(Active.toLowerCase()) &&  <span
                    style={{
                      cursor: "pointer",
                      color: "#1E8AE7",
                      fontSize: "16px",
                      fontWeight: "700",
                      paddingLeft: "16px",
                    }}
                    onClick={() => {
                      setActive("Active");                  
                      setisDisabled(false);                   
                    }}
                    className={`${Active.toLowerCase()  === "inactive" && get(GetAllAccountApi,"data.data.t__status","").toLowerCase() === "pending" ? "disable-wrapper": ""}`}
                  >
                    {" "}
                    Activate user
                  </span>
                  }
                  {
                    ["active","pending"].includes(Active.toLowerCase()) &&  <span
                    style={{
                      cursor: "pointer",
                      color: "#1E8AE7",
                      fontSize: "16px",
                      fontWeight: "700",
                      paddingLeft: "16px",
                    }}
                    onClick={() => {
                      setActive("Inactive")
                      setisDisabled(false);
                    
                    }}
                  >
                    {" "}
                    Inactivate user
                  </span>
                  }
                 
                 
                </div>
                <div className={`${Active.toLowerCase() !== "inactive" ? "" : "disable-wrapper"} `}>
                  <div style={{ marginTop: "24px" }} className="d-flex">
                    <div style={{ display: "inline-block" }}>
                      <lable className="form-label"> Name:</lable>
                      <input
                        className="normal-input"
                        type="text"
                        name="name"
                        value={name}
                        onChange={(e) => {
                          setName(e.target.value);
                          setisDisabled(false);
                        }}
                        style={{
                          height: "40px",
                          width: "300px",
                          borderRadius: "4px",
                          border: "1px solid #C8C8C8",
                        }}
                      ></input>
                      {isEmpty(name) && (
                        <p style={{ color: "red" }} > Name is required</p>
                      )}
                    </div>
                    <div
                      style={{ display: "inline-block",width: "300px",marginLeft:"16px"}}
                     
                    >
                      <div>
                        <Row>
                          <Col>
                            <lable className="form-label">Mobile :</lable>
                          </Col>
                        </Row>
                      </div>
                      <input
                        type="number"
                        className="normal-input"
                        placeholder="Enter mobile number"
                        name="mobile"
                        value={mobile}
                   
                        style={{
                          height: "40px",
                          width: "calc(100% - 16px)",

                          borderRadius: "4px",
                          border: "1px solid #C8C8C8",
                        }}
                        onChange={(e) => {
                          setMobile(e.target.value);
                        
                        }}
                      />
                     
                      {isEmpty(mobile.toString()) && (
                        <p style={{ color: "red" }}>
                          mobile is required
                        </p>
                      )}
                    </div>

                   
                  </div>
                  <div style={{marginTop:'24px' ,display:'flex'}}>
                  <div style={{ display: "inline-block" }}>
                      <div >
                        {" "}
                        <lable className="form-label">Role:</lable>
                        
                        {console.log("599", rolesArray.filter((item) => item.roleName === "External Patient Manager"))}
                        <CustomMultiSelect
                          key={"role-dropdown"}
                          options={rolesArray.filter((item) => item.roleName === "External Patient Manager")}
                          getSelctedItem={(e) => {
                            getSelectedRole(e);
                            setisDisabled(false);
                          }}
                          getSelected={selectedRole}
                          optionKey={"roleName"}
                          optionValue={"roleId"}
                        />
                      </div>
                    </div>
                  </div>
                  {!["Administrator"].includes(selectedRole) && (
                    <div className="trial-country-wrapper">
                      <p className="viewheading1 ">Trial and Site</p>

                      {viewState.trailsArray.map((item, index) => (
                        <div key={index} className="d-flex" style={{marginBottom:"16px"}}>
                          <div style={{ display: "inline-block" }}>
                            <lable className="form-label">Trial:</lable>
                            {console.log("index",index)}
                            <CustomMultiSelect
                              key={index}
                              keyIndex={index}
                              options={viewState.trailsFilteredData.filter(item =>item.t__trial_id !== 'Select')}
                              getSelctedItem={(e) =>{ getSelctedItem(e, index)
                                setisDisabled(false);
                              }}
                  
                              getSelected={item.t__trial_id}
                              
                              optionKey={"t__trial_id"}
                              optionValue={"t__trial_name"}
                            />
                            {viewState.trailsArray[0].t__trial_id === "Select" && <p style={{ color: "red" }}>Trial is required</p>}
                          </div>
                          <div
                            style={{
                              display: "inline-block",
                              marginLeft: "16px",
                            }}
                          >
                            <lable className="form-label">Site:</lable>
                            <CustomMultiSelect
                              key={index}
                              keyIndex={index}
                              options={viewState.sitesFilteredList.filter(item =>item.t__trial_id !== 'Select')}
                              getSelctedItem={(e) =>{ getSelectedSite(e, index)
                                setisDisabled(false);
                              }}
                  
                              getSelected={item.t__trial_sites}
                              
                              optionKey={"t__name"}
                              optionValue={"t__code"}
                            />
                            
                          </div>
                          <div
                            style={{
                              marginTop: "32px",
                              marginLeft: "16px",
                              display: "inline-block",
                            }}
                          >

                            { viewState.trailsArray.length > 1 &&
                               <IoIcons.IoMdCloseCircle
                              className="icon-close"
                              key={index}
                              onClick={() =>{removeRow(item, index)
                              setisDisabled(false);}}
                            
                            />
                            }
                           
                          </div>
                        </div>
                      ))}

                      <button
                        type="button"
                        onClick={() => handleTrialAdd()}
                        style={{
                          textDecoration: "none",
                          fontWeight: "700",
                          outline: "none",
                          border: "none",
                          color: "#1E8AE7",
                          background: "white",
                          marginTop: "10px",
                        }}
                      >
                        Add new Trial & Site
                      </button>
                    </div>
                  )}
                </div>

                <div>
                  <div style={{ display: "inline-block" }}>
                    <button
                      className={`btn4 ${isdisabled ? "disabled" : ""}`}
                      onClick={handleSave}
                      disabled={isdisabled}
                    >
                      Save
                    </button>
                    <button
                      type="button"
                      className="btn5"
                      onClick={handlecancel}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
                <ToastContainer />
              </UserForm>
            ) : (
              <Loader />
            )}
          </Col>
        </Row>
      </View>
    </>
  );
}

export default ExternalViewUsers;
