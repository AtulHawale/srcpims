import React, { useEffect } from "react";
import styled from "styled-components";
import * as BiIcons from "react-icons/bi";
import * as IoIcons from "react-icons/io";
import { Link, useLocation } from "react-router-dom";
import ProfileHeader from "../../ProfileHeader";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import { useState } from "react";
import { flatten, get, isEmpty } from "lodash";
import CustomMultiSelect from '../../../Component/CustomMultiselect';
import { useQuery, useMutation } from "react-query";
import {
  CreateExternalRegister,
  CreateUserRegister,
  GetAllAccount,
  GetControlData,
  SaveData,
} from "../../../Api";
import { rolesArray } from "../../../Constants";
import Loader from "react-loader";
import { ToastContainer, toast } from "react-toastify";

import "react-toastify/dist/ReactToastify.css";
import '../InternalUsers/CreateUser.css'

const View = styled.div`
  .viewheading {
    padding-top: 20px;
  }
  .viewheading1 {
    padding-top: 20px;
    font-weight: 700;
    font-size: 24px;
    margin-top: 48px;
  }
  .iconback1 {
    color: #1e8ae7;
    padding-top: 32px;
    font-weight: 700;
    font-size: 16px;
  }
  .viewuser {
    font-weight: 700;
    font-size: 24px;
    font-style: normal;
    padding-top: 24px;
    font-family: Helvetica;
  }
  .viewuser1 {
    font-weight: 700;
    font-size: 24px;
    font-style: normal;
    padding-top: 24px;
    margin-right: 500px;
  }
  .view2 {
    font-weight: 700;
    font-size: 24px;
    font-style: normal;
    padding-top: 46px;
  }
  .form-label {
    display: block;
    font-family: Helvetica;
    font-weight: 700;
    font-size: 16px;
    margin-bottom: 0;
  }
`;

const UserForm = styled.div`
  .form-label {
    display: block;
    font-family: Helvetica;
    font-weight: 700;
    font-size: 16px;
    margin-bottom: 0;
  }
  .normal-input {
    height: 40px;
    width: 100%;
    border: 1px solid #c8c8c8;
    border-radius: 4px;
    margin-bottom: 24px;
    padding: 0 16px;
  }
  .normal-input:focus {
    color: #212529;
    background-color: #fff;
    border-color: #86b7fe;
    outline: 0;
    box-shadow: 0 0 0 0.25rem rgb(13 110 253 / 25%);
  }
  
  .searchWrapper {
    height: 40px;
  }
  
 
  .icon-close {
    height: 26px;
    width: 26px;
    color: #808080;
  }
  .icon-close:hover {
    color: black;
  }
  
`;

const initialState = {
  trailsArray: [{ t__trial_id: "Select", t__trial_countries: [] }],
  trailsOriginalList: [],
  trailsFilteredData: [],
  trailcountryList: [],
  trailcountryFilteredData: [],
  searchCountyList: [],
  timezonelist: [],
};

const ErrorList = {
  nameError: true,
  emailError: true,
  mobileError: true,
  roleError: true,
  validEmailError: true,
  siteError: true,
  trailError: true,
};

function ExternalCreateUsers() {
  const [viewState, setViewState] = useState(initialState);
  const [input, setInput] = useState([
    { email: "", mobile: "", name:{first:""}, role: "" },
  ]);
  console.log(input, "input");

  const [errorState, setErrorState] = useState(ErrorList);

  const [email, setEmail] = useState("");
  const [name, setName] = useState("");

  const [mobile, setMobile] = useState();
  const [searchIndex, setSearchIndex] = useState();

  const [selectedRole, setSelectedRole] = useState("");
  const [selectedCountry, setSelectedCountry] = useState("");
  const [selectedTimezone, setSelectedTimezone] = useState("");
  const [selectedsite, setSelectedsite] = useState("");



  useEffect(() => {
    setViewState({
      ...viewState,
      trailsArray: [{ t__trial_id: "Select" }],
      trailsOriginalList: get(GetControlApi, "data.data.data.trialList", []),
      trailsFilteredData: get(GetControlApi, "data.data.data.trialList", []),
    });
  }, [selectedRole]);

  const handleTrialAdd = () => {
    setInput([...input, { email: "", mobile: "",name:{first:""}, role: "" }]);
  };
  const handleServiceRemove = (index) => {
    const list = [...input];
    list.splice(index, 1);
    setInput(list);
  };

  const getSelctedItem = (value, index) => {
    let List = [...viewState.trailsArray];
    List[index].t__trial_id = value.t__trial_name;
    let filteredItem = viewState.trailsOriginalList.filter(
      (item) => !List.some((item2) => item.t__trial_name === item2.t__trial_id)
    );

    setViewState({
      ...viewState,
      trailsArray: List,
      trailsFilteredData: filteredItem,
    });
  };

  const getSelectedsite = (site) => {
    setSelectedsite(site);
  };

  const getSelectedRole = (role, index) => {
    console.log("role 293", role)
    let newArray = [...input]
    newArray[index].role = get(role, "roleName", "")
    setInput(newArray)
  };

  const GetControlApi = useQuery(["GetControlApi"], GetControlData, {
    enabled: true,
    onSuccess: (res) => {
      setViewState({
        ...viewState,
        trailsOriginalList: res.data.data.trialList,
        trailsFilteredData: res.data.data.trialList,
        trailsitelist: res.data.data.siteList,
      });
    },
  });

  const SaveDataApi = useMutation("SaveDataApi", CreateExternalRegister, {
    onSuccess: (res) => {
      // toast.success("Data saved successfully", {
      //   position: toast.POSITION.TOP_CENTER,
      // });
      alert("External user created successfully");
    },

    onError: () => {
      // toast.error("Error encountered while saving ", {
      //   position: toast.POSITION.TOP_CENTER,
      // });
      alert("Error while creating user");
    },
  });

  const updateApi = useMutation("updateApi", SaveData, {
    enabled: false,
    onSuccess: (res) => { },
    onError: () => { },
  });
  useEffect(() => {
    if (SaveDataApi.status === "success") {
      let roleString = rolesArray.filter(
        (item) => item.roleName === "External Patient Manager"
      );
      let payload = {
        roles: !isEmpty(roleString) ? [roleString[0].roleId] : "",
      };
      console.log("res", get(SaveDataApi, "data.data._id"));
      let id = get(SaveDataApi, "data.data._id");
      updateApi.mutate({ id, payload });
    }
    console.log("saveDatat status", SaveDataApi.status);
  }, [SaveDataApi.isLoading]);

  // const handleErrorValidation = () => {
  //   let namefiled = !isEmpty(name) ? true : false;
  //   let emailfield = !isEmpty(email) ? true : false;
  //   let mobilefield = !isEmpty(mobile) ? true : false;
  //   let valiedemailfield =
  //     (!isEmpty(email) && !email.includes("@thermofisher.com")) ||
  //       isEmpty(email)
  //       ? false
  //       : true;
  //   let roleField = !isEmpty(selectedRole) ? true : false;
  //   let site = !isEmpty(selectedsite) ? true : false;
  //   let trailRecord = viewState.trailsArray[0];

  //   let trailsErrorCheck = true;

  //   trailsErrorCheck = !isEmpty(trailRecord.t__trial_countries) ? true : false;

  //   console.log("trailsErrorCheck", !isEmpty(trailRecord.t__trial_countries));
  //   setErrorState({
  //     ...errorState,
  //     nameError: namefiled,
  //     emailError: emailfield,
  //     mobileError: mobilefield,
  //     roleError: roleField,
  //     siteError: site,
  //     validEmailError: valiedemailfield,
  //     trailError: trailsErrorCheck,
  //   });
  //   console.log(namefiled ,
  //     emailfield ,
  //     mobilefield ,
  //     roleField ,
  //     site ,
  //     !valiedemailfield ,
  //     trailsErrorCheck,"checkflag")

  //   if (
  //     namefiled &&
  //     emailfield &&
  //     mobilefield &&
  //     roleField &&
  //     site &&
  //     !valiedemailfield &&
  //     trailsErrorCheck
  //   ) {
  //     return true;
  //   } else {
  //     return false;
  //   }
  // };

  const handleSave = () => {
    // const checkFlag = handleErrorValidation();

    let roleString = rolesArray.filter(
      (item) => item.roleName === selectedRole
    );
    let lastspaceindex = name.lastIndexOf(" ");
    let firstName = name.substring(0, lastspaceindex);
    let lastName = name.substring(lastspaceindex + 1);

    let newArray = viewState.trailsArray.map((item) => {
      return {
        t__trial_id: item.t__trial_id,
        t__trial_countries: item.t__trial_countries,
      };
    });

    let payload = {

      t__trial_id: "TRIAL001",

      t__trial_sites: "SITE001",
      t__trial_sites_countries: "USA",


      users: input

    }
  
 
   
      SaveDataApi.mutate({ payload });
    
  };

  console.log("valids object", selectedCountry, selectedRole, selectedTimezone);

  const handlecancel = () => {
    // GetAllAccountApi.refetch();

    setInput([{ name: "", email: "", mobile: "", role: "" }]);
    setSelectedsite("")



    console.log(
      " get(GetControlApi",
      get(GetControlApi, "data.data.data.trialList", [])
    );
    setViewState({
      ...viewState,
      trailsArray: [{ t__trial_id: "Select" }],
      trailsFilteredData: get(GetControlApi, "data.data.data.trialList", []),
    });
    setErrorState({
      ...errorState,
      nameError: true,
      emailError: true,
      mobileError: true,
      roleError: true,
      siteError: true,
      validEmailError: true,
      trailError: true,
    });
  };
  console.log("selectedRole", selectedRole);
  console.log("input", input);

  const hanldeNamechange = (e, index) => {
    console.log("hanldeNamechange", e.target.value, index)
    let nameString = e.target.value;
    let lastspaceindex = nameString.lastIndexOf(" ");
    let newArray = [...input];
    newArray[index].name = {first:nameString}
    setInput(newArray)

  }

  const hanldeEmailchange = (e, index) => {
    let emailString = e.target.value;
    let newArray = [...input];
    newArray[index].email = emailString
    setInput(newArray)

  }
  const hanldeMobilechange = (e, index) => {
    let mobileString = e.target.value;
    let newArray = [...input];
    newArray[index].mobile = mobileString
    setInput(newArray)

  }
  console.log(selectedsite, "site")

  return (
    <>
      <ProfileHeader />
      <View>
        <h1 className="Heading6">External Users</h1>
        <div className="iconback1">
          {" "}
          <BiIcons.BiArrowBack
            style={{ height: "24px", width: "24px", color: "#1E8AE7" }}
          />{" "}
          <Link style={{ textDecoration: "none" }} to="/externalusers">
            {" "}
            Back
          </Link>
        </div>
        <Row>
          <Col className="col-md-3">
            {" "}
            <p className="Heading7 ">Create new user</p>
          </Col>
        </Row>

        <div className="trial-country-wrapper">
          {viewState.trailsArray &&
            viewState.trailsArray.map((item, index) => (
              <div
                key={index}
                className="d-flex trail-rows"
                style={{ marginBottom: "24px" }}
              >
                <div style={{ display: "inline-block" }}>
                  <lable className="form-label">Trial:</lable>
                  {console.log("item.t__trial_id", item.t__trial_id)}
                  <CustomMultiSelect
                    key={index}
                    options={viewState.trailsFilteredData}
                    getSelctedItem={(e) => getSelctedItem(e, index)}
                    getSelected={item.t__trial_id}
                    optionKey={"t__trial_id"}
                    optionValue={"t__trial_name"}
                    width={"200px"}
                  />
                  {!errorState.trailError &&
                    viewState.trailsArray[0].t__trial_id === "Select" && (
                      <p style={{ color: "red" }}>Trial is required</p>
                    )}
                </div>
                <div style={{ display: "inline-block", marginLeft: '16px' }}>
                  <lable className="form-label">Site:</lable>

                  <CustomMultiSelect
                    key={index}
                    options={viewState.trailsitelist}
                    getSelctedItem={(e) => getSelectedsite(e, index)}
                    getSelected={get(selectedsite, "t__name", "")}
                    optionKey={"t__name"}
                    optionValue={"t__code"}
                    width={"200px"}
                  />
                  {!errorState.siteError && isEmpty(selectedsite) && (
                    <p style={{ color: "red" }}>Site is required</p>
                  )}

                </div>




              </div>
            ))}
        </div>
        <Row>
          <Col >
            <UserForm>
              <div style={{
                marginTop: "24px",
                border: "1px solid #C8C8C8",
                borderRadius: "4px",
                padding: "32px 16px 32px 32px",
              }}
                className="d-flex flex-wrap">
                {input.map((singleInput, index) => (
                  <div
                    key={index}
                    className="d-flex flex-wrap"

                  >
                    <div
                      style={{ display: "inline-block" }}

                    >
                      <lable className="form-label"> Name:</lable>
                      <input
                        className="normal-input"
                        type="text"
                        name="name"
                        placeholder="Enter name"
                        key={index}
                        value={singleInput.name["first"]}
                        onChange={(e) => {
                          hanldeNamechange(e, index)


                        }}
                        style={{
                          height: "40px",
                          width: "200px",

                          border: "1px solid #C8C8C8",
                        }}
                      ></input>
                      {!errorState.nameError && isEmpty(singleInput.name) && (
                        <p style={{ color: "red", marginTop: "-25px" }}>
                          Name is required
                        </p>
                      )}
                    </div>
                    <div
                      style={{ display: "inline-block", marginLeft: '16px' }}

                    >
                      <div>

                        <lable className="form-label">Email:</lable>

                      </div>
                      <input
                        type="text"
                        className="normal-input"
                        placeholder="Enter email"
                        name="email"
                        key={index}
                        value={singleInput.email}
                        style={{
                          height: "40px",
                          width: "200px",

                          borderRadius: "4px",
                          border: "1px solid #C8C8C8",
                        }}
                        onChange={(e) => {
                          hanldeEmailchange(e, index)


                        }}
                      />
                      {!errorState.emailError && isEmpty(singleInput.email) && (
                        <p style={{ color: "red", marginTop: "-24px" }}>
                          Email is required
                        </p>
                      )}
                      {errorState.validEmailError &&
                        !isEmpty(singleInput.email) &&
                        singleInput.email.includes("@thermofisher.com") && (
                          <p style={{ color: "red", marginTop: "-24px" }}>
                            Enter Valid Email
                          </p>
                        )}
                    </div>
                    <div
                      style={{ display: "inline-block", marginLeft: '16px' }}

                    >
                      <div>

                        <lable className="form-label">Mobile :</lable>

                      </div>
                      <input
                        type="number"
                        className="normal-input"
                        placeholder="Enter mobile number"
                        name="mobile"
                        value={singleInput.mobile}
                        key={index}
                        style={{
                          height: "40px",
                          width: "200px",

                          borderRadius: "4px",
                          border: "1px solid #C8C8C8",
                        }}
                        onChange={(e) => {
                          hanldeMobilechange(e, index)


                        }}
                      />
                      {!errorState.mobileError && isEmpty(singleInput.mobile) && (
                        <p style={{ color: "red", marginTop: "-25px" }}>
                          Mobile is required
                        </p>
                      )}
                    </div>

                    <div
                      style={{ display: "inline-block", marginLeft: '16px' }}

                    >
                      <div>
                        {" "}
                        <lable className="form-label">Role:</lable>
                        <CustomMultiSelect
                          // key={"role-dropdown"}
                          options={rolesArray}
                          key={index}
                          getSelctedItem={(e) => {
                            getSelectedRole(e, index);
                          }}
                          getSelected={singleInput.role}
                          optionKey={"roleName"}
                          optionValue={"roleId"}
                          width={"200px"}
                        />
                        {!errorState.roleError && isEmpty(singleInput.role) && (
                          <p style={{ color: "red" }}>Role is required</p>
                        )}
                      </div>
                    </div>
                    <div style={{
                      marginTop: "32px",
                      marginLeft: "16px",
                      display: "inline-block",
                    }} >
                      {input.length !== 1 && (
                        <IoIcons.IoMdCloseCircle
                          className="icon-close"

                          onClick={() => handleServiceRemove(index)}
                        />


                      )}
                    </div>


                    {input.length - 1 === index && input.length < 5 && (
                      <button
                        type="button"
                        onClick={() => handleTrialAdd()}
                        style={{
                          textDecoration: "none",
                          fontWeight: "700",
                          outline: "none",
                          border: "none",
                          color: "#1E8AE7",
                          background: "white",
                          marginTop: "10px",
                        }}
                      >
                        Add new User
                      </button>
                    )}

                  </div>
                ))}
              </div>

              <div>
                <div style={{ display: "inline-block" }}>
                  <button className={`btn4`} onClick={handleSave}>
                    Save
                  </button>
                  <button type="button" className="btn5" onClick={handlecancel}>
                    Cancel
                  </button>
                </div>
              </div>
              <ToastContainer />
            </UserForm>
          </Col>
        </Row>
      </View>
    </>
  );
}

export default ExternalCreateUsers;
