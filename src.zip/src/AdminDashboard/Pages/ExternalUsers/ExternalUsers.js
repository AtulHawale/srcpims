import React from "react";
import CustomTable from "../../../Component/CustomTable"
import { useState, useEffect, useMemo } from "react";
import styled from "styled-components";
import { Field } from "formik";
import Select from "react-select";
import { useQuery } from "react-query";
import { GetInternalUsers } from "../../../Api";
import axios from "axios";
import Loader from "react-loader";
import { CgOpenCollective, CgSearch } from "react-icons/cg";
import { rolesArray } from "../../../Constants";
import { get, _, isEmpty} from "lodash";
import ProfileHeader from "../../ProfileHeader";
import CustomSelect from "../../../Component/CustomSelect";
import { ReactComponent as ArrowDown } from "../../../Logo/arrow drop down.svg";
import { ReactComponent as SearchIconSvg } from "../../../Logo/search.svg";
import {flatten} from 'lodash'
import { useNavigate } from "react-router-dom";
const TableWrapper = styled.div`
  padding: 1rem;
  padding: 0;

  table {
    border-spacing: 0;
    border: 1px solid black;

    tr {
      :last-child {
        td {
          border-bottom: 0;
        }
      }
    }

    th,
    td {
      margin: 0;
      padding: 0.5rem;
      border-bottom: 1px solid black;
      border-right: 1px solid black;
      max-width: 200px;
      text-overflow: ellipsis;
      white-space: nowrap;
      .inactive {
        height: 8px;
        width: 8px;
        border: 1px solid #ee3134;
        background: #ee3134;
        border-radius: 50%;
        display: inline-block;
        margin-right: 5px;
      }
      .active {
        height: 8px;
        width: 8px;
        border: 1px solid #1bba3e;
        background: #1bba3e;
        border-radius: 50%;
        display: inline-block;
        margin-right: 5px;
      }
      .pending {
        height: 8px;
        width: 8px;
        border: 1px solid #eb9411;
        background: #eb9411;
        border-radius: 50%;
        display: inline-block;
        margin-right: 5px;
      }

      :last-child {
        border-right: 0;
      }
    }
  }
`;
const SearchIcon = styled.div`
  height: 40px;
  width: 40px;
  background: #dd1f25;
  border-radius: 4px;
  position: relative;
  cursor: pointer;
  svg {
    height: 30px;
    width: 30px;
    color: #fff;
    position: absolute;
    top: 5px;
    left: 5px;
  }
 
  }
`;
const Search = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-family: Helvetica;
  font-size: 16px;
  @media screen and (max-width: 550px){
    .margin-div {
      margin-top: 16px;
      width: 100%;
      input{
        width: 100%;
      }
    }
 
   
  
  }
  
  .search-input {
    height: 40px;
    border: 1px solid #c8c8c8;
    padding: 10px;
    border-radius: 4px;
    width: 208px;
    margin-right: 8px;
    outline: none;
    &:hover,&:active,&:focus{
      border-color: none !important;
      box-shadow: 0 0 0 0.25rem rgb(13 110 253 / 25%);
    }
    
      }

    
    
  }
  .search-heading {
    font-weight: 700;
    padding-right: 16px;
    @media screen and (max-width: 550px){
      padding-top: 11.75px;
      padding-bottom: 11.75px;
    }

  }
  .select {
    height: 40px;
    padding-right: 8px;
    @media screen and (max-width: 550px){
      padding-right: 0px;
    }
    .mySelect__menu{
      margin: 0;
      cursor: pointer;
    }
    .mySelect__value-container{
      cursor: pointer;
    }
    .mySelect__control {
      height: 100%;
      border: 1px solid #C8C8C8;
   
      &:hover,&:active,&:focus{
        border-color: none !important;
        box-shadow: 0 0 0 0.25rem rgb(13 110 253 / 25%);
      }
    }
    .mySelect__single-value {
      height: 100%;
      line-height: 35px;
    }
    .mySelect__indicators {
      height: 100%;
    }
    .mySelect__indicator-separator {
      display: none;
    }
    .mySelect__dropdown-indicator{
      svg{
        position: absolute;
        right: 8px;
        top: 10px;
        opacity: 0;
        z-index: 1;
        cursor: pointer;
      }
    }
    .mySelect__menu-list{
      margin: 0;
      padding: 0;
      .react-select__option--is-selected{
        backgroundColor: "red";

      }
    }
  }
  @media screen and (max-width: 550px){
    display: flex;
    flex-direction: column;
    align-items: flex-start;
   
   
  }
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 34px;
  margin-bottom: 48px;
  .select-container {
    position: relative;
    width: 136px;
    cursor: pointer;
    .arrow-down {
      position: absolute;
      top: 4px;
      right: 10px;
      cursor: pointer;
    }
  }

  @media screen and (max-width: 550px) {
    display: flex;
    flex-direction: column;
    justify-content: flex-start !important;
    align-items: normal;
    .select-container {
      width: 100%;
    }
  }
`;

function ExternalUsers() {
  const [data, setData] = useState([]);
  const [pageCount, setPageCount] = React.useState(0);
  const [totalRecords, setTotalRecords] = useState();
  const [filteredArray, setFilteredArray] = useState([]);
  const [filteredText, setFilteredText] = useState(null);
  const navigate = useNavigate()
  const customStyles = {
    option: (styles, { data, isDisabled, isFocused, isSelected }) => {
      return {
        ...styles,
        backgroundColor: isFocused ? "rgb(13 110 253 / 25%)" : null,
        color: "#333333"
      };
    }
  };
  const [columnBy, setColumnBy] = useState({
    label: "By Email",
    value: "email",
  });

  const options = [
    { value: "email", label: "By Email" },
    { value: "name", label: "By Name" },
    { value: "roles", label: "By Role" },
    { value: "t__status", label: "By Status" },
    { value: "t__trial_country", label: "By Trial" },
    { value: "t__trial_sites", label: "By Site" },
    { value: "By Country", label: "By Country" },
    
  ];

  const handleViewEdit = (row) => {
   
    navigate(`/viewuserexternal?id=${row.row.values._id}`)
  };
 

  const columns = useMemo(() => [
    {
      Header: "Email",
      accessor: "email",
      width: 150,
     
      
    },
    {
      Header: "Name",
      accessor: (row) => row.name.first,
      width: 120,
      // Cell: ({ cell }) => (
      //   <span>
      //     {console.g("first",cell)}
      //     {/* {cell.row.values.name.first} {cell.row.values.name.last} */}
      //   </span>
      // )
      
    },
    // {
    //   Header: "Mobile",
    //   accessor: "mobile",
    //   width: 130,
    // },
    {
      Header: "Role",
      accessor: (row) => {
        
        let filtered =
          rolesArray &&
          rolesArray.filter(
            (item) => item.roleId === get(row, "roles[0]")
          );

        return get(filtered, "[0].roleName", "")
      },
      width: 100
      // Cell: ({ cell }) => {
      //   let filtered =
      //     rolesArray &&
      //     rolesArray.filter(
      //       (item) => item.roleId === get(cell, "row.values.roles[0]")
      //     );

      //   return (
      //     get(filtered, "[0].roleName", "") && (
      //       <span>{get(filtered, "[0].roleName", "")}</span>
      //     )
      //   );
      // },
    },
    {
      Header: "Activation Status",
      accessor: "t__status",
      width: 170,
      Cell: ({ cell }) => (
        <>
          <div
            className={get(cell, "row.values.t__status", "").toLowerCase()}
          ></div>
          <span>{get(cell, "row.values.t__status", "")}</span>
        </>
      ),
    },

    {
      Header: "Trial (s) ",
      accessor: (row) => {        
          
          let TrailString = flatten(row.t__trial_country.map((item) => item.t__trial_id))
        
        
          return   TrailString.toString() !== "," ? getString(TrailString.toString()): "" ; 
      },   
      width: 100
      // Cell: (row) => {
      //   return (
      //     <>
      //       {row.value.map((item) => (
      //         <span>
      //           {item.t__trial_id} {""}
      //         </span>
      //       ))}
      //     </>
      //   );
      // },
    },
    {
      Header: "Site",
      accessor: (row) => {  
        let TrailString = flatten(row.t__trial_sites.map((item) => item.t__trial_sites))
           
        
          return  TrailString.toString() !== "," ? getString(TrailString.toString()): "" ; 
      },   
      width: 80
    },
    {
      Header: "Country",
      accessor: (row) => {  
        let TrailString = flatten(row.t__trial_sites.map((item) => item.t__trial_sites_countries))           
        
          return  TrailString.toString() !== "," ? getString(TrailString.toString()): "" ; 
      },   
      width: 80
    },
    {
      Header: "",
      accessor: "_id",
      width: 140,
      Cell: (row) => (
        <button
          onClick={() => handleViewEdit(row)}
          className="view-edit-button"
        >
          View/Edit
        </button>
      ),
    },
  ]);

  const getString = (str) => {
    let newString =str;
    if(str.indexOf(',') === 0){
      newString = str.substring(1)
      return newString
    } else{
      return str
    }
    
  }

  const handleFilterChange = (e) => {
    setFilteredText(e.target.value);
    setFilteredArray();
  };
  

  const handleSearch = () => {

    const dataArray = [...data];


    const newArray = dataArray.filter((item) => {
    
      if (
        ["email", "mobile"].includes(columnBy.value)
      ) {
        // item[columnBy.value].includes(e.target.value)

        return (
          item[columnBy.value] &&
          item[columnBy.value]
            .toLowerCase()
            .trim()
            .includes(filteredText.toLowerCase().trim())
        );
      } else if (columnBy.value === "name") {
        let namefilter = columnBy.value;
        let nameString = [item[namefilter].first ,item[namefilter].last].filter(Boolean).join(", ");
        let reverseString = [item[namefilter].last ,item[namefilter].first].filter(Boolean).join(", ");
        let finalNameString = nameString.replaceAll(',',' ').replace(/\s/g, "")
        let finalReverseString = reverseString.replaceAll(',',' ').replace(/\s/g, "")
      
        // let finalNameString = nameString.replace(/\s/g, "")
        let filteredName = filteredText.split(" ");
      
        
       
        let firstName =  filteredName[0];
        let lastName =   filteredName[1];
       
        let fullName  = filteredName.toString()
        let finalFullName = fullName.replaceAll(',',' ').replace(/\s/g, "")
        let reverseFullName = filteredName.reverse();
        let finalReverseFullName = reverseFullName.toString().replaceAll(',',' ').replace(/\s/g, "");
       
        

        // let fullName =  filteredName[0] +  filteredName[1] + filteredName[2]
        // let rveresedFullName = filteredName[1] + filteredName[0]
      
        if(firstName && lastName){
          
          return finalNameString.toLowerCase().includes(finalFullName
            .toLowerCase()) || finalNameString.toLowerCase().includes(finalReverseFullName.toLowerCase())
        } else if(firstName){
          return nameString.toString().toLowerCase().includes(firstName
            .toString()
            .toLowerCase())
        } else if(lastName){
          return nameString.toString().toLowerCase().includes(lastName
            .toString()
            .toLowerCase())
        } 
        
      } else if (columnBy.value === "roles") {
        let userRole = filteredText.trim();

        let rolesfilteredId = rolesArray.filter((item) =>
          item.roleName
            .toLowerCase()
            .trim()
            .includes(filteredText.toLowerCase().trim())
        );
        // let roleNames = rolesfiltered[0].roleName
        
        if(rolesfilteredId.length > 0){
          return (
            item[columnBy.value] &&
            item[columnBy.value][0] &&
            get(item[columnBy.value], "[0]").toString().includes(          
                rolesfilteredId && get(rolesfilteredId, "[0].roleId").toString())
              
          );
        } else {
          return null
        }
       
      } else if(["t__trial_country"].includes(columnBy.value)){      
        let filteredArray = flatten(item[columnBy.value].map((sub) => (sub.t__trial_id)))
        const finalResult = filteredArray.some(ele => ele.toLowerCase().includes(filteredText.toLowerCase()))
      if(finalResult){
        return item[columnBy.value]
      } else{
        return null
      }
        

      }
      else if(["t__status"].includes(columnBy.value)){
        return (
          item[columnBy.value] &&
          item[columnBy.value]
            .toLowerCase()
            .trim()
            === (filteredText.toLowerCase().trim())
        );
      }
      else if(["t__trial_sites"].includes(columnBy.value)){       
        return (
          item[columnBy.value] &&
          get(item[columnBy.value],"[0].t__trial_sites.[0]","")
        .toLowerCase()
        .trim().includes(
         (filteredText.toLowerCase().trim()))
        );
      }
      else if(["By Country"].includes(columnBy.label)){   
         
        return (
          item["t__trial_sites"] &&
          get(item["t__trial_sites"],"[0].t__trial_sites_countries.[0]","")
        .toLowerCase()
        .trim().includes(
         (filteredText.toLowerCase().trim()))
        );
      }
    });

    setFilteredArray(newArray);
  };
  

  const handleChange = (value) => {
    setColumnBy(value);
  };

  const GetExternalUsersApi = useQuery([
    "GetExternalUsersApi","External"],
    GetInternalUsers,
    {
      enabled: true,
      onSuccess: (res) => {
        let sortedARray = get(res,"data.data",[]).sort((a, b) => new Date(b.updated) - new Date(a.updated));
        setData(sortedARray);
        
      },
      onError: (res) => {
        alert(res);
        setData([]);
      },
    }
  );

 
  
  return (
    <>
      <ProfileHeader />
      <TableWrapper>
        <Header>
          <h1 className="heading m-0">External Users</h1>
          <Search className="col-md-7 justify-content-end">
            <div className="search-heading">Search User:</div>
            <div className="select-container">
              <Select
                options={options}
                onChange={(value) => handleChange(value)}
                defaultValue={columnBy}
                className="select"
                classNamePrefix="mySelect"
                styles={customStyles}
              />
              <ArrowDown className="arrow-down" />
            </div>

            <div className="d-flex margin-div">
              <input
                type="text"
                onChange={(e) => handleFilterChange(e)}
                placeholder="Enter Information"
                className="search-input"
                onKeyPress={(e) => e.charCode === 13 && handleSearch()}
              />
              <SearchIcon>
                <SearchIconSvg onClick={handleSearch} />
              </SearchIcon>
            </div>
          </Search>
        </Header>

        {GetExternalUsersApi.isLoading ? (
          <Loader />
        ) : (
          <CustomTable
            columns={columns}
            data={
              filteredText && filteredArray && filteredArray.length > 0
                ? filteredArray
                : filteredText && filteredArray && filteredArray.length === 0
                ? []
                : data
            }
          />
          )}  
      </TableWrapper>
    </>
  );
}

export default ExternalUsers;
