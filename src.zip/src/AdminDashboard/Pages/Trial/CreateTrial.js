import React, { useState, useEffect } from 'react'
import ProfileHeader from "../../ProfileHeader";
import * as BiIcons from "react-icons/bi";
import * as IoIcons from "react-icons/io";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import {Link} from 'react-router-dom'
import styled from "styled-components";
import Form from 'react-bootstrap/Form';
import axios from 'axios'
import { FaLessThanEqual } from 'react-icons/fa';
const View = styled.div`
  .viewheading {
    padding-top: 20px;
  }
  .form-label {
    display: block;
    font-family: Helvetica;
    font-weight: 700;
    font-size: 16px;
    margin-bottom: 0;
  }
  .textbox-label {
    display: block;
    font-family: Helvetica;
    font-size: 14px;
    margin-bottom: 0;
  }
  .viewheading1 {
    padding-top: 20px;
    font-weight: 700;
    font-size: 24px;
    margin-top: 48px;
  }
  .iconback1 {
    color: #1e8ae7;
    padding-top: 32px;
    font-weight: 700;
    font-size: 16px;
    padding-left: 10px;
  }
  .viewuser {
    font-weight: 700;
    font-size: 24px;
    font-style: normal;
    font-family: Helvetica;
  }
  .viewuser1 {
    font-weight: 700;
    font-size: 24px;
    font-style: normal;
    padding-top: 24px;
    margin-right: 500px;
  }
  .view2 {
    font-weight: 700;
    font-size: 24px;
    font-style: normal;
    padding-top: 46px;
  }
  .normal-input {
    height: 40px;
    width: 480px;
    border: 1px solid #c8c8c8;
    border-radius: 4px;
    margin-bottom: 24px;
    padding: 0 16px;
   
  
  }
  .normal-input:focus{
  
    color: #212529;
    background-color: #fff;
    border-color: #86b7fe;
    outline: 0;
    box-shadow: 0 0 0 0.25rem rgb(13 110 253 / 25%);
  }
  .box-input {
    height: 40px;
    width: 180px;
    border: 1px solid #c8c8c8;
    border-radius: 4px;
    margin-bottom: 24px;
    padding: 0 16px;
   
  
  }

  .box-input:focus{
  
    color: #212529;
    background-color: #fff;
    border-color: #86b7fe;
    outline: 0;
    box-shadow: 0 0 0 0.25rem rgb(13 110 253 / 25%);
  }

  .button-class{
    margin-top:21px;
    margin-right: 30px;
    width: 89px;
    background: #ee3134;
    border: 1px solid #dd1f25;
    border-radius: 4px;
    color: white;
    height: 40px;
    margin-left: 0px;
  }
  

`;

const initialState = {
  trailsArray: [{ t__customer: [] }],
  trailsOriginalList: [],
  trailsFilteredData: [],
 

}

export default function CreateTrial() {

  const [disableSave, setDisableSave] = useState(true)
  const [customerArray, setCustomerArray]= useState([])
  const [showAddTextBox, setShowAddTextBox] = useState(false)
  const [enteredCountryCode,setEnteredCountryCode]=useState("")
  const [enteredCountryName, setEnteredCountryName]= useState("")
  const [selectedCustomer, setSelectedCustomer] = useState("")
  const [editEnabled, setEditEnabled] = useState(false)
  const [enteredTrial, setEnteredTrial]= useState("")
  const [customerId, setCustomerId]= useState("")
  const[showError, setShowError]= useState(false)

  useEffect(() => {
    console.log(" entered trial", enteredTrial)

  axios.get(
    "https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/getCustomerList",
    {
      headers: {
        "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3",
      },
      withCredentials: true,
    })

  .then((res) => {
      console.log("use effect response headers", res.headers)
      console.log("GET Customer api response", res);
      setCustomerArray(res.data.data)
  })
  .catch((err) => {
    console.log(err.response.data.message,'error')
    alert(err.response.data.message)
  })

    if(enteredTrial!==""&& customerArray.length!==0){
      setDisableSave(false)
    }
    else{
      setDisableSave(true)
    }
   
    
  },[])

  const handleAddCustomer = () => {
    console.log(" handle trial add called")
   // setDisableSave(false)
    setShowAddTextBox(true)
    if(editEnabled===false){

      setEnteredCountryCode("")
      setEnteredCountryName("")
      }
    }

  const handleCustomerDropdown=(e)=>{
    setShowError(false)
   // setDisableSave(false)
      setSelectedCustomer(e.target.value)
    setEditEnabled(true)
    
    console.log(" handle customer drop down called ",selectedCustomer)
    let splitValue= e.target.value.split("-")
    
    setEnteredCountryCode(splitValue[0])
    setEnteredCountryName(splitValue[1])
    
  }

  const handleTrial=(e)=>{

  
    setEnteredTrial(e.target.value)
    if(e.target.value!==""&&customerArray.length!==0){
      setDisableSave(false)
    }
    else{
      setDisableSave(true)
    }
    // if(e.target.value!==""&& customerArray.length!==0){
    //   setDisableSave(false)
    // }
    // else{
    //   setDisableSave(true)
    // }
    console.log(" handle trial called", enteredTrial)
    console.log(" handle trial called e value", e.target.value)
  }

  const handleSave=()=>{
    console.log(" handle save called",enteredCountryCode)
if(enteredCountryCode!==""){
    axios({
      method: "post",
      withCredentials:true,
          url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/t__trial",
          data: { "t__customer": enteredCountryCode, "t__protocol":enteredTrial,
           "t__trial_id":enteredCountryCode+"-"+enteredTrial ,
           "t__trial_name":enteredCountryCode+" "+enteredCountryName+"-"+enteredTrial,
          "t__trial_status":"Active"},
          headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
  })
  .then((res) => {
      console.log("use effect response headers", res.headers)
      console.log("Customer api  POST response", res);
      
  })
  .catch((err) => {
    console.log(err.response.data.message,'error')
    alert(err.response.data.message)
  })

  setEnteredTrial("")
}
else {
  setShowError(true)
}

  }

  const handleCustomerCreate=async()=>{
    console.log("EDIT ENABLED", editEnabled)
  if(editEnabled==false){
    try{
      const resp = await axios({
        method: "post",
        withCredentials:true,
        url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/t__customer",
        data: { "t__customer_id": enteredCountryCode, "t__customer_name":enteredCountryName },
        headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
    })
    console.log(" response from update api",resp )
    if(resp.status===200){
      try{
        const responseFromGet= await axios({
          method: "get",
          withCredentials:true,
          url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/getCustomerList",
          headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
      })
      if(responseFromGet.status==200){
        setCustomerArray(responseFromGet.data.data)
      }
      }
      catch(error){
        alert(error)
      }
    }
    }
   
    catch(err){
alert(err)
    }
  }
  if(editEnabled){
    var newArray=[...customerArray]
    console.log("NEW ARRAY", newArray)
     var foundIndex = newArray.findIndex(x => x.t__customer_name == selectedCustomer);
     console.log("aaaaaa",customerArray[foundIndex])
var id = customerArray[foundIndex]._id
    console.log("indexofEditedData",foundIndex)
    console.log(" id of selected ", id)
    setCustomerId(id)
    console.log("customer id is", customerId)
    try{
      const responseFromPut = await axios({
        method: "put",
        withCredentials:true,
        url: `https://api.dev.medable.com/cognizant-tf-sandbox/v2/t__customer/${id}`,
         data: { "t__customer_id": enteredCountryCode, "t__customer_name":enteredCountryName },
        headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
    })
    console.log(" response from update api",responseFromPut )
    if(responseFromPut.status===200){
      try{
        const responseFromGetAPI= await axios({
          method: "get",
          withCredentials:true,
          url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/getCustomerList",
          headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
      })
      if(responseFromGetAPI.status==200){
        setCustomerArray(responseFromGetAPI.data.data)
      }
      }
      catch(error){
        alert(error)
      }
    }
    }
   
    catch(err){
alert(err)
    }
  }
setEnteredCountryCode("")
setEnteredCountryName("")
  }

  const handleAddButton=()=>{
    handleCustomerCreate()
    //if(editEnabled){
  //   axios({
  //     method: "post",
  //     withCredentials:true,
  //         url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/t__customer",
  //         data: { "t__customer_id": enteredCountryCode, "t__customer_name":enteredCountryName },
  //         headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
  // })
  // .then((res) => {
  //     console.log("use effect response headers", res.headers)
  //     console.log("Customer api  POST response", res);
      
  // })
  // .catch((err) => {
  //   console.log(err.response.data.message,'error')
  //   alert(err.response.data.message)
  // })
//}
// if(editEnabled===false){
//   axios({
//     method: "put",
//     withCredentials:true,
//         url: `https://api.dev.medable.com/cognizant-tf-sandbox/v2/t__customer/${id}`,
//         data: { "t__customer_id": enteredCountryCode, "t__customer_name":enteredCountryName },
//         headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
// })
// .then((res) => {
//     console.log("use effect response headers", res.headers)
//     console.log("Customer api  POST response", res);
    
// })
// .catch((err) => {
//   console.log(err.response.data.message,'error')
//   alert(err.response.data.message)
// })
// }

  
    
    setEditEnabled(false)
    console.log(" handle add button called", enteredCountryCode, enteredCountryName)
    console.log("CUSTOMER ARRAY", customerArray)
    console.log("selected value", selectedCustomer)
  //   var newArray=[...customerArray]
  //   console.log("NEW ARRAY", newArray)
  //    var foundIndex = newArray.findIndex(x => x.t__customer_name === selectedCustomer);
  //  //var foundIndex= customerArray.findIndex(selectedCustomer)

  //    console.log(" found index", foundIndex)
  //   if(foundIndex!==-1){
  //     customerArray[foundIndex] = {"t__customer_id":enteredCountryCode,"t__customer_name":enteredCountryCode+"-"+enteredCountryName}
  //    console.log(" newArray if found", newArray, enteredCountryCode, enteredCountryName)
  //   }
  //   else
  //   {
  //    customerArray.push({"t__customer_id":enteredCountryCode,"t__customer_name":enteredCountryCode+"-"+enteredCountryName})
  //    }
  //    //setCustomerArray(newArray)
  //    console.log(" new array", newArray)
     setShowAddTextBox(false)
  }
  
  const handleCountryCode=(e)=>{
    console.log(" handle country code called", e.target.value)
    setEnteredCountryCode(e.target.value)
  }

  const handleCountryName=(e)=>{
    setEnteredCountryName(e.target.value)
  }

  const handleCancelAPI=async()=>{

    
    try{
const responseFromAPI= await axios({
  method: "get",
  withCredentials:true,
  url: "https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/getCustomerList",
  headers: { "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3" },
})
if(responseFromAPI.status===200){
  console.log("use effect response headers", responseFromAPI.headers)
  console.log("GET Customer api response on cancel ", responseFromAPI);
  setCustomerArray(responseFromAPI.data.data)
  setEnteredTrial("")
setEnteredCountryCode("")
setEnteredCountryName("")
setShowAddTextBox(false)

}
    }
catch(err){
  console.log(err.response.data.message,'error')
  alert(err.response.data.message)
}
    
  }

  const handleCancel=()=>{
    handleCancelAPI()
    setEditEnabled(false)
    setShowError(false)
    // console.log(" handle save")
    // axios.get(
    //   "https://api.dev.medable.com/cognizant-tf-sandbox/v2/routes/getCustomerList",
    //   {
    //     headers: {
    //       "medable-client-key": "EYKm5YLKZjjRNi7MDkqxA3",
    //     },
    //     withCredentials: true,
    //   })
  
    // .then((res) => {
    //     console.log("use effect response headers", res.headers)
    //     console.log("GET Customer api response on cancel ", res);
    //     setCustomerArray(res.data.data)
    //     setEnteredTrial("")
    //   setEnteredCountryCode("")
    //   setEnteredCountryName("")
    //   setShowAddTextBox(false)
    // })
    // .catch((err) => {
    //   console.log(err.response.data.message,'error')
    //   alert(err.response.data.message)
    // })
  
      if(enteredTrial!==""&& customerArray.length!==0){
        setDisableSave(false)
      }
      else{
        setDisableSave(true)
      }
      
  }

  return (
    <>
    <ProfileHeader />
    <View>
    <h1 className="Heading6">Trial Setup</h1>
        <div className="iconback1">
          {" "}
          <BiIcons.BiArrowBack
            style={{ height: "24px", width: "24px", color: "#1E8AE7" }}
          />{" "}
          <Link style={{ textDecoration: "none" }} to="/trial">
            {" "}
            Back
          </Link>
        </div>
        <Row style={{paddingTop:"32px"}}>
          <Col className="col-md-3">
            <h3 className="viewuser ">Create new trial</h3>
          </Col>
          <Col style={{paddingLeft:"141px"}}>
         <div>
         <lable className="form-label">Customer:</lable>
         
        
          <div style={{paddingTop:"5px"}}>  
                      <Form.Select style={{ height: '40px', width: '480px', borderRadius: '4px', border: '1px solid #C8C8C8' }}
                      onChange={(e)=>handleCustomerDropdown(e)}
                      value={selectedCustomer}
                    
                     >
                        <option value="">Select customer</option>
                      {customerArray.map(opt => (
                              <option >{opt.t__customer_name}</option>
                        ))}
                   </Form.Select>
          </div> 
          {showError?<p style={{fontSize:"14px", color:"red"}}>Customer selection is required</p>:""}
          </div>
                    <button
                        type="button"
                        onClick={() => handleAddCustomer()}
                        style={{
                          textDecoration: "none",
                          fontWeight: "700",
                          outline: "none",
                          border: "none",
                          color: "#1E8AE7",
                          background: "white",
                          marginTop: "10px",
                          marginLeft:"-5px"
                        }}
                      >
                       {editEnabled? "Edit selected customer":  "Add a new customer"} 
                      </button>

                        {showAddTextBox?
                      <div style={{display:"flex",flexDirection:"row", paddingTop:"15px"}}>
                        <div>
                        <label className="textbox-label">Master customer code:</label>
                        <input
                        className="box-input"
                        type="text"
                        name="customerCode"
                        placeholder="Enter customer code"
                        value={enteredCountryCode}
                        onChange={(e)=>handleCountryCode(e)}
                     
                       >
                        </input>
                        </div>
                        <div style={{paddingLeft:"15px"}}>
                        <label className="textbox-label">Master customer name:</label>
                        <input
                        className="box-input"
                        type="text"
                        name="customerName"
                        placeholder="Enter customer name"
                        value={enteredCountryName}
                        onChange={(e)=>handleCountryName(e)}
                       
                       >
                        </input>
                        </div>
                        <div style={{paddingLeft:"15px"}}>
                        <button className="button-class" 
                        onClick={handleAddButton}
                        disabled={enteredCountryCode&&enteredCountryName !==""?false:true}
                        style={{opacity:enteredCountryCode&&enteredCountryName !==""?"":"0.5"}}
                    >
                      Add
                    </button>
                        </div>

                      </div>
                      :""
                            }


            <div style={{paddingTop:"16px"}}>
            <label className="form-label">Protocol:</label>
            <input
                        className="normal-input"
                        type="text"
                        name="protocol"
                        placeholder="Enter Protocol"
                        value={enteredTrial}
                        onChange={(e)=>{handleTrial(e)}}
                      ></input>

            </div>
            <div>
                  <div style={{ display: "inline-block" }}>
                    <button className={`btn4`} disabled={disableSave} style={{opacity:disableSave?"0.5":""}}
                    onClick={handleSave}
                    >
                      Save
                    </button>
                    <button
                      type="button"
                      className="btn5"
                      onClick={handleCancel}
                    >
                      Cancel
                    </button>
                  </div>
                </div>

          </Col>
         
        
            </Row>
            </View>
    </>
  )
}
