import React from 'react'
import {Link} from 'react-router-dom'

function Trial() {
   
    return (
        <>
        <Link to ="/createtrial" className='button9' >Create new trial</Link>
        </>
    )
}

export default Trial