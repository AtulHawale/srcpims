import React from 'react'
import ProfileHeader from "../../ProfileHeader";
import * as BiIcons from "react-icons/bi";
import * as IoIcons from "react-icons/io";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import { Link } from 'react-router-dom'
import styled from "styled-components";
import Form from 'react-bootstrap/Form';
const View = styled.div`
  .viewheading {
    padding-top: 20px;
  }
  .viewheading1 {
    padding-top: 20px;
    font-weight: 700;
    font-size: 24px;
    margin-top: 48px;
  }
  .iconback1 {
    color: #1e8ae7;
    padding-top: 32px;
    font-weight: 700;
    font-size: 16px;
    padding-left: 10px;
  }
  .viewuser {
    font-weight: 700;
    font-size: 24px;
    font-style: normal;
    padding-top: 24px;
    font-family: Helvetica;
  }
  .viewuser1 {
    font-weight: 700;
    font-size: 24px;
    font-style: normal;
    padding-top: 24px;
    margin-right: 500px;
  }
  .view2 {
    font-weight: 700;
    font-size: 24px;
    font-style: normal;
    padding-top: 46px;
  }
  .form-label{
    font-weight: 700;
    font-size: 16px;
  }
  .check{
    width: 480px;
     height: 144px;
background: rgba(249, 245, 245, 0.25);

border: 1px solid #C8C8C8;
border-radius: 4px;
margin-top:16px;
padding-left:16px;
padding-top:16px;
font-size:16px;


  }
`;

function CreateProtocol() {
  return (
    <>
      <ProfileHeader />
      <View>
        <h1 className="Heading6">Protocol Setup</h1>
        <div className="iconback1">
          {" "}
          <BiIcons.BiArrowBack
            style={{ height: "24px", width: "24px", color: "#1E8AE7" }}
          />{" "}
          <Link style={{ textDecoration: "none" }} to="/protocol">
            {" "}
            Back
          </Link>
        </div>
        <Row>
          <Col className="col-md-3">
            {" "}
            <h3 className="viewuser ">View Protocol</h3>
          </Col>
          <Col>
            <div>  <lable className="form-label">Customer:</lable>
              <Form.Select style={{ height: '40px', width: '480px', borderRadius: '4px', border: '1px solid #C8C8C8' }} >
                <option> select</option>
              </Form.Select></div> <br></br>
            <div>  <lable className="form-label">Protocol:</lable>
              <Form.Control type="email" placeholder="Enter email" style={{ height: '40px', width: '480px', borderRadius: '4px', border: '1px solid #C8C8C8' }} />
            </div>
            <div className="check "   >
              <input type="checkbox" />
              
              <b style={{fontFamily:'Helvetica',fontSize:'16px',paddingLeft:'10px'}}>Delete protocol:</b> Select and save to delete the <br></br>
              <span style={{fontFamily:'Helvetica',fontSize:'16px',paddingLeft:'25px'}}> protocol information.</span><br></br>
              <span style={{fontFamily:'Helvetica',fontSize:'16px',paddingLeft:'25px'}}>(WARNING: Deleting protocol information will erase <br></br><span style={{paddingLeft:'25px'}}>permanently all data about this protocol).</span></span>

              

              

            </div>
            <div>
                <div style={{ display: "inline-block" }}>
                  <button className="btn4">
                    Save
                  </button>
                  <button type="button" className="btn5" >
                    Cancel
                  </button>
                </div>
              </div>



          </Col>


        </Row>
      </View>
    </>
  )
}

export default CreateProtocol