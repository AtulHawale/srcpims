import React from 'react'

function SecondComponent(props){
    return(
        <div>
            <h2> You are logged in as an External User</h2>
           
        </div>
    )
}

export default SecondComponent