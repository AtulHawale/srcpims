import React from 'react'
import { useNavigate } from 'react-router-dom'

function InternalSiteManager() {
   const navigate =useNavigate()
   window.onpopstate = () => {
    console.log("hellloo")
    
    navigate("/success");
  }
  const Logout = () => {
    sessionStorage.clear()
  
  
    window.location.href = 'https://aav0112.my.idaptive.app/applogout/appkey/3f986442-dbe0-4d4d-935e-c876390cdb1c/customerid/AAV0112'
  
  }
  

  return (
    <>
    <h3>Internal Site Manager</h3>
    <button style={{ marginTop: '100px',marginLeft:'20px',border: 'none', outline: 'none', background: '#DD1F25', color: 'white', fontSize: '16px', fontWeight: '700' }} onClick={Logout}>Log out</button>
    </>
  )
}

export default InternalSiteManager