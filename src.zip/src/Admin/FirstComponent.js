import React from 'react'

function FirstComponent(props){
    return(
        <div>
            
            <h2> You are logged in as an Internal User</h2>
           
        </div>
    )
}

export default FirstComponent